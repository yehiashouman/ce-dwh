<?php
class Kaltura_Client_Type_PlaylistFilter extends Kaltura_Client_Type_PlaylistBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaPlaylistFilter';
	}
	

}

