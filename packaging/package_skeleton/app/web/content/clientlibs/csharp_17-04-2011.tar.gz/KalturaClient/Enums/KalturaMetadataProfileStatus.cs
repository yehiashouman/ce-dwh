namespace Kaltura
{
	public enum KalturaMetadataProfileStatus
	{
		ACTIVE = 1,
		DEPRECATED = 2,
		TRANSFORMING = 3,
	}
}
