<?php
class Kaltura_Client_Type_PermissionFilter extends Kaltura_Client_Type_PermissionBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaPermissionFilter';
	}
	

}

