package com.kaltura.client;

import java.util.ArrayList;

public class KalturaMultiResponse extends ArrayList<Object>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
