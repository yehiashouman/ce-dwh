<?php
abstract class Kaltura_Client_Type_NotificationBaseFilter extends Kaltura_Client_Type_BaseJobFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaNotificationBaseFilter';
	}
	

}

