<?php
class Kaltura_Client_Type_ITunesSyndicationFeedFilter extends Kaltura_Client_Type_ITunesSyndicationFeedBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaITunesSyndicationFeedFilter';
	}
	

}

