<?php
class Kaltura_Client_Enum_AssetParamsOutputOrderBy
{
}

