namespace Kaltura
{
	public sealed class KalturaDistributionProviderType : KalturaStringEnum
	{
		public static readonly KalturaDistributionProviderType GENERIC = new KalturaDistributionProviderType("1");
		public static readonly KalturaDistributionProviderType SYNDICATION = new KalturaDistributionProviderType("2");
		public static readonly KalturaDistributionProviderType MSN = new KalturaDistributionProviderType("msnDistribution.MSN");
		public static readonly KalturaDistributionProviderType HULU = new KalturaDistributionProviderType("huluDistribution.HULU");
		public static readonly KalturaDistributionProviderType COMCAST = new KalturaDistributionProviderType("comcastDistribution.COMCAST");
		public static readonly KalturaDistributionProviderType YOUTUBE = new KalturaDistributionProviderType("youTubeDistribution.YOUTUBE");
		public static readonly KalturaDistributionProviderType VERIZON = new KalturaDistributionProviderType("verizonDistribution.VERIZON");

		private KalturaDistributionProviderType(string name) : base(name) { }
	}
}
