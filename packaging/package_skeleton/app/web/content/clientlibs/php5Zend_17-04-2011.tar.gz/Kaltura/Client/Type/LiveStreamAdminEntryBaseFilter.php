<?php
abstract class Kaltura_Client_Type_LiveStreamAdminEntryBaseFilter extends Kaltura_Client_Type_LiveStreamEntryFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaLiveStreamAdminEntryBaseFilter';
	}
	

}

