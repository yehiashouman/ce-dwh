namespace Kaltura
{
	public enum KalturaVirusFoundAction
	{
		NONE = 0,
		DELETE = 1,
		CLEAN_NONE = 2,
		CLEAN_DELETE = 3,
	}
}
