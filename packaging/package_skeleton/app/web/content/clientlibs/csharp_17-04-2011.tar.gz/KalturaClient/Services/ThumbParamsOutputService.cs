using System;
using System.Xml;
using System.Collections.Generic;
using System.IO;

namespace Kaltura
{

	public class KalturaThumbParamsOutputService : KalturaServiceBase
	{
	public KalturaThumbParamsOutputService(KalturaClient client)
			: base(client)
		{
		}

		public KalturaThumbParamsOutputListResponse List()
		{
			return this.List(null);
		}

		public KalturaThumbParamsOutputListResponse List(KalturaThumbParamsOutputFilter filter)
		{
			return this.List(filter, null);
		}

		public KalturaThumbParamsOutputListResponse List(KalturaThumbParamsOutputFilter filter, KalturaFilterPager pager)
		{
			KalturaParams kparams = new KalturaParams();
			if (filter != null)
				kparams.Add("filter", filter.ToParams());
			if (pager != null)
				kparams.Add("pager", pager.ToParams());
			_Client.QueueServiceCall("adminconsole_thumbparamsoutput", "list", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaThumbParamsOutputListResponse)KalturaObjectFactory.Create(result);
		}
	}
}
