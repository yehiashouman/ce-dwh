namespace Kaltura
{
	public enum KalturaAuditTrailContext
	{
		CLIENT = -1,
		SCRIPT = 0,
		PS2 = 1,
		API_V3 = 2,
	}
}
