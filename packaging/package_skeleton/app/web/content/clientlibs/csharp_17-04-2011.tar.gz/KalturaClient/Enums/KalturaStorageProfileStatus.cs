namespace Kaltura
{
	public enum KalturaStorageProfileStatus
	{
		DISABLED = 1,
		AUTOMATIC = 2,
		MANUAL = 3,
	}
}
