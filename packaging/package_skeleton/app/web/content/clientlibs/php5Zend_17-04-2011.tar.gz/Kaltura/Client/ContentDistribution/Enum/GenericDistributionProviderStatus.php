<?php
class Kaltura_Client_ContentDistribution_Enum_GenericDistributionProviderStatus
{
	const ACTIVE = 2;
	const DELETED = 3;
}

