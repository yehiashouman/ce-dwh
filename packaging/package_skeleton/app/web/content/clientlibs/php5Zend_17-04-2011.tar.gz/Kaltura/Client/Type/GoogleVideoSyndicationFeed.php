<?php
class Kaltura_Client_Type_GoogleVideoSyndicationFeed extends Kaltura_Client_Type_BaseSyndicationFeed
{
	public function getKalturaObjectType()
	{
		return 'KalturaGoogleVideoSyndicationFeed';
	}
	
	/**
	 * 
	 *
	 * @var Kaltura_Client_Enum_GoogleSyndicationFeedAdultValues
	 */
	public $adultContent = null;


}

