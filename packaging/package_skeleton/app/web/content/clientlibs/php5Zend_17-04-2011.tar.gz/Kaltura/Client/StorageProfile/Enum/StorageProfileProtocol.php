<?php
class Kaltura_Client_StorageProfile_Enum_StorageProfileProtocol
{
	const KALTURA_DC = 0;
	const FTP = 1;
	const SCP = 2;
	const SFTP = 3;
}

