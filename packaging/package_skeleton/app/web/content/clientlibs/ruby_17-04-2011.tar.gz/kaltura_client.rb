require 'kaltura_client_base.rb'

module Kaltura

	class KalturaAccessControlOrderBy
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
	end

	class KalturaAdminUserOrderBy
		ID_ASC = "+id"
		ID_DESC = "-id"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
	end

	class KalturaAnnotationOrderBy
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
	end

	class KalturaApiActionPermissionItemOrderBy
		ID_ASC = "+id"
		ID_DESC = "-id"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
	end

	class KalturaApiParameterPermissionItemAction
		READ = "read"
		UPDATE = "update"
		INSERT = "insert"
	end

	class KalturaApiParameterPermissionItemOrderBy
		ID_ASC = "+id"
		ID_DESC = "-id"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
	end

	class KalturaAssetOrderBy
		SIZE_ASC = "+size"
		SIZE_DESC = "-size"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
		DELETED_AT_ASC = "+deletedAt"
		DELETED_AT_DESC = "-deletedAt"
	end

	class KalturaAssetParamsOrderBy
	end

	class KalturaAssetParamsOutputOrderBy
	end

	class KalturaAssetType
		FLAVOR = "1"
		THUMBNAIL = "2"
		DOCUMENT = "document.Document"
		SWF = "document.SWF"
		PDF = "document.PDF"
	end

	class KalturaAudioCodec
		NONE = ""
		MP3 = "mp3"
		AAC = "aac"
		VORBIS = "vorbis"
		WMA = "wma"
		COPY = "copy"
	end

	class KalturaAuditTrailAction
		CREATED = "CREATED"
		COPIED = "COPIED"
		CHANGED = "CHANGED"
		DELETED = "DELETED"
		VIEWED = "VIEWED"
		CONTENT_VIEWED = "CONTENT_VIEWED"
		FILE_SYNC_CREATED = "FILE_SYNC_CREATED"
		RELATION_ADDED = "RELATION_ADDED"
		RELATION_REMOVED = "RELATION_REMOVED"
	end

	class KalturaAuditTrailContext
		CLIENT = -1
		SCRIPT = 0
		PS2 = 1
		API_V3 = 2
	end

	class KalturaAuditTrailObjectType
		ACCESS_CONTROL = "accessControl"
		ADMIN_KUSER = "adminKuser"
		BATCH_JOB = "BatchJob"
		CATEGORY = "category"
		CONVERSION_PROFILE_2 = "conversionProfile2"
		EMAIL_INGESTION_PROFILE = "EmailIngestionProfile"
		ENTRY = "entry"
		FILE_SYNC = "FileSync"
		FLAVOR_ASSET = "flavorAsset"
		FLAVOR_PARAMS = "flavorParams"
		FLAVOR_PARAMS_CONVERSION_PROFILE = "flavorParamsConversionProfile"
		FLAVOR_PARAMS_OUTPUT = "flavorParamsOutput"
		KSHOW = "kshow"
		KSHOW_KUSER = "KshowKuser"
		KUSER = "kuser"
		MEDIA_INFO = "mediaInfo"
		MODERATION = "moderation"
		PARTNER = "Partner"
		ROUGHCUT = "roughcutEntry"
		SYNDICATION = "syndicationFeed"
		UI_CONF = "uiConf"
		UPLOAD_TOKEN = "UploadToken"
		WIDGET = "widget"
		METADATA = "Metadata"
		METADATA_PROFILE = "MetadataProfile"
		USER_LOGIN_DATA = "UserLoginData"
		USER_ROLE = "UserRole"
		PERMISSION = "Permission"
	end

	class KalturaAuditTrailOrderBy
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		PARSED_AT_ASC = "+parsedAt"
		PARSED_AT_DESC = "-parsedAt"
	end

	class KalturaAuditTrailStatus
		PENDING = 1
		READY = 2
		FAILED = 3
	end

	class KalturaBaseEntryOrderBy
		NAME_ASC = "+name"
		NAME_DESC = "-name"
		MODERATION_COUNT_ASC = "+moderationCount"
		MODERATION_COUNT_DESC = "-moderationCount"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
		RANK_ASC = "+rank"
		RANK_DESC = "-rank"
	end

	class KalturaBaseJobOrderBy
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
		PROCESSOR_EXPIRATION_ASC = "+processorExpiration"
		PROCESSOR_EXPIRATION_DESC = "-processorExpiration"
		EXECUTION_ATTEMPTS_ASC = "+executionAttempts"
		EXECUTION_ATTEMPTS_DESC = "-executionAttempts"
		LOCK_VERSION_ASC = "+lockVersion"
		LOCK_VERSION_DESC = "-lockVersion"
	end

	class KalturaBaseSyndicationFeedOrderBy
		PLAYLIST_ID_ASC = "+playlistId"
		PLAYLIST_ID_DESC = "-playlistId"
		NAME_ASC = "+name"
		NAME_DESC = "-name"
		TYPE_ASC = "+type"
		TYPE_DESC = "-type"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
	end

	class KalturaBatchJobErrorTypes
		APP = 0
		RUNTIME = 1
		HTTP = 2
		CURL = 3
		KALTURA_API = 4
		KALTURA_CLIENT = 5
	end

	class KalturaBatchJobOrderBy
		STATUS_ASC = "+status"
		STATUS_DESC = "-status"
		CHECK_AGAIN_TIMEOUT_ASC = "+checkAgainTimeout"
		CHECK_AGAIN_TIMEOUT_DESC = "-checkAgainTimeout"
		PROGRESS_ASC = "+progress"
		PROGRESS_DESC = "-progress"
		UPDATES_COUNT_ASC = "+updatesCount"
		UPDATES_COUNT_DESC = "-updatesCount"
		PRIORITY_ASC = "+priority"
		PRIORITY_DESC = "-priority"
		QUEUE_TIME_ASC = "+queueTime"
		QUEUE_TIME_DESC = "-queueTime"
		FINISH_TIME_ASC = "+finishTime"
		FINISH_TIME_DESC = "-finishTime"
		FILE_SIZE_ASC = "+fileSize"
		FILE_SIZE_DESC = "-fileSize"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
		PROCESSOR_EXPIRATION_ASC = "+processorExpiration"
		PROCESSOR_EXPIRATION_DESC = "-processorExpiration"
		EXECUTION_ATTEMPTS_ASC = "+executionAttempts"
		EXECUTION_ATTEMPTS_DESC = "-executionAttempts"
		LOCK_VERSION_ASC = "+lockVersion"
		LOCK_VERSION_DESC = "-lockVersion"
	end

	class KalturaBatchJobStatus
		PENDING = 0
		QUEUED = 1
		PROCESSING = 2
		PROCESSED = 3
		MOVEFILE = 4
		FINISHED = 5
		FAILED = 6
		ABORTED = 7
		ALMOST_DONE = 8
		RETRY = 9
		FATAL = 10
		DONT_PROCESS = 11
	end

	class KalturaBatchJobType
		CONVERT = "0"
		IMPORT = "1"
		DELETE = "2"
		FLATTEN = "3"
		BULKUPLOAD = "4"
		DVDCREATOR = "5"
		DOWNLOAD = "6"
		OOCONVERT = "7"
		CONVERT_PROFILE = "10"
		POSTCONVERT = "11"
		PULL = "12"
		REMOTE_CONVERT = "13"
		EXTRACT_MEDIA = "14"
		MAIL = "15"
		NOTIFICATION = "16"
		CLEANUP = "17"
		SCHEDULER_HELPER = "18"
		BULKDOWNLOAD = "19"
		DB_CLEANUP = "20"
		PROVISION_PROVIDE = "21"
		CONVERT_COLLECTION = "22"
		STORAGE_EXPORT = "23"
		PROVISION_DELETE = "24"
		STORAGE_DELETE = "25"
		EMAIL_INGESTION = "26"
		METADATA_IMPORT = "27"
		METADATA_TRANSFORM = "28"
		FILESYNC_IMPORT = "29"
		CAPTURE_THUMB = "30"
		VIRUS_SCAN = "virusScan.VirusScan"
		DISTRIBUTION_SUBMIT = "contentDistribution.DistributionSubmit"
		DISTRIBUTION_UPDATE = "contentDistribution.DistributionUpdate"
		DISTRIBUTION_DELETE = "contentDistribution.DistributionDelete"
		DISTRIBUTION_FETCH_REPORT = "contentDistribution.DistributionFetchReport"
		DISTRIBUTION_SYNC = "contentDistribution.DistributionSync"
	end

	class KalturaBitRateMode
		CBR = 1
		VBR = 2
	end

	class KalturaCategoryOrderBy
		DEPTH_ASC = "+depth"
		DEPTH_DESC = "-depth"
		FULL_NAME_ASC = "+fullName"
		FULL_NAME_DESC = "-fullName"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
	end

	class KalturaCommercialUseType
		COMMERCIAL_USE = 1
		NON_COMMERCIAL_USE = 0
	end

	class KalturaContainerFormat
		FLV = "flv"
		MP4 = "mp4"
		AVI = "avi"
		MOV = "mov"
		MP3 = "mp3"
		_3GP = "3gp"
		OGG = "ogg"
		WMV = "wmv"
		WMA = "wma"
		ISMV = "ismv"
		MKV = "mkv"
		WEBM = "webm"
		MPEG = "mpeg"
		MPEGTS = "mpegts"
		APPLEHTTP = "applehttp"
		SWF = "swf"
		PDF = "pdf"
		JPG = "jpg"
	end

	class KalturaControlPanelCommandOrderBy
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
	end

	class KalturaControlPanelCommandStatus
		PENDING = 1
		HANDLED = 2
		DONE = 3
		FAILED = 4
	end

	class KalturaControlPanelCommandTargetType
		DATA_CENTER = 1
		SCHEDULER = 2
		JOB_TYPE = 3
		JOB = 4
		BATCH = 5
	end

	class KalturaControlPanelCommandType
		STOP = 1
		START = 2
		CONFIG = 3
		KILL = 4
	end

	class KalturaConversionEngineType
		KALTURA_COM = "0"
		ON2 = "1"
		FFMPEG = "2"
		MENCODER = "3"
		ENCODING_COM = "4"
		EXPRESSION_ENCODER3 = "5"
		FFMPEG_VP8 = "98"
		FFMPEG_AUX = "99"
		PDF2SWF = "201"
		PDF_CREATOR = "202"
		QUICK_TIME_PLAYER_TOOLS = "quickTimeTools.QuickTimeTools"
		FAST_START = "fastStart.FastStart"
		EXPRESSION_ENCODER = "expressionEncoder.ExpressionEncoder"
		AVIDEMUX = "avidemux.Avidemux"
		SEGMENTER = "segmenter.Segmenter"
	end

	class KalturaConversionProfileOrderBy
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
	end

	class KalturaCountryRestrictionType
		RESTRICT_COUNTRY_LIST = 0
		ALLOW_COUNTRY_LIST = 1
	end

	class KalturaDataEntryOrderBy
		NAME_ASC = "+name"
		NAME_DESC = "-name"
		MODERATION_COUNT_ASC = "+moderationCount"
		MODERATION_COUNT_DESC = "-moderationCount"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
		RANK_ASC = "+rank"
		RANK_DESC = "-rank"
	end

	class KalturaDirectoryRestrictionType
		DONT_DISPLAY = 0
		DISPLAY_WITH_LINK = 1
	end

	class KalturaDistributionAction
		SUBMIT = 1
		UPDATE = 2
		DELETE = 3
		FETCH_REPORT = 4
	end

	class KalturaDistributionErrorType
		MISSING_FLAVOR = 1
		MISSING_THUMBNAIL = 2
		MISSING_METADATA = 3
		INVALID_DATA = 4
	end

	class KalturaDistributionProfileActionStatus
		DISABLED = 1
		AUTOMATIC = 2
		MANUAL = 3
	end

	class KalturaDistributionProfileOrderBy
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
	end

	class KalturaDistributionProfileStatus
		DISABLED = 1
		ENABLED = 2
		DELETED = 3
	end

	class KalturaDistributionProtocol
		FTP = 1
		SCP = 2
		SFTP = 3
		HTTP = 4
		HTTPS = 5
	end

	class KalturaDistributionProviderOrderBy
	end

	class KalturaDistributionProviderType
		GENERIC = "1"
		SYNDICATION = "2"
		MSN = "msnDistribution.MSN"
		HULU = "huluDistribution.HULU"
		COMCAST = "comcastDistribution.COMCAST"
		YOUTUBE = "youTubeDistribution.YOUTUBE"
		VERIZON = "verizonDistribution.VERIZON"
	end

	class KalturaDocumentEntryOrderBy
		NAME_ASC = "+name"
		NAME_DESC = "-name"
		MODERATION_COUNT_ASC = "+moderationCount"
		MODERATION_COUNT_DESC = "-moderationCount"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
		RANK_ASC = "+rank"
		RANK_DESC = "-rank"
	end

	class KalturaDocumentType
		DOCUMENT = 11
		SWF = 12
		PDF = 13
	end

	class KalturaDurationType
		NOT_AVAILABLE = "notavailable"
		SHORT = "short"
		MEDIUM = "medium"
		LONG = "long"
	end

	class KalturaEditorType
		SIMPLE = 1
		ADVANCED = 2
	end

	class KalturaEmailIngestionProfileStatus
		INACTIVE = 0
		ACTIVE = 1
	end

	class KalturaEntryDistributionFlag
		NONE = 0
		SUBMIT_REQUIRED = 1
		DELETE_REQUIRED = 2
		UPDATE_REQUIRED = 3
	end

	class KalturaEntryDistributionOrderBy
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
		SUBMITTED_AT_ASC = "+submittedAt"
		SUBMITTED_AT_DESC = "-submittedAt"
		SUNRISE_ASC = "+sunrise"
		SUNRISE_DESC = "-sunrise"
		SUNSET_ASC = "+sunset"
		SUNSET_DESC = "-sunset"
	end

	class KalturaEntryDistributionStatus
		PENDING = 0
		QUEUED = 1
		READY = 2
		DELETED = 3
		SUBMITTING = 4
		UPDATING = 5
		DELETING = 6
		ERROR_SUBMITTING = 7
		ERROR_UPDATING = 8
		ERROR_DELETING = 9
		REMOVED = 10
	end

	class KalturaEntryModerationStatus
		PENDING_MODERATION = 1
		APPROVED = 2
		REJECTED = 3
		FLAGGED_FOR_REVIEW = 5
		AUTO_APPROVED = 6
	end

	class KalturaEntryStatus
		ERROR_IMPORTING = "-2"
		ERROR_CONVERTING = "-1"
		IMPORT = "0"
		PRECONVERT = "1"
		READY = "2"
		DELETED = "3"
		PENDING = "4"
		MODERATE = "5"
		BLOCKED = "6"
		INFECTED = "virusScan.Infected"
	end

	class KalturaEntryType
		AUTOMATIC = "-1"
		MEDIA_CLIP = "1"
		MIX = "2"
		PLAYLIST = "5"
		DATA = "6"
		LIVE_STREAM = "7"
		DOCUMENT = "10"
	end

	class KalturaFileSyncObjectType
		ENTRY = "1"
		UICONF = "2"
		BATCHJOB = "3"
		FLAVOR_ASSET = "4"
		METADATA = "5"
		METADATA_PROFILE = "6"
		SYNDICATION_FEED = "7"
		GENERIC_DISTRIBUTION_ACTION = "contentDistribution.GenericDistributionAction"
		ENTRY_DISTRIBUTION = "contentDistribution.EntryDistribution"
		DISTRIBUTION_PROFILE = "contentDistribution.DistributionProfile"
	end

	class KalturaFlavorAssetOrderBy
		SIZE_ASC = "+size"
		SIZE_DESC = "-size"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
		DELETED_AT_ASC = "+deletedAt"
		DELETED_AT_DESC = "-deletedAt"
	end

	class KalturaFlavorAssetStatus
		ERROR = -1
		QUEUED = 0
		CONVERTING = 1
		READY = 2
		DELETED = 3
		NOT_APPLICABLE = 4
		TEMP = 5
	end

	class KalturaFlavorParamsOrderBy
	end

	class KalturaFlavorParamsOutputOrderBy
	end

	class KalturaGender
		UNKNOWN = 0
		MALE = 1
		FEMALE = 2
	end

	class KalturaGenericDistributionProviderActionOrderBy
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
	end

	class KalturaGenericDistributionProviderOrderBy
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
	end

	class KalturaGenericDistributionProviderParser
		XSL = 1
		XPATH = 2
		REGEX = 3
	end

	class KalturaGenericDistributionProviderStatus
		ACTIVE = 2
		DELETED = 3
	end

	class KalturaGenericSyndicationFeedOrderBy
		PLAYLIST_ID_ASC = "+playlistId"
		PLAYLIST_ID_DESC = "-playlistId"
		NAME_ASC = "+name"
		NAME_DESC = "-name"
		TYPE_ASC = "+type"
		TYPE_DESC = "-type"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
	end

	class KalturaGenericXsltSyndicationFeedOrderBy
		PLAYLIST_ID_ASC = "+playlistId"
		PLAYLIST_ID_DESC = "-playlistId"
		NAME_ASC = "+name"
		NAME_DESC = "-name"
		TYPE_ASC = "+type"
		TYPE_DESC = "-type"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
	end

	class KalturaGoogleSyndicationFeedAdultValues
		YES = "Yes"
		NO = "No"
	end

	class KalturaGoogleVideoSyndicationFeedOrderBy
		PLAYLIST_ID_ASC = "+playlistId"
		PLAYLIST_ID_DESC = "-playlistId"
		NAME_ASC = "+name"
		NAME_DESC = "-name"
		TYPE_ASC = "+type"
		TYPE_DESC = "-type"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
	end

	class KalturaITunesSyndicationFeedAdultValues
		YES = "yes"
		NO = "no"
		CLEAN = "clean"
	end

	class KalturaITunesSyndicationFeedCategories
		ARTS = "Arts"
		ARTS_DESIGN = "Arts/Design"
		ARTS_FASHION_BEAUTY = "Arts/Fashion &amp; Beauty"
		ARTS_FOOD = "Arts/Food"
		ARTS_LITERATURE = "Arts/Literature"
		ARTS_PERFORMING_ARTS = "Arts/Performing Arts"
		ARTS_VISUAL_ARTS = "Arts/Visual Arts"
		BUSINESS = "Business"
		BUSINESS_BUSINESS_NEWS = "Business/Business News"
		BUSINESS_CAREERS = "Business/Careers"
		BUSINESS_INVESTING = "Business/Investing"
		BUSINESS_MANAGEMENT_MARKETING = "Business/Management &amp; Marketing"
		BUSINESS_SHOPPING = "Business/Shopping"
		COMEDY = "Comedy"
		EDUCATION = "Education"
		EDUCATION_TECHNOLOGY = "Education/Education Technology"
		EDUCATION_HIGHER_EDUCATION = "Education/Higher Education"
		EDUCATION_K_12 = "Education/K-12"
		EDUCATION_LANGUAGE_COURSES = "Education/Language Courses"
		EDUCATION_TRAINING = "Education/Training"
		GAMES_HOBBIES = "Games &amp; Hobbies"
		GAMES_HOBBIES_AUTOMOTIVE = "Games &amp; Hobbies/Automotive"
		GAMES_HOBBIES_AVIATION = "Games &amp; Hobbies/Aviation"
		GAMES_HOBBIES_HOBBIES = "Games &amp; Hobbies/Hobbies"
		GAMES_HOBBIES_OTHER_GAMES = "Games &amp; Hobbies/Other Games"
		GAMES_HOBBIES_VIDEO_GAMES = "Games &amp; Hobbies/Video Games"
		GOVERNMENT_ORGANIZATIONS = "Government &amp; Organizations"
		GOVERNMENT_ORGANIZATIONS_LOCAL = "Government &amp; Organizations/Local"
		GOVERNMENT_ORGANIZATIONS_NATIONAL = "Government &amp; Organizations/National"
		GOVERNMENT_ORGANIZATIONS_NON_PROFIT = "Government &amp; Organizations/Non-Profit"
		GOVERNMENT_ORGANIZATIONS_REGIONAL = "Government &amp; Organizations/Regional"
		HEALTH = "Health"
		HEALTH_ALTERNATIVE_HEALTH = "Health/Alternative Health"
		HEALTH_FITNESS_NUTRITION = "Health/Fitness &amp; Nutrition"
		HEALTH_SELF_HELP = "Health/Self-Help"
		HEALTH_SEXUALITY = "Health/Sexuality"
		KIDS_FAMILY = "Kids &amp; Family"
		MUSIC = "Music"
		NEWS_POLITICS = "News &amp; Politics"
		RELIGION_SPIRITUALITY = "Religion &amp; Spirituality"
		RELIGION_SPIRITUALITY_BUDDHISM = "Religion &amp; Spirituality/Buddhism"
		RELIGION_SPIRITUALITY_CHRISTIANITY = "Religion &amp; Spirituality/Christianity"
		RELIGION_SPIRITUALITY_HINDUISM = "Religion &amp; Spirituality/Hinduism"
		RELIGION_SPIRITUALITY_ISLAM = "Religion &amp; Spirituality/Islam"
		RELIGION_SPIRITUALITY_JUDAISM = "Religion &amp; Spirituality/Judaism"
		RELIGION_SPIRITUALITY_OTHER = "Religion &amp; Spirituality/Other"
		RELIGION_SPIRITUALITY_SPIRITUALITY = "Religion &amp; Spirituality/Spirituality"
		SCIENCE_MEDICINE = "Science &amp; Medicine"
		SCIENCE_MEDICINE_MEDICINE = "Science &amp; Medicine/Medicine"
		SCIENCE_MEDICINE_NATURAL_SCIENCES = "Science &amp; Medicine/Natural Sciences"
		SCIENCE_MEDICINE_SOCIAL_SCIENCES = "Science &amp; Medicine/Social Sciences"
		SOCIETY_CULTURE = "Society &amp; Culture"
		SOCIETY_CULTURE_HISTORY = "Society &amp; Culture/History"
		SOCIETY_CULTURE_PERSONAL_JOURNALS = "Society &amp; Culture/Personal Journals"
		SOCIETY_CULTURE_PHILOSOPHY = "Society &amp; Culture/Philosophy"
		SOCIETY_CULTURE_PLACES_TRAVEL = "Society &amp; Culture/Places &amp; Travel"
		SPORTS_RECREATION = "Sports &amp; Recreation"
		SPORTS_RECREATION_AMATEUR = "Sports &amp; Recreation/Amateur"
		SPORTS_RECREATION_COLLEGE_HIGH_SCHOOL = "Sports &amp; Recreation/College &amp; High School"
		SPORTS_RECREATION_OUTDOOR = "Sports &amp; Recreation/Outdoor"
		SPORTS_RECREATION_PROFESSIONAL = "Sports &amp; Recreation/Professional"
		TECHNOLOGY = "Technology"
		TECHNOLOGY_GADGETS = "Technology/Gadgets"
		TECHNOLOGY_TECH_NEWS = "Technology/Tech News"
		TECHNOLOGY_PODCASTING = "Technology/Podcasting"
		TECHNOLOGY_SOFTWARE_HOW_TO = "Technology/Software How-To"
		TV_FILM = "TV &amp; Film"
	end

	class KalturaITunesSyndicationFeedOrderBy
		PLAYLIST_ID_ASC = "+playlistId"
		PLAYLIST_ID_DESC = "-playlistId"
		NAME_ASC = "+name"
		NAME_DESC = "-name"
		TYPE_ASC = "+type"
		TYPE_DESC = "-type"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
	end

	class KalturaIpAddressRestrictionType
		RESTRICT_LIST = 0
		ALLOW_LIST = 1
	end

	class KalturaLicenseType
		UNKNOWN = -1
		NONE = 0
		COPYRIGHTED = 1
		PUBLIC_DOMAIN = 2
		CREATIVECOMMONS_ATTRIBUTION = 3
		CREATIVECOMMONS_ATTRIBUTION_SHARE_ALIKE = 4
		CREATIVECOMMONS_ATTRIBUTION_NO_DERIVATIVES = 5
		CREATIVECOMMONS_ATTRIBUTION_NON_COMMERCIAL = 6
		CREATIVECOMMONS_ATTRIBUTION_NON_COMMERCIAL_SHARE_ALIKE = 7
		CREATIVECOMMONS_ATTRIBUTION_NON_COMMERCIAL_NO_DERIVATIVES = 8
		GFDL = 9
		GPL = 10
		AFFERO_GPL = 11
		LGPL = 12
		BSD = 13
		APACHE = 14
		MOZILLA = 15
	end

	class KalturaLiveStreamAdminEntryOrderBy
		MEDIA_TYPE_ASC = "+mediaType"
		MEDIA_TYPE_DESC = "-mediaType"
		PLAYS_ASC = "+plays"
		PLAYS_DESC = "-plays"
		VIEWS_ASC = "+views"
		VIEWS_DESC = "-views"
		DURATION_ASC = "+duration"
		DURATION_DESC = "-duration"
		MS_DURATION_ASC = "+msDuration"
		MS_DURATION_DESC = "-msDuration"
		NAME_ASC = "+name"
		NAME_DESC = "-name"
		MODERATION_COUNT_ASC = "+moderationCount"
		MODERATION_COUNT_DESC = "-moderationCount"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
		RANK_ASC = "+rank"
		RANK_DESC = "-rank"
	end

	class KalturaLiveStreamEntryOrderBy
		MEDIA_TYPE_ASC = "+mediaType"
		MEDIA_TYPE_DESC = "-mediaType"
		PLAYS_ASC = "+plays"
		PLAYS_DESC = "-plays"
		VIEWS_ASC = "+views"
		VIEWS_DESC = "-views"
		DURATION_ASC = "+duration"
		DURATION_DESC = "-duration"
		MS_DURATION_ASC = "+msDuration"
		MS_DURATION_DESC = "-msDuration"
		NAME_ASC = "+name"
		NAME_DESC = "-name"
		MODERATION_COUNT_ASC = "+moderationCount"
		MODERATION_COUNT_DESC = "-moderationCount"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
		RANK_ASC = "+rank"
		RANK_DESC = "-rank"
	end

	class KalturaMailJobOrderBy
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
		PROCESSOR_EXPIRATION_ASC = "+processorExpiration"
		PROCESSOR_EXPIRATION_DESC = "-processorExpiration"
		EXECUTION_ATTEMPTS_ASC = "+executionAttempts"
		EXECUTION_ATTEMPTS_DESC = "-executionAttempts"
		LOCK_VERSION_ASC = "+lockVersion"
		LOCK_VERSION_DESC = "-lockVersion"
	end

	class KalturaMediaEntryOrderBy
		MEDIA_TYPE_ASC = "+mediaType"
		MEDIA_TYPE_DESC = "-mediaType"
		PLAYS_ASC = "+plays"
		PLAYS_DESC = "-plays"
		VIEWS_ASC = "+views"
		VIEWS_DESC = "-views"
		DURATION_ASC = "+duration"
		DURATION_DESC = "-duration"
		MS_DURATION_ASC = "+msDuration"
		MS_DURATION_DESC = "-msDuration"
		NAME_ASC = "+name"
		NAME_DESC = "-name"
		MODERATION_COUNT_ASC = "+moderationCount"
		MODERATION_COUNT_DESC = "-moderationCount"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
		RANK_ASC = "+rank"
		RANK_DESC = "-rank"
	end

	class KalturaMediaFlavorParamsOrderBy
	end

	class KalturaMediaFlavorParamsOutputOrderBy
	end

	class KalturaMediaInfoOrderBy
	end

	class KalturaMediaType
		VIDEO = 1
		IMAGE = 2
		AUDIO = 5
		LIVE_STREAM_FLASH = 201
		LIVE_STREAM_WINDOWS_MEDIA = 202
		LIVE_STREAM_REAL_MEDIA = 203
		LIVE_STREAM_QUICKTIME = 204
	end

	class KalturaMetadataObjectType
		ENTRY = 1
	end

	class KalturaMetadataOrderBy
		METADATA_PROFILE_VERSION_ASC = "+metadataProfileVersion"
		METADATA_PROFILE_VERSION_DESC = "-metadataProfileVersion"
		VERSION_ASC = "+version"
		VERSION_DESC = "-version"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
	end

	class KalturaMetadataProfileOrderBy
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
	end

	class KalturaMetadataProfileStatus
		ACTIVE = 1
		DEPRECATED = 2
		TRANSFORMING = 3
	end

	class KalturaMetadataStatus
		VALID = 1
		INVALID = 2
		DELETED = 3
	end

	class KalturaMixEntryOrderBy
		PLAYS_ASC = "+plays"
		PLAYS_DESC = "-plays"
		VIEWS_ASC = "+views"
		VIEWS_DESC = "-views"
		DURATION_ASC = "+duration"
		DURATION_DESC = "-duration"
		MS_DURATION_ASC = "+msDuration"
		MS_DURATION_DESC = "-msDuration"
		NAME_ASC = "+name"
		NAME_DESC = "-name"
		MODERATION_COUNT_ASC = "+moderationCount"
		MODERATION_COUNT_DESC = "-moderationCount"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
		RANK_ASC = "+rank"
		RANK_DESC = "-rank"
	end

	class KalturaModerationFlagStatus
		PENDING = 1
		MODERATED = 2
	end

	class KalturaModerationFlagType
		SEXUAL_CONTENT = 1
		VIOLENT_REPULSIVE = 2
		HARMFUL_DANGEROUS = 3
		SPAM_COMMERCIALS = 4
	end

	class KalturaModerationObjectType
		ENTRY = 2
		USER = 3
	end

	class KalturaNotificationOrderBy
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
		PROCESSOR_EXPIRATION_ASC = "+processorExpiration"
		PROCESSOR_EXPIRATION_DESC = "-processorExpiration"
		EXECUTION_ATTEMPTS_ASC = "+executionAttempts"
		EXECUTION_ATTEMPTS_DESC = "-executionAttempts"
		LOCK_VERSION_ASC = "+lockVersion"
		LOCK_VERSION_DESC = "-lockVersion"
	end

	class KalturaNotificationType
		ENTRY_ADD = 1
		ENTR_UPDATE_PERMISSIONS = 2
		ENTRY_DELETE = 3
		ENTRY_BLOCK = 4
		ENTRY_UPDATE = 5
		ENTRY_UPDATE_THUMBNAIL = 6
		ENTRY_UPDATE_MODERATION = 7
		USER_ADD = 21
		USER_BANNED = 26
	end

	class KalturaNullableBoolean
		NULL_VALUE = -1
		FALSE_VALUE = 0
		TRUE_VALUE = 1
	end

	class KalturaPartnerOrderBy
		ID_ASC = "+id"
		ID_DESC = "-id"
		NAME_ASC = "+name"
		NAME_DESC = "-name"
		WEBSITE_ASC = "+website"
		WEBSITE_DESC = "-website"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		ADMIN_NAME_ASC = "+adminName"
		ADMIN_NAME_DESC = "-adminName"
		ADMIN_EMAIL_ASC = "+adminEmail"
		ADMIN_EMAIL_DESC = "-adminEmail"
		STATUS_ASC = "+status"
		STATUS_DESC = "-status"
	end

	class KalturaPartnerStatus
		ACTIVE = 1
		BLOCKED = 2
		FULL_BLOCK = 3
	end

	class KalturaPartnerType
		KMC = 1
		WIKI = 100
		WORDPRESS = 101
		DRUPAL = 102
		DEKIWIKI = 103
		MOODLE = 104
		COMMUNITY_EDITION = 105
		JOOMLA = 106
		BLACKBOARD = 107
		SAKAI = 108
	end

	class KalturaPermissionItemOrderBy
		ID_ASC = "+id"
		ID_DESC = "-id"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
	end

	class KalturaPermissionItemType
		API_ACTION_ITEM = "kApiActionPermissionItem"
		API_PARAMETER_ITEM = "kApiParameterPermissionItem"
	end

	class KalturaPermissionName
		FEATURE_ANALYTICS_TAB = "FEATURE_ANALYTICS_TAB"
		FEATURE_508_PLAYERS = "FEATURE_508_PLAYERS"
		FEATURE_LIVE_STREAM = "FEATURE_LIVE_STREAM"
		FEATURE_VAST = "FEATURE_VAST"
		FEATURE_SILVERLIGHT = "FEATURE_SILVERLIGHT"
		FEATURE_PS2_PERMISSIONS_VALIDATION = "FEATURE_PS2_PERMISSIONS_VALIDATION"
		FEATURE_MOBILE_FLAVORS = "FEATURE_MOBILE_FLAVORS"
		USER_SESSION_PERMISSION = "BASE_USER_SESSION_PERMISSION"
		ALWAYS_ALLOWED_ACTIONS = "ALWAYS_ALLOWED_ACTIONS"
		SYSTEM_FILESYNC = "SYSTEM_FILESYNC"
		SYSTEM_INTERNAL = "SYSTEM_INTERNAL"
		KMC_ACCESS = "KMC_ACCESS"
		KMC_READ_ONLY = "KMC_READ_ONLY"
		SYSTEM_ADMIN_BASE = "SYSTEM_ADMIN_BASE"
		SYSTEM_ADMIN_PUBLISHER_BASE = "SYSTEM_ADMIN_PUBLISHER_BASE"
		SYSTEM_ADMIN_PUBLISHER_KMC_ACCESS = "SYSTEM_ADMIN_PUBLISHER_KMC_ACCESS"
		SYSTEM_ADMIN_PUBLISHER_CONFIG = "SYSTEM_ADMIN_PUBLISHER_CONFIG"
		SYSTEM_ADMIN_PUBLISHER_BLOCK = "SYSTEM_ADMIN_PUBLISHER_BLOCK"
		SYSTEM_ADMIN_PUBLISHER_REMOVE = "SYSTEM_ADMIN_PUBLISHER_REMOVE"
		SYSTEM_ADMIN_PUBLISHER_ADD = "SYSTEM_ADMIN_PUBLISHER_ADD"
		SYSTEM_ADMIN_PUBLISHER_USAGE = "SYSTEM_ADMIN_PUBLISHER_USAGE"
		SYSTEM_ADMIN_USER_MANAGE = "SYSTEM_ADMIN_USER_MANAGE"
		SYSTEM_ADMIN_SYSTEM_MONITOR = "SYSTEM_ADMIN_SYSTEM_MONITOR"
		SYSTEM_ADMIN_DEVELOPERS_TAB = "SYSTEM_ADMIN_DEVELOPERS_TAB"
		SYSTEM_ADMIN_BATCH_CONTROL = "SYSTEM_ADMIN_BATCH_CONTROL"
		SYSTEM_ADMIN_BATCH_CONTROL_INPROGRESS = "SYSTEM_ADMIN_BATCH_CONTROL_INPROGRESS"
		SYSTEM_ADMIN_BATCH_CONTROL_FAILED = "SYSTEM_ADMIN_BATCH_CONTROL_FAILED"
		SYSTEM_ADMIN_BATCH_CONTROL_SETUP = "SYSTEM_ADMIN_BATCH_CONTROL_SETUP"
		SYSTEM_ADMIN_STORAGE = "SYSTEM_ADMIN_STORAGE"
		SYSTEM_ADMIN_VIRUS_SCAN = "SYSTEM_ADMIN_VIRUS_SCAN"
		SYSTEM_ADMIN_EMAIL_INGESTION = "SYSTEM_ADMIN_EMAIL_INGESTION"
		SYSTEM_ADMIN_CONTENT_DISTRIBUTION_BASE = "SYSTEM_ADMIN_CONTENT_DISTRIBUTION_BASE"
		SYSTEM_ADMIN_CONTENT_DISTRIBUTION_MODIFY = "SYSTEM_ADMIN_CONTENT_DISTRIBUTION_MODIFY"
		SYSTEM_ADMIN_PERMISSIONS_MANAGE = "SYSTEM_ADMIN_PERMISSIONS_MANAGE"
		SYSTEM_ADMIN_ENTRY_INVESTIGATION = "SYSTEM_ADMIN_ENTRY_INVESTIGATION"
		BATCH_BASE = "BATCH_BASE"
		CONTENT_INGEST_UPLOAD = "CONTENT_INGEST_UPLOAD"
		CONTENT_INGEST_BULK_UPLOAD = "CONTENT_INGEST_BULK_UPLOAD"
		CONTENT_INGEST_FEED = "CONTENT_INGEST_FEED"
		CONTENT_MANAGE_DISTRIBUTION_BASE = "CONTENT_MANAGE_DISTRIBUTION_BASE"
		CONTENT_MANAGE_DISTRIBUTION_WHERE = "CONTENT_MANAGE_DISTRIBUTION_WHERE"
		CONTENT_MANAGE_DISTRIBUTION_SEND = "CONTENT_MANAGE_DISTRIBUTION_SEND"
		CONTENT_MANAGE_DISTRIBUTION_REMOVE = "CONTENT_MANAGE_DISTRIBUTION_REMOVE"
		CONTENT_MANAGE_DISTRIBUTION_PROFILE_MODIFY = "CONTENT_MANAGE_DISTRIBUTION_PROFILE_MODIFY"
		CONTENT_MANAGE_VIRUS_SCAN = "CONTENT_MANAGE_VIRUS_SCAN"
		CONTENT_MANAGE_MIX = "CONTENT_MANAGE_MIX"
		CONTENT_MANAGE_BASE = "CONTENT_MANAGE_BASE"
		CONTENT_MANAGE_METADATA = "CONTENT_MANAGE_METADATA"
		CONTENT_MANAGE_ASSIGN_CATEGORIES = "CONTENT_MANAGE_ASSIGN_CATEGORIES"
		CONTENT_MANAGE_THUMBNAIL = "CONTENT_MANAGE_THUMBNAIL"
		CONTENT_MANAGE_SCHEDULE = "CONTENT_MANAGE_SCHEDULE"
		CONTENT_MANAGE_ACCESS_CONTROL = "CONTENT_MANAGE_ACCESS_CONTROL"
		CONTENT_MANAGE_CUSTOM_DATA = "CONTENT_MANAGE_CUSTOM_DATA"
		CONTENT_MANAGE_DELETE = "CONTENT_MANAGE_DELETE"
		CONTENT_MANAGE_RECONVERT = "CONTENT_MANAGE_RECONVERT"
		CONTENT_MANAGE_EDIT_CATEGORIES = "CONTENT_MANAGE_EDIT_CATEGORIES"
		CONTENT_MANAGE_ANNOTATION = "CONTENT_MANAGE_ANNOTATION"
		CONTENT_MANAGE_SHARE = "CONTENT_MANAGE_SHARE"
		CONTENT_MANAGE_DOWNLOAD = "CONTENT_MANAGE_DOWNLOAD"
		LIVE_STREAM_ADD = "LIVE_STREAM_ADD"
		LIVE_STREAM_UPDATE = "LIVE_STREAM_UPDATE"
		CONTENT_MODERATE_BASE = "CONTENT_MODERATE_BASE"
		CONTENT_MODERATE_METADATA = "CONTENT_MODERATE_METADATA"
		CONTENT_MODERATE_CUSTOM_DATA = "CONTENT_MODERATE_CUSTOM_DATA"
		CONTENT_MODERATE_APPROVE_REJECT = "CONTENT_MODERATE_APPROVE_REJECT"
		PLAYLIST_BASE = "PLAYLIST_BASE"
		PLAYLIST_ADD = "PLAYLIST_ADD"
		PLAYLIST_UPDATE = "PLAYLIST_UPDATE"
		PLAYLIST_DELETE = "PLAYLIST_DELETE"
		SYNDICATION_BASE = "SYNDICATION_BASE"
		SYNDICATION_ADD = "SYNDICATION_ADD"
		SYNDICATION_UPDATE = "SYNDICATION_UPDATE"
		SYNDICATION_DELETE = "SYNDICATION_DELETE"
		STUDIO_BASE = "STUDIO_BASE"
		STUDIO_ADD_UICONF = "STUDIO_ADD_UICONF"
		STUDIO_UPDATE_UICONF = "STUDIO_UPDATE_UICONF"
		STUDIO_DELETE_UICONF = "STUDIO_DELETE_UICONF"
		ACCOUNT_BASE = "ACCOUNT_BASE"
		ACCOUNT_UPDATE_SETTINGS = "ACCOUNT_UPDATE_SETTINGS"
		INTEGRATION_BASE = "INTEGRATION_BASE"
		INTEGRATION_UPDATE_SETTINGS = "INTEGRATION_UPDATE_SETTINGS"
		ACCESS_CONTROL_BASE = "ACCESS_CONTROL_BASE"
		ACCESS_CONTROL_ADD = "ACCESS_CONTROL_ADD"
		ACCESS_CONTROL_UPDATE = "ACCESS_CONTROL_UPDATE"
		ACCESS_CONTROL_DELETE = "ACCESS_CONTROL_DELETE"
		TRANSCODING_BASE = "TRANSCODING_BASE"
		TRANSCODING_ADD = "TRANSCODING_ADD"
		TRANSCODING_UPDATE = "TRANSCODING_UPDATE"
		TRANSCODING_DELETE = "TRANSCODING_DELETE"
		CUSTOM_DATA_PROFILE_BASE = "CUSTOM_DATA_PROFILE_BASE"
		CUSTOM_DATA_PROFILE_ADD = "CUSTOM_DATA_PROFILE_ADD"
		CUSTOM_DATA_PROFILE_UPDATE = "CUSTOM_DATA_PROFILE_UPDATE"
		CUSTOM_DATA_PROFILE_DELETE = "CUSTOM_DATA_PROFILE_DELETE"
		CUSTOM_DATA_FIELD_ADD = "CUSTOM_DATA_FIELD_ADD"
		CUSTOM_DATA_FIELD_UPDATE = "CUSTOM_DATA_FIELD_UPDATE"
		CUSTOM_DATA_FIELD_DELETE = "CUSTOM_DATA_FIELD_DELETE"
		ADMIN_BASE = "ADMIN_BASE"
		ADMIN_USER_ADD = "ADMIN_USER_ADD"
		ADMIN_USER_UPDATE = "ADMIN_USER_UPDATE"
		ADMIN_USER_DELETE = "ADMIN_USER_DELETE"
		ADMIN_ROLE_ADD = "ADMIN_ROLE_ADD"
		ADMIN_ROLE_UPDATE = "ADMIN_ROLE_UPDATE"
		ADMIN_ROLE_DELETE = "ADMIN_ROLE_DELETE"
		ADMIN_PERMISSION_ADD = "ADMIN_PERMISSION_ADD"
		ADMIN_PERMISSION_UPDATE = "ADMIN_PERMISSION_UPDATE"
		ADMIN_PERMISSION_DELETE = "ADMIN_PERMISSION_DELETE"
		ADMIN_PUBLISHER_MANAGE = "ADMIN_PUBLISHER_MANAGE"
		ANALYTICS_BASE = "ANALYTICS_BASE"
		WIDGET_ADMIN = "WIDGET_ADMIN"
		SEARCH_SERVICE = "SEARCH_SERVICE"
		ANALYTICS_SEND_DATA = "ANALYTICS_SEND_DATA"
		AUDIT_TRAIL_BASE = "AUDIT_TRAIL_BASE"
		AUDIT_TRAIL_ADD = "AUDIT_TRAIL_ADD"
		ADVERTISING_BASE = "ADVERTISING_BASE"
		ADVERTISING_UPDATE_SETTINGS = "ADVERTISING_UPDATE_SETTINGS"
		PLAYLIST_EMBED_CODE = "PLAYLIST_EMBED_CODE"
		STUDIO_BRAND_UICONF = "STUDIO_BRAND_UICONF"
		STUDIO_SELECT_CONTENT = "STUDIO_SELECT_CONTENT"
		CONTENT_MANAGE_EMBED_CODE = "CONTENT_MANAGE_EMBED_CODE"
		ADMIN_WHITE_BRANDING = "ADMIN_WHITE_BRANDING"
	end

	class KalturaPermissionOrderBy
		ID_ASC = "+id"
		ID_DESC = "-id"
		NAME_ASC = "+name"
		NAME_DESC = "-name"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
	end

	class KalturaPermissionStatus
		ACTIVE = 1
		BLOCKED = 2
		DELETED = 3
	end

	class KalturaPermissionType
		NORMAL = 1
		SPECIAL_FEATURE = 2
		PLUGIN = 3
		PARTNER_GROUP = 4
	end

	class KalturaPlayableEntryOrderBy
		PLAYS_ASC = "+plays"
		PLAYS_DESC = "-plays"
		VIEWS_ASC = "+views"
		VIEWS_DESC = "-views"
		DURATION_ASC = "+duration"
		DURATION_DESC = "-duration"
		MS_DURATION_ASC = "+msDuration"
		MS_DURATION_DESC = "-msDuration"
		NAME_ASC = "+name"
		NAME_DESC = "-name"
		MODERATION_COUNT_ASC = "+moderationCount"
		MODERATION_COUNT_DESC = "-moderationCount"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
		RANK_ASC = "+rank"
		RANK_DESC = "-rank"
	end

	class KalturaPlaylistOrderBy
		NAME_ASC = "+name"
		NAME_DESC = "-name"
		MODERATION_COUNT_ASC = "+moderationCount"
		MODERATION_COUNT_DESC = "-moderationCount"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
		RANK_ASC = "+rank"
		RANK_DESC = "-rank"
	end

	class KalturaPlaylistType
		DYNAMIC = 10
		STATIC_LIST = 3
		EXTERNAL = 101
	end

	class KalturaReportType
		TOP_CONTENT = 1
		CONTENT_DROPOFF = 2
		CONTENT_INTERACTIONS = 3
		MAP_OVERLAY = 4
		TOP_CONTRIBUTORS = 5
		TOP_SYNDICATION = 6
		CONTENT_CONTRIBUTIONS = 7
	end

	class KalturaSearchConditionComparison
		EQUEL = 1
		GREATER_THAN = 2
		GREATER_THAN_OR_EQUEL = 3
		LESS_THAN = 4
		LESS_THAN_OR_EQUEL = 5
	end

	class KalturaSearchOperatorType
		SEARCH_AND = 1
		SEARCH_OR = 2
	end

	class KalturaSearchProviderType
		FLICKR = 3
		YOUTUBE = 4
		MYSPACE = 7
		PHOTOBUCKET = 8
		JAMENDO = 9
		CCMIXTER = 10
		NYPL = 11
		CURRENT = 12
		MEDIA_COMMONS = 13
		KALTURA = 20
		KALTURA_USER_CLIPS = 21
		ARCHIVE_ORG = 22
		KALTURA_PARTNER = 23
		METACAFE = 24
		SEARCH_PROXY = 28
		PARTNER_SPECIFIC = 100
	end

	class KalturaSessionType
		USER = 0
		ADMIN = 2
	end

	class KalturaShortLinkOrderBy
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
		EXPIRES_AT_ASC = "+expiresAt"
		EXPIRES_AT_DESC = "-expiresAt"
	end

	class KalturaShortLinkStatus
		DISABLED = 1
		ENABLED = 2
		DELETED = 3
	end

	class KalturaSiteRestrictionType
		RESTRICT_SITE_LIST = 0
		ALLOW_SITE_LIST = 1
	end

	class KalturaSourceType
		FILE = 1
		WEBCAM = 2
		URL = 5
		SEARCH_PROVIDER = 6
		AKAMAI_LIVE = 29
	end

	class KalturaStatsEventType
		WIDGET_LOADED = 1
		MEDIA_LOADED = 2
		PLAY = 3
		PLAY_REACHED_25 = 4
		PLAY_REACHED_50 = 5
		PLAY_REACHED_75 = 6
		PLAY_REACHED_100 = 7
		OPEN_EDIT = 8
		OPEN_VIRAL = 9
		OPEN_DOWNLOAD = 10
		OPEN_REPORT = 11
		BUFFER_START = 12
		BUFFER_END = 13
		OPEN_FULL_SCREEN = 14
		CLOSE_FULL_SCREEN = 15
		REPLAY = 16
		SEEK = 17
		OPEN_UPLOAD = 18
		SAVE_PUBLISH = 19
		CLOSE_EDITOR = 20
		PRE_BUMPER_PLAYED = 21
		POST_BUMPER_PLAYED = 22
		BUMPER_CLICKED = 23
		PREROLL_STARTED = 24
		MIDROLL_STARTED = 25
		POSTROLL_STARTED = 26
		OVERLAY_STARTED = 27
		PREROLL_CLICKED = 28
		MIDROLL_CLICKED = 29
		POSTROLL_CLICKED = 30
		OVERLAY_CLICKED = 31
		PREROLL_25 = 32
		PREROLL_50 = 33
		PREROLL_75 = 34
		MIDROLL_25 = 35
		MIDROLL_50 = 36
		MIDROLL_75 = 37
		POSTROLL_25 = 38
		POSTROLL_50 = 39
		POSTROLL_75 = 40
	end

	class KalturaStatsKmcEventType
		CONTENT_PAGE_VIEW = 1001
		CONTENT_ADD_PLAYLIST = 1010
		CONTENT_EDIT_PLAYLIST = 1011
		CONTENT_DELETE_PLAYLIST = 1012
		CONTENT_DELETE_ITEM = 1058
		CONTENT_DELETE_MIX = 1059
		CONTENT_EDIT_ENTRY = 1013
		CONTENT_CHANGE_THUMBNAIL = 1014
		CONTENT_ADD_TAGS = 1015
		CONTENT_REMOVE_TAGS = 1016
		CONTENT_ADD_ADMIN_TAGS = 1017
		CONTENT_REMOVE_ADMIN_TAGS = 1018
		CONTENT_DOWNLOAD = 1019
		CONTENT_APPROVE_MODERATION = 1020
		CONTENT_REJECT_MODERATION = 1021
		CONTENT_BULK_UPLOAD = 1022
		CONTENT_ADMIN_KCW_UPLOAD = 1023
		CONTENT_CONTENT_GO_TO_PAGE = 1057
		CONTENT_ENTRY_DRILLDOWN = 1088
		CONTENT_OPEN_PREVIEW_AND_EMBED = 1089
		ACCOUNT_CHANGE_PARTNER_INFO = 1030
		ACCOUNT_CHANGE_LOGIN_INFO = 1031
		ACCOUNT_CONTACT_US_USAGE = 1032
		ACCOUNT_UPDATE_SERVER_SETTINGS = 1033
		ACCOUNT_ACCOUNT_OVERVIEW = 1034
		ACCOUNT_ACCESS_CONTROL = 1035
		ACCOUNT_TRANSCODING_SETTINGS = 1036
		ACCOUNT_ACCOUNT_UPGRADE = 1037
		ACCOUNT_SAVE_SERVER_SETTINGS = 1038
		ACCOUNT_ACCESS_CONTROL_DELETE = 1039
		ACCOUNT_SAVE_TRANSCODING_SETTINGS = 1040
		LOGIN = 1041
		DASHBOARD_IMPORT_CONTENT = 1042
		DASHBOARD_UPDATE_CONTENT = 1043
		DASHBOARD_ACCOUNT_CONTACT_US = 1044
		DASHBOARD_VIEW_REPORTS = 1045
		DASHBOARD_EMBED_PLAYER = 1046
		DASHBOARD_EMBED_PLAYLIST = 1047
		DASHBOARD_CUSTOMIZE_PLAYERS = 1048
		APP_STUDIO_NEW_PLAYER_SINGLE_VIDEO = 1050
		APP_STUDIO_NEW_PLAYER_PLAYLIST = 1051
		APP_STUDIO_NEW_PLAYER_MULTI_TAB_PLAYLIST = 1052
		APP_STUDIO_EDIT_PLAYER_SINGLE_VIDEO = 1053
		APP_STUDIO_EDIT_PLAYER_PLAYLIST = 1054
		APP_STUDIO_EDIT_PLAYER_MULTI_TAB_PLAYLIST = 1055
		APP_STUDIO_DUPLICATE_PLAYER = 1056
		REPORTS_AND_ANALYTICS_BANDWIDTH_USAGE_TAB = 1070
		REPORTS_AND_ANALYTICS_CONTENT_REPORTS_TAB = 1071
		REPORTS_AND_ANALYTICS_USERS_AND_COMMUNITY_REPORTS_TAB = 1072
		REPORTS_AND_ANALYTICS_TOP_CONTRIBUTORS = 1073
		REPORTS_AND_ANALYTICS_MAP_OVERLAYS = 1074
		REPORTS_AND_ANALYTICS_TOP_SYNDICATIONS = 1075
		REPORTS_AND_ANALYTICS_TOP_CONTENT = 1076
		REPORTS_AND_ANALYTICS_CONTENT_DROPOFF = 1077
		REPORTS_AND_ANALYTICS_CONTENT_INTERACTIONS = 1078
		REPORTS_AND_ANALYTICS_CONTENT_CONTRIBUTIONS = 1079
		REPORTS_AND_ANALYTICS_VIDEO_DRILL_DOWN = 1080
		REPORTS_AND_ANALYTICS_CONTENT_DRILL_DOWN_INTERACTION = 1081
		REPORTS_AND_ANALYTICS_CONTENT_CONTRIBUTIONS_DRILLDOWN = 1082
		REPORTS_AND_ANALYTICS_VIDEO_DRILL_DOWN_DROPOFF = 1083
		REPORTS_AND_ANALYTICS_MAP_OVERLAYS_DRILLDOWN = 1084
		REPORTS_AND_ANALYTICS_TOP_SYNDICATIONS_DRILL_DOWN = 1085
		REPORTS_AND_ANALYTICS_BANDWIDTH_USAGE_VIEW_MONTHLY = 1086
		REPORTS_AND_ANALYTICS_BANDWIDTH_USAGE_VIEW_YEARLY = 1087
	end

	class KalturaStorageProfileProtocol
		KALTURA_DC = 0
		FTP = 1
		SCP = 2
		SFTP = 3
	end

	class KalturaStorageProfileStatus
		DISABLED = 1
		AUTOMATIC = 2
		MANUAL = 3
	end

	class KalturaStorageServePriority
		KALTURA_ONLY = 1
		KALTURA_FIRST = 2
		EXTERNAL_FIRST = 3
		EXTERNAL_ONLY = 4
	end

	class KalturaSyndicationFeedStatus
		DELETED = -1
		ACTIVE = 1
	end

	class KalturaSyndicationFeedType
		GOOGLE_VIDEO = 1
		YAHOO = 2
		ITUNES = 3
		TUBE_MOGUL = 4
		KALTURA = 5
		KALTURA_XSLT = 6
	end

	class KalturaThumbAssetOrderBy
		SIZE_ASC = "+size"
		SIZE_DESC = "-size"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
		DELETED_AT_ASC = "+deletedAt"
		DELETED_AT_DESC = "-deletedAt"
	end

	class KalturaThumbCropType
		RESIZE = 1
		RESIZE_WITH_PADDING = 2
		CROP = 3
		CROP_FROM_TOP = 4
	end

	class KalturaThumbParamsOrderBy
	end

	class KalturaThumbParamsOutputOrderBy
	end

	class KalturaTrackEntryEventType
		UPLOADED_FILE = 1
		WEBCAM_COMPLETED = 2
		IMPORT_STARTED = 3
		ADD_ENTRY = 4
		UPDATE_ENTRY = 5
		DELETED_ENTRY = 6
	end

	class KalturaTubeMogulSyndicationFeedCategories
		ARTS_AND_ANIMATION = "Arts &amp; Animation"
		COMEDY = "Comedy"
		ENTERTAINMENT = "Entertainment"
		MUSIC = "Music"
		NEWS_AND_BLOGS = "News &amp; Blogs"
		SCIENCE_AND_TECHNOLOGY = "Science &amp; Technology"
		SPORTS = "Sports"
		TRAVEL_AND_PLACES = "Travel &amp; Places"
		VIDEO_GAMES = "Video Games"
		ANIMALS_AND_PETS = "Animals &amp; Pets"
		AUTOS = "Autos"
		VLOGS_PEOPLE = "Vlogs &amp; People"
		HOW_TO_INSTRUCTIONAL_DIY = "How To/Instructional/DIY"
		COMMERCIALS_PROMOTIONAL = "Commercials/Promotional"
		FAMILY_AND_KIDS = "Family &amp; Kids"
	end

	class KalturaTubeMogulSyndicationFeedOrderBy
		PLAYLIST_ID_ASC = "+playlistId"
		PLAYLIST_ID_DESC = "-playlistId"
		NAME_ASC = "+name"
		NAME_DESC = "-name"
		TYPE_ASC = "+type"
		TYPE_DESC = "-type"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
	end

	class KalturaUiConfCreationMode
		WIZARD = 2
		ADVANCED = 3
	end

	class KalturaUiConfObjType
		PLAYER = 1
		CONTRIBUTION_WIZARD = 2
		SIMPLE_EDITOR = 3
		ADVANCED_EDITOR = 4
		PLAYLIST = 5
		APP_STUDIO = 6
		KRECORD = 7
		PLAYER_V3 = 8
		KMC_ACCOUNT = 9
		KMC_ANALYTICS = 10
		KMC_CONTENT = 11
		KMC_DASHBOARD = 12
		KMC_LOGIN = 13
		PLAYER_SL = 14
		CLIENTSIDE_ENCODER = 15
		KMC_GENERAL = 16
		KMC_ROLES_AND_PERMISSIONS = 17
	end

	class KalturaUiConfOrderBy
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
	end

	class KalturaUploadErrorCode
		NO_ERROR = 0
		GENERAL_ERROR = 1
		PARTIAL_UPLOAD = 2
	end

	class KalturaUploadTokenOrderBy
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
	end

	class KalturaUploadTokenStatus
		PENDING = 0
		PARTIAL_UPLOAD = 1
		FULL_UPLOAD = 2
		CLOSED = 3
		TIMED_OUT = 4
		DELETED = 5
	end

	class KalturaUserOrderBy
		ID_ASC = "+id"
		ID_DESC = "-id"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
	end

	class KalturaUserRoleOrderBy
		ID_ASC = "+id"
		ID_DESC = "-id"
		NAME_ASC = "+name"
		NAME_DESC = "-name"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
	end

	class KalturaUserRoleStatus
		ACTIVE = 1
		BLOCKED = 2
		DELETED = 3
	end

	class KalturaUserStatus
		BLOCKED = 0
		ACTIVE = 1
		DELETED = 2
	end

	class KalturaVideoCodec
		NONE = ""
		VP6 = "vp6"
		H263 = "h263"
		H264 = "h264"
		H264B = "h264b"
		H264M = "h264m"
		H264H = "h264h"
		FLV = "flv"
		MPEG4 = "mpeg4"
		THEORA = "theora"
		WMV2 = "wmv2"
		WMV3 = "wmv3"
		WVC1A = "wvc1a"
		VP8 = "vp8"
		COPY = "copy"
	end

	class KalturaVirusFoundAction
		NONE = 0
		DELETE = 1
		CLEAN_NONE = 2
		CLEAN_DELETE = 3
	end

	class KalturaVirusScanEngineType
		SYMANTEC_SCAN_ENGINE = "symantecScanEngine.SymantecScanEngine"
	end

	class KalturaVirusScanProfileOrderBy
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
		UPDATED_AT_ASC = "+updatedAt"
		UPDATED_AT_DESC = "-updatedAt"
	end

	class KalturaVirusScanProfileStatus
		DISABLED = 1
		ENABLED = 2
	end

	class KalturaWidgetOrderBy
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
	end

	class KalturaWidgetSecurityType
		NONE = 1
		TIMEHASH = 2
	end

	class KalturaYahooSyndicationFeedAdultValues
		ADULT = "adult"
		NON_ADULT = "nonadult"
	end

	class KalturaYahooSyndicationFeedCategories
		ACTION = "Action"
		ART_AND_ANIMATION = "Art &amp; Animation"
		ENTERTAINMENT_AND_TV = "Entertainment &amp; TV"
		FOOD = "Food"
		GAMES = "Games"
		HOW_TO = "How-To"
		MUSIC = "Music"
		PEOPLE_AND_VLOGS = "People &amp; Vlogs"
		SCIENCE_AND_ENVIRONMENT = "Science &amp; Environment"
		TRANSPORTATION = "Transportation"
		ANIMALS = "Animals"
		COMMERCIALS = "Commercials"
		FAMILY = "Family"
		FUNNY_VIDEOS = "Funny Videos"
		HEALTH_AND_BEAUTY = "Health &amp; Beauty"
		MOVIES_AND_SHORTS = "Movies &amp; Shorts"
		NEWS_AND_POLITICS = "News &amp; Politics"
		PRODUCTS_AND_TECH = "Products &amp; Tech."
		SPORTS = "Sports"
		TRAVEL = "Travel"
	end

	class KalturaYahooSyndicationFeedOrderBy
		PLAYLIST_ID_ASC = "+playlistId"
		PLAYLIST_ID_DESC = "-playlistId"
		NAME_ASC = "+name"
		NAME_DESC = "-name"
		TYPE_ASC = "+type"
		TYPE_DESC = "-type"
		CREATED_AT_ASC = "+createdAt"
		CREATED_AT_DESC = "-createdAt"
	end

	class KalturaBaseRestriction < KalturaObjectBase

	end

	class KalturaAccessControl < KalturaObjectBase
		attr_accessor :id
		attr_accessor :partner_id
		attr_accessor :name
		attr_accessor :description
		attr_accessor :created_at
		attr_accessor :is_default
		attr_accessor :restrictions

		def id=(val)
			@id = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def is_default=(val)
			@is_default = val.to_i
		end
	end

	class KalturaSearchItem < KalturaObjectBase

	end

	class KalturaFilter < KalturaObjectBase
		attr_accessor :order_by
		attr_accessor :advanced_search

	end

	class KalturaAccessControlBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :id_in
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal

		def id_equal=(val)
			@id_equal = val.to_i
		end
		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
	end

	class KalturaAccessControlFilter < KalturaAccessControlBaseFilter

	end

	class KalturaFilterPager < KalturaObjectBase
		attr_accessor :page_size
		attr_accessor :page_index

		def page_size=(val)
			@page_size = val.to_i
		end
		def page_index=(val)
			@page_index = val.to_i
		end
	end

	class KalturaAccessControlListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaUser < KalturaObjectBase
		attr_accessor :id
		attr_accessor :partner_id
		attr_accessor :screen_name
		attr_accessor :full_name
		attr_accessor :email
		attr_accessor :date_of_birth
		attr_accessor :country
		attr_accessor :state
		attr_accessor :city
		attr_accessor :zip
		attr_accessor :thumbnail_url
		attr_accessor :description
		attr_accessor :tags
		attr_accessor :admin_tags
		attr_accessor :gender
		attr_accessor :status
		attr_accessor :created_at
		attr_accessor :updated_at
		attr_accessor :partner_data
		attr_accessor :indexed_partner_data_int
		attr_accessor :indexed_partner_data_string
		attr_accessor :storage_size
		attr_accessor :password
		attr_accessor :first_name
		attr_accessor :last_name
		attr_accessor :is_admin
		attr_accessor :last_login_time
		attr_accessor :status_updated_at
		attr_accessor :deleted_at
		attr_accessor :login_enabled
		attr_accessor :role_ids
		attr_accessor :role_names
		attr_accessor :is_account_owner

		def partner_id=(val)
			@partner_id = val.to_i
		end
		def date_of_birth=(val)
			@date_of_birth = val.to_i
		end
		def gender=(val)
			@gender = val.to_i
		end
		def status=(val)
			@status = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
		def indexed_partner_data_int=(val)
			@indexed_partner_data_int = val.to_i
		end
		def storage_size=(val)
			@storage_size = val.to_i
		end
		def is_admin=(val)
			@is_admin = to_b(val)
		end
		def last_login_time=(val)
			@last_login_time = val.to_i
		end
		def status_updated_at=(val)
			@status_updated_at = val.to_i
		end
		def deleted_at=(val)
			@deleted_at = val.to_i
		end
		def login_enabled=(val)
			@login_enabled = to_b(val)
		end
		def is_account_owner=(val)
			@is_account_owner = to_b(val)
		end
	end

	class KalturaDynamicEnum < KalturaObjectBase

	end

	class KalturaBaseEntry < KalturaObjectBase
		attr_accessor :id
		attr_accessor :name
		attr_accessor :description
		attr_accessor :partner_id
		attr_accessor :user_id
		attr_accessor :tags
		attr_accessor :admin_tags
		attr_accessor :categories
		attr_accessor :categories_ids
		attr_accessor :status
		attr_accessor :moderation_status
		attr_accessor :moderation_count
		attr_accessor :type
		attr_accessor :created_at
		attr_accessor :updated_at
		attr_accessor :rank
		attr_accessor :total_rank
		attr_accessor :votes
		attr_accessor :group_id
		attr_accessor :partner_data
		attr_accessor :download_url
		attr_accessor :search_text
		attr_accessor :license_type
		attr_accessor :version
		attr_accessor :thumbnail_url
		attr_accessor :access_control_id
		attr_accessor :start_date
		attr_accessor :end_date

		def partner_id=(val)
			@partner_id = val.to_i
		end
		def moderation_status=(val)
			@moderation_status = val.to_i
		end
		def moderation_count=(val)
			@moderation_count = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
		def rank=(val)
			@rank = val.to_f
		end
		def total_rank=(val)
			@total_rank = val.to_i
		end
		def votes=(val)
			@votes = val.to_i
		end
		def group_id=(val)
			@group_id = val.to_i
		end
		def license_type=(val)
			@license_type = val.to_i
		end
		def version=(val)
			@version = val.to_i
		end
		def access_control_id=(val)
			@access_control_id = val.to_i
		end
		def start_date=(val)
			@start_date = val.to_i
		end
		def end_date=(val)
			@end_date = val.to_i
		end
	end

	class KalturaBaseEntryBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :id_in
		attr_accessor :id_not_in
		attr_accessor :name_like
		attr_accessor :name_multi_like_or
		attr_accessor :name_multi_like_and
		attr_accessor :name_equal
		attr_accessor :partner_id_equal
		attr_accessor :partner_id_in
		attr_accessor :user_id_equal
		attr_accessor :tags_like
		attr_accessor :tags_multi_like_or
		attr_accessor :tags_multi_like_and
		attr_accessor :admin_tags_like
		attr_accessor :admin_tags_multi_like_or
		attr_accessor :admin_tags_multi_like_and
		attr_accessor :categories_match_and
		attr_accessor :categories_match_or
		attr_accessor :categories_ids_match_and
		attr_accessor :categories_ids_match_or
		attr_accessor :status_equal
		attr_accessor :status_not_equal
		attr_accessor :status_in
		attr_accessor :status_not_in
		attr_accessor :moderation_status_equal
		attr_accessor :moderation_status_not_equal
		attr_accessor :moderation_status_in
		attr_accessor :moderation_status_not_in
		attr_accessor :type_equal
		attr_accessor :type_in
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal
		attr_accessor :updated_at_greater_than_or_equal
		attr_accessor :updated_at_less_than_or_equal
		attr_accessor :group_id_equal
		attr_accessor :search_text_match_and
		attr_accessor :search_text_match_or
		attr_accessor :access_control_id_equal
		attr_accessor :access_control_id_in
		attr_accessor :start_date_greater_than_or_equal
		attr_accessor :start_date_less_than_or_equal
		attr_accessor :start_date_greater_than_or_equal_or_null
		attr_accessor :start_date_less_than_or_equal_or_null
		attr_accessor :end_date_greater_than_or_equal
		attr_accessor :end_date_less_than_or_equal
		attr_accessor :end_date_greater_than_or_equal_or_null
		attr_accessor :end_date_less_than_or_equal_or_null
		attr_accessor :tags_name_multi_like_or
		attr_accessor :tags_admin_tags_multi_like_or
		attr_accessor :tags_admin_tags_name_multi_like_or
		attr_accessor :tags_name_multi_like_and
		attr_accessor :tags_admin_tags_multi_like_and
		attr_accessor :tags_admin_tags_name_multi_like_and

		def partner_id_equal=(val)
			@partner_id_equal = val.to_i
		end
		def moderation_status_equal=(val)
			@moderation_status_equal = val.to_i
		end
		def moderation_status_not_equal=(val)
			@moderation_status_not_equal = val.to_i
		end
		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
		def updated_at_greater_than_or_equal=(val)
			@updated_at_greater_than_or_equal = val.to_i
		end
		def updated_at_less_than_or_equal=(val)
			@updated_at_less_than_or_equal = val.to_i
		end
		def group_id_equal=(val)
			@group_id_equal = val.to_i
		end
		def access_control_id_equal=(val)
			@access_control_id_equal = val.to_i
		end
		def start_date_greater_than_or_equal=(val)
			@start_date_greater_than_or_equal = val.to_i
		end
		def start_date_less_than_or_equal=(val)
			@start_date_less_than_or_equal = val.to_i
		end
		def start_date_greater_than_or_equal_or_null=(val)
			@start_date_greater_than_or_equal_or_null = val.to_i
		end
		def start_date_less_than_or_equal_or_null=(val)
			@start_date_less_than_or_equal_or_null = val.to_i
		end
		def end_date_greater_than_or_equal=(val)
			@end_date_greater_than_or_equal = val.to_i
		end
		def end_date_less_than_or_equal=(val)
			@end_date_less_than_or_equal = val.to_i
		end
		def end_date_greater_than_or_equal_or_null=(val)
			@end_date_greater_than_or_equal_or_null = val.to_i
		end
		def end_date_less_than_or_equal_or_null=(val)
			@end_date_less_than_or_equal_or_null = val.to_i
		end
	end

	class KalturaBaseEntryFilter < KalturaBaseEntryBaseFilter
		attr_accessor :free_text

	end

	class KalturaBaseEntryListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaModerationFlag < KalturaObjectBase
		attr_accessor :id
		attr_accessor :partner_id
		attr_accessor :user_id
		attr_accessor :moderation_object_type
		attr_accessor :flagged_entry_id
		attr_accessor :flagged_user_id
		attr_accessor :status
		attr_accessor :comments
		attr_accessor :flag_type
		attr_accessor :created_at
		attr_accessor :updated_at

		def id=(val)
			@id = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def moderation_object_type=(val)
			@moderation_object_type = val.to_i
		end
		def status=(val)
			@status = val.to_i
		end
		def flag_type=(val)
			@flag_type = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
	end

	class KalturaModerationFlagListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaEntryContextDataParams < KalturaObjectBase
		attr_accessor :referrer

	end

	class KalturaEntryContextDataResult < KalturaObjectBase
		attr_accessor :is_site_restricted
		attr_accessor :is_country_restricted
		attr_accessor :is_session_restricted
		attr_accessor :is_ip_address_restricted
		attr_accessor :preview_length
		attr_accessor :is_scheduled_now
		attr_accessor :is_admin

		def is_site_restricted=(val)
			@is_site_restricted = to_b(val)
		end
		def is_country_restricted=(val)
			@is_country_restricted = to_b(val)
		end
		def is_session_restricted=(val)
			@is_session_restricted = to_b(val)
		end
		def is_ip_address_restricted=(val)
			@is_ip_address_restricted = to_b(val)
		end
		def preview_length=(val)
			@preview_length = val.to_i
		end
		def is_scheduled_now=(val)
			@is_scheduled_now = to_b(val)
		end
		def is_admin=(val)
			@is_admin = to_b(val)
		end
	end

	class KalturaBulkUploadPluginData < KalturaObjectBase
		attr_accessor :field
		attr_accessor :value

	end

	class KalturaBulkUploadResult < KalturaObjectBase
		attr_accessor :id
		attr_accessor :bulk_upload_job_id
		attr_accessor :line_index
		attr_accessor :partner_id
		attr_accessor :entry_id
		attr_accessor :entry_status
		attr_accessor :row_data
		attr_accessor :title
		attr_accessor :description
		attr_accessor :tags
		attr_accessor :url
		attr_accessor :content_type
		attr_accessor :conversion_profile_id
		attr_accessor :access_control_profile_id
		attr_accessor :category
		attr_accessor :schedule_start_date
		attr_accessor :schedule_end_date
		attr_accessor :thumbnail_url
		attr_accessor :thumbnail_saved
		attr_accessor :partner_data
		attr_accessor :error_description
		attr_accessor :plugins_data

		def id=(val)
			@id = val.to_i
		end
		def bulk_upload_job_id=(val)
			@bulk_upload_job_id = val.to_i
		end
		def line_index=(val)
			@line_index = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def entry_status=(val)
			@entry_status = val.to_i
		end
		def conversion_profile_id=(val)
			@conversion_profile_id = val.to_i
		end
		def access_control_profile_id=(val)
			@access_control_profile_id = val.to_i
		end
		def schedule_start_date=(val)
			@schedule_start_date = val.to_i
		end
		def schedule_end_date=(val)
			@schedule_end_date = val.to_i
		end
		def thumbnail_saved=(val)
			@thumbnail_saved = to_b(val)
		end
	end

	class KalturaBulkUpload < KalturaObjectBase
		attr_accessor :id
		attr_accessor :uploaded_by
		attr_accessor :uploaded_by_user_id
		attr_accessor :uploaded_on
		attr_accessor :num_of_entries
		attr_accessor :status
		attr_accessor :log_file_url
		attr_accessor :csv_file_url
		attr_accessor :results

		def id=(val)
			@id = val.to_i
		end
		def uploaded_on=(val)
			@uploaded_on = val.to_i
		end
		def num_of_entries=(val)
			@num_of_entries = val.to_i
		end
		def status=(val)
			@status = val.to_i
		end
	end

	class KalturaBulkUploadListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaCategory < KalturaObjectBase
		attr_accessor :id
		attr_accessor :parent_id
		attr_accessor :depth
		attr_accessor :partner_id
		attr_accessor :name
		attr_accessor :full_name
		attr_accessor :entries_count
		attr_accessor :created_at

		def id=(val)
			@id = val.to_i
		end
		def parent_id=(val)
			@parent_id = val.to_i
		end
		def depth=(val)
			@depth = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def entries_count=(val)
			@entries_count = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
	end

	class KalturaCategoryBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :id_in
		attr_accessor :parent_id_equal
		attr_accessor :parent_id_in
		attr_accessor :depth_equal
		attr_accessor :full_name_equal
		attr_accessor :full_name_starts_with

		def id_equal=(val)
			@id_equal = val.to_i
		end
		def parent_id_equal=(val)
			@parent_id_equal = val.to_i
		end
		def depth_equal=(val)
			@depth_equal = val.to_i
		end
	end

	class KalturaCategoryFilter < KalturaCategoryBaseFilter

	end

	class KalturaCategoryListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaCropDimensions < KalturaObjectBase
		attr_accessor :left
		attr_accessor :top
		attr_accessor :width
		attr_accessor :height

		def left=(val)
			@left = val.to_i
		end
		def top=(val)
			@top = val.to_i
		end
		def width=(val)
			@width = val.to_i
		end
		def height=(val)
			@height = val.to_i
		end
	end

	class KalturaConversionProfile < KalturaObjectBase
		attr_accessor :id
		attr_accessor :partner_id
		attr_accessor :name
		attr_accessor :description
		attr_accessor :created_at
		attr_accessor :flavor_params_ids
		attr_accessor :is_default
		attr_accessor :crop_dimensions
		attr_accessor :clip_start
		attr_accessor :clip_duration

		def id=(val)
			@id = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def is_default=(val)
			@is_default = val.to_i
		end
		def clip_start=(val)
			@clip_start = val.to_i
		end
		def clip_duration=(val)
			@clip_duration = val.to_i
		end
	end

	class KalturaConversionProfileBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :id_in
		attr_accessor :name_equal

		def id_equal=(val)
			@id_equal = val.to_i
		end
	end

	class KalturaConversionProfileFilter < KalturaConversionProfileBaseFilter

	end

	class KalturaConversionProfileListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaDataEntry < KalturaBaseEntry
		attr_accessor :data_content
		attr_accessor :retrieve_data_content_by_get

		def retrieve_data_content_by_get=(val)
			@retrieve_data_content_by_get = to_b(val)
		end
	end

	class KalturaDataEntryBaseFilter < KalturaBaseEntryFilter

	end

	class KalturaDataEntryFilter < KalturaDataEntryBaseFilter

	end

	class KalturaDataListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaDocumentEntry < KalturaBaseEntry
		attr_accessor :document_type
		attr_accessor :conversion_profile_id

		def document_type=(val)
			@document_type = val.to_i
		end
	end

	class KalturaConversionAttribute < KalturaObjectBase
		attr_accessor :flavor_params_id
		attr_accessor :name
		attr_accessor :value

		def flavor_params_id=(val)
			@flavor_params_id = val.to_i
		end
	end

	class KalturaDocumentEntryBaseFilter < KalturaBaseEntryFilter
		attr_accessor :document_type_equal
		attr_accessor :document_type_in

		def document_type_equal=(val)
			@document_type_equal = val.to_i
		end
	end

	class KalturaDocumentEntryFilter < KalturaDocumentEntryBaseFilter

	end

	class KalturaDocumentListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaEmailIngestionProfile < KalturaObjectBase
		attr_accessor :id
		attr_accessor :name
		attr_accessor :description
		attr_accessor :email_address
		attr_accessor :mailbox_id
		attr_accessor :partner_id
		attr_accessor :conversion_profile2id
		attr_accessor :moderation_status
		attr_accessor :status
		attr_accessor :created_at
		attr_accessor :default_category
		attr_accessor :default_user_id
		attr_accessor :default_tags
		attr_accessor :default_admin_tags
		attr_accessor :max_attachment_size_kbytes
		attr_accessor :max_attachments_per_mail

		def id=(val)
			@id = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def conversion_profile2id=(val)
			@conversion_profile2id = val.to_i
		end
		def moderation_status=(val)
			@moderation_status = val.to_i
		end
		def status=(val)
			@status = val.to_i
		end
		def max_attachment_size_kbytes=(val)
			@max_attachment_size_kbytes = val.to_i
		end
		def max_attachments_per_mail=(val)
			@max_attachments_per_mail = val.to_i
		end
	end

	class KalturaPlayableEntry < KalturaBaseEntry
		attr_accessor :plays
		attr_accessor :views
		attr_accessor :width
		attr_accessor :height
		attr_accessor :duration
		attr_accessor :ms_duration
		attr_accessor :duration_type

		def plays=(val)
			@plays = val.to_i
		end
		def views=(val)
			@views = val.to_i
		end
		def width=(val)
			@width = val.to_i
		end
		def height=(val)
			@height = val.to_i
		end
		def duration=(val)
			@duration = val.to_i
		end
		def ms_duration=(val)
			@ms_duration = val.to_i
		end
	end

	class KalturaMediaEntry < KalturaPlayableEntry
		attr_accessor :media_type
		attr_accessor :conversion_quality
		attr_accessor :source_type
		attr_accessor :search_provider_type
		attr_accessor :search_provider_id
		attr_accessor :credit_user_name
		attr_accessor :credit_url
		attr_accessor :media_date
		attr_accessor :data_url
		attr_accessor :flavor_params_ids

		def media_type=(val)
			@media_type = val.to_i
		end
		def source_type=(val)
			@source_type = val.to_i
		end
		def search_provider_type=(val)
			@search_provider_type = val.to_i
		end
		def media_date=(val)
			@media_date = val.to_i
		end
	end

	class KalturaAsset < KalturaObjectBase
		attr_accessor :id
		attr_accessor :entry_id
		attr_accessor :partner_id
		attr_accessor :status
		attr_accessor :version
		attr_accessor :size
		attr_accessor :tags
		attr_accessor :file_ext
		attr_accessor :created_at
		attr_accessor :updated_at
		attr_accessor :deleted_at
		attr_accessor :description

		def partner_id=(val)
			@partner_id = val.to_i
		end
		def status=(val)
			@status = val.to_i
		end
		def version=(val)
			@version = val.to_i
		end
		def size=(val)
			@size = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
		def deleted_at=(val)
			@deleted_at = val.to_i
		end
	end

	class KalturaFlavorAsset < KalturaAsset
		attr_accessor :flavor_params_id
		attr_accessor :width
		attr_accessor :height
		attr_accessor :bitrate
		attr_accessor :frame_rate
		attr_accessor :is_original
		attr_accessor :is_web
		attr_accessor :container_format
		attr_accessor :video_codec_id

		def flavor_params_id=(val)
			@flavor_params_id = val.to_i
		end
		def width=(val)
			@width = val.to_i
		end
		def height=(val)
			@height = val.to_i
		end
		def bitrate=(val)
			@bitrate = val.to_i
		end
		def frame_rate=(val)
			@frame_rate = val.to_i
		end
		def is_original=(val)
			@is_original = to_b(val)
		end
		def is_web=(val)
			@is_web = to_b(val)
		end
	end

	class KalturaAssetBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :id_in
		attr_accessor :entry_id_equal
		attr_accessor :entry_id_in
		attr_accessor :partner_id_equal
		attr_accessor :partner_id_in
		attr_accessor :status_equal
		attr_accessor :status_in
		attr_accessor :status_not_in
		attr_accessor :size_greater_than_or_equal
		attr_accessor :size_less_than_or_equal
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal
		attr_accessor :updated_at_greater_than_or_equal
		attr_accessor :updated_at_less_than_or_equal
		attr_accessor :deleted_at_greater_than_or_equal
		attr_accessor :deleted_at_less_than_or_equal

		def partner_id_equal=(val)
			@partner_id_equal = val.to_i
		end
		def status_equal=(val)
			@status_equal = val.to_i
		end
		def size_greater_than_or_equal=(val)
			@size_greater_than_or_equal = val.to_i
		end
		def size_less_than_or_equal=(val)
			@size_less_than_or_equal = val.to_i
		end
		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
		def updated_at_greater_than_or_equal=(val)
			@updated_at_greater_than_or_equal = val.to_i
		end
		def updated_at_less_than_or_equal=(val)
			@updated_at_less_than_or_equal = val.to_i
		end
		def deleted_at_greater_than_or_equal=(val)
			@deleted_at_greater_than_or_equal = val.to_i
		end
		def deleted_at_less_than_or_equal=(val)
			@deleted_at_less_than_or_equal = val.to_i
		end
	end

	class KalturaAssetFilter < KalturaAssetBaseFilter

	end

	class KalturaFlavorAssetListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaString < KalturaObjectBase
		attr_accessor :value

	end

	class KalturaAssetParams < KalturaObjectBase
		attr_accessor :id
		attr_accessor :partner_id
		attr_accessor :name
		attr_accessor :description
		attr_accessor :created_at
		attr_accessor :is_system_default
		attr_accessor :tags
		attr_accessor :format
		attr_accessor :required_permissions

		def id=(val)
			@id = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def is_system_default=(val)
			@is_system_default = val.to_i
		end
	end

	class KalturaFlavorParams < KalturaAssetParams
		attr_accessor :video_codec
		attr_accessor :video_bitrate
		attr_accessor :audio_codec
		attr_accessor :audio_bitrate
		attr_accessor :audio_channels
		attr_accessor :audio_sample_rate
		attr_accessor :width
		attr_accessor :height
		attr_accessor :frame_rate
		attr_accessor :gop_size
		attr_accessor :conversion_engines
		attr_accessor :conversion_engines_extra_params
		attr_accessor :two_pass
		attr_accessor :deinterlice
		attr_accessor :rotate
		attr_accessor :operators
		attr_accessor :engine_version

		def video_bitrate=(val)
			@video_bitrate = val.to_i
		end
		def audio_bitrate=(val)
			@audio_bitrate = val.to_i
		end
		def audio_channels=(val)
			@audio_channels = val.to_i
		end
		def audio_sample_rate=(val)
			@audio_sample_rate = val.to_i
		end
		def width=(val)
			@width = val.to_i
		end
		def height=(val)
			@height = val.to_i
		end
		def frame_rate=(val)
			@frame_rate = val.to_i
		end
		def gop_size=(val)
			@gop_size = val.to_i
		end
		def two_pass=(val)
			@two_pass = to_b(val)
		end
		def deinterlice=(val)
			@deinterlice = val.to_i
		end
		def rotate=(val)
			@rotate = val.to_i
		end
		def engine_version=(val)
			@engine_version = val.to_i
		end
	end

	class KalturaFlavorAssetWithParams < KalturaObjectBase
		attr_accessor :flavor_asset
		attr_accessor :flavor_params
		attr_accessor :entry_id

	end

	class KalturaAssetParamsBaseFilter < KalturaFilter
		attr_accessor :is_system_default_equal
		attr_accessor :tags_equal
		attr_accessor :format_equal

		def is_system_default_equal=(val)
			@is_system_default_equal = val.to_i
		end
	end

	class KalturaAssetParamsFilter < KalturaAssetParamsBaseFilter

	end

	class KalturaFlavorParamsBaseFilter < KalturaAssetParamsFilter

	end

	class KalturaFlavorParamsFilter < KalturaFlavorParamsBaseFilter

	end

	class KalturaFlavorParamsListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaLiveStreamBitrate < KalturaObjectBase
		attr_accessor :bitrate
		attr_accessor :width
		attr_accessor :height

		def bitrate=(val)
			@bitrate = val.to_i
		end
		def width=(val)
			@width = val.to_i
		end
		def height=(val)
			@height = val.to_i
		end
	end

	class KalturaLiveStreamEntry < KalturaMediaEntry
		attr_accessor :offline_message
		attr_accessor :stream_remote_id
		attr_accessor :stream_remote_backup_id
		attr_accessor :bitrates
		attr_accessor :primary_broadcasting_url
		attr_accessor :secondary_broadcasting_url
		attr_accessor :stream_name

	end

	class KalturaLiveStreamAdminEntry < KalturaLiveStreamEntry
		attr_accessor :encoding_ip1
		attr_accessor :encoding_ip2
		attr_accessor :stream_password
		attr_accessor :stream_username

	end

	class KalturaPlayableEntryBaseFilter < KalturaBaseEntryFilter
		attr_accessor :duration_less_than
		attr_accessor :duration_greater_than
		attr_accessor :duration_less_than_or_equal
		attr_accessor :duration_greater_than_or_equal
		attr_accessor :ms_duration_less_than
		attr_accessor :ms_duration_greater_than
		attr_accessor :ms_duration_less_than_or_equal
		attr_accessor :ms_duration_greater_than_or_equal
		attr_accessor :duration_type_match_or

		def duration_less_than=(val)
			@duration_less_than = val.to_i
		end
		def duration_greater_than=(val)
			@duration_greater_than = val.to_i
		end
		def duration_less_than_or_equal=(val)
			@duration_less_than_or_equal = val.to_i
		end
		def duration_greater_than_or_equal=(val)
			@duration_greater_than_or_equal = val.to_i
		end
		def ms_duration_less_than=(val)
			@ms_duration_less_than = val.to_i
		end
		def ms_duration_greater_than=(val)
			@ms_duration_greater_than = val.to_i
		end
		def ms_duration_less_than_or_equal=(val)
			@ms_duration_less_than_or_equal = val.to_i
		end
		def ms_duration_greater_than_or_equal=(val)
			@ms_duration_greater_than_or_equal = val.to_i
		end
	end

	class KalturaPlayableEntryFilter < KalturaPlayableEntryBaseFilter

	end

	class KalturaMediaEntryBaseFilter < KalturaPlayableEntryFilter
		attr_accessor :media_type_equal
		attr_accessor :media_type_in
		attr_accessor :media_date_greater_than_or_equal
		attr_accessor :media_date_less_than_or_equal
		attr_accessor :flavor_params_ids_match_or
		attr_accessor :flavor_params_ids_match_and

		def media_type_equal=(val)
			@media_type_equal = val.to_i
		end
		def media_date_greater_than_or_equal=(val)
			@media_date_greater_than_or_equal = val.to_i
		end
		def media_date_less_than_or_equal=(val)
			@media_date_less_than_or_equal = val.to_i
		end
	end

	class KalturaMediaEntryFilter < KalturaMediaEntryBaseFilter

	end

	class KalturaLiveStreamEntryBaseFilter < KalturaMediaEntryFilter

	end

	class KalturaLiveStreamEntryFilter < KalturaLiveStreamEntryBaseFilter

	end

	class KalturaLiveStreamListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaSearch < KalturaObjectBase
		attr_accessor :key_words
		attr_accessor :search_source
		attr_accessor :media_type
		attr_accessor :extra_data
		attr_accessor :auth_data

		def search_source=(val)
			@search_source = val.to_i
		end
		def media_type=(val)
			@media_type = val.to_i
		end
	end

	class KalturaSearchResult < KalturaSearch
		attr_accessor :id
		attr_accessor :title
		attr_accessor :thumb_url
		attr_accessor :description
		attr_accessor :tags
		attr_accessor :url
		attr_accessor :source_link
		attr_accessor :credit
		attr_accessor :license_type
		attr_accessor :flash_playback_type

		def license_type=(val)
			@license_type = val.to_i
		end
	end

	class KalturaMediaListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaMixEntry < KalturaPlayableEntry
		attr_accessor :has_real_thumbnail
		attr_accessor :editor_type
		attr_accessor :data_content

		def has_real_thumbnail=(val)
			@has_real_thumbnail = to_b(val)
		end
		def editor_type=(val)
			@editor_type = val.to_i
		end
	end

	class KalturaMixEntryBaseFilter < KalturaPlayableEntryFilter

	end

	class KalturaMixEntryFilter < KalturaMixEntryBaseFilter

	end

	class KalturaMixListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaClientNotification < KalturaObjectBase
		attr_accessor :url
		attr_accessor :data

	end

	class KalturaPartner < KalturaObjectBase
		attr_accessor :id
		attr_accessor :name
		attr_accessor :website
		attr_accessor :notification_url
		attr_accessor :appear_in_search
		attr_accessor :created_at
		attr_accessor :admin_name
		attr_accessor :admin_email
		attr_accessor :description
		attr_accessor :commercial_use
		attr_accessor :landing_page
		attr_accessor :user_landing_page
		attr_accessor :content_categories
		attr_accessor :type
		attr_accessor :phone
		attr_accessor :describe_yourself
		attr_accessor :adult_content
		attr_accessor :def_conversion_profile_type
		attr_accessor :notify
		attr_accessor :status
		attr_accessor :allow_quick_edit
		attr_accessor :merge_entry_lists
		attr_accessor :notifications_config
		attr_accessor :max_upload_size
		attr_accessor :partner_package
		attr_accessor :secret
		attr_accessor :admin_secret
		attr_accessor :cms_password
		attr_accessor :allow_multi_notification
		attr_accessor :admin_login_users_quota
		attr_accessor :admin_user_id

		def id=(val)
			@id = val.to_i
		end
		def appear_in_search=(val)
			@appear_in_search = val.to_i
		end
		def commercial_use=(val)
			@commercial_use = val.to_i
		end
		def type=(val)
			@type = val.to_i
		end
		def adult_content=(val)
			@adult_content = to_b(val)
		end
		def notify=(val)
			@notify = val.to_i
		end
		def status=(val)
			@status = val.to_i
		end
		def allow_quick_edit=(val)
			@allow_quick_edit = val.to_i
		end
		def merge_entry_lists=(val)
			@merge_entry_lists = val.to_i
		end
		def max_upload_size=(val)
			@max_upload_size = val.to_i
		end
		def partner_package=(val)
			@partner_package = val.to_i
		end
		def allow_multi_notification=(val)
			@allow_multi_notification = val.to_i
		end
		def admin_login_users_quota=(val)
			@admin_login_users_quota = val.to_i
		end
	end

	class KalturaPartnerUsage < KalturaObjectBase
		attr_accessor :hosting_gb
		attr_accessor :percent
		attr_accessor :package_bw
		attr_accessor :usage_gb
		attr_accessor :reached_limit_date
		attr_accessor :usage_graph

		def hosting_gb=(val)
			@hosting_gb = val.to_f
		end
		def percent=(val)
			@percent = val.to_f
		end
		def package_bw=(val)
			@package_bw = val.to_i
		end
		def usage_gb=(val)
			@usage_gb = val.to_i
		end
		def reached_limit_date=(val)
			@reached_limit_date = val.to_i
		end
	end

	class KalturaPermissionItem < KalturaObjectBase
		attr_accessor :id
		attr_accessor :type
		attr_accessor :partner_id
		attr_accessor :tags
		attr_accessor :created_at
		attr_accessor :updated_at

		def id=(val)
			@id = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
	end

	class KalturaPermissionItemBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :id_in
		attr_accessor :type_equal
		attr_accessor :type_in
		attr_accessor :partner_id_equal
		attr_accessor :partner_id_in
		attr_accessor :tags_multi_like_or
		attr_accessor :tags_multi_like_and
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal
		attr_accessor :updated_at_greater_than_or_equal
		attr_accessor :updated_at_less_than_or_equal

		def id_equal=(val)
			@id_equal = val.to_i
		end
		def partner_id_equal=(val)
			@partner_id_equal = val.to_i
		end
		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
		def updated_at_greater_than_or_equal=(val)
			@updated_at_greater_than_or_equal = val.to_i
		end
		def updated_at_less_than_or_equal=(val)
			@updated_at_less_than_or_equal = val.to_i
		end
	end

	class KalturaPermissionItemFilter < KalturaPermissionItemBaseFilter

	end

	class KalturaPermissionItemListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaPermission < KalturaObjectBase
		attr_accessor :id
		attr_accessor :type
		attr_accessor :name
		attr_accessor :friendly_name
		attr_accessor :description
		attr_accessor :status
		attr_accessor :partner_id
		attr_accessor :depends_on_permission_names
		attr_accessor :tags
		attr_accessor :permission_items_ids
		attr_accessor :created_at
		attr_accessor :updated_at
		attr_accessor :partner_group

		def id=(val)
			@id = val.to_i
		end
		def type=(val)
			@type = val.to_i
		end
		def status=(val)
			@status = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
	end

	class KalturaPermissionBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :id_in
		attr_accessor :type_equal
		attr_accessor :type_in
		attr_accessor :name_equal
		attr_accessor :name_in
		attr_accessor :friendly_name_like
		attr_accessor :description_like
		attr_accessor :status_equal
		attr_accessor :status_in
		attr_accessor :partner_id_equal
		attr_accessor :partner_id_in
		attr_accessor :depends_on_permission_names_multi_like_or
		attr_accessor :depends_on_permission_names_multi_like_and
		attr_accessor :tags_multi_like_or
		attr_accessor :tags_multi_like_and
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal
		attr_accessor :updated_at_greater_than_or_equal
		attr_accessor :updated_at_less_than_or_equal

		def id_equal=(val)
			@id_equal = val.to_i
		end
		def type_equal=(val)
			@type_equal = val.to_i
		end
		def status_equal=(val)
			@status_equal = val.to_i
		end
		def partner_id_equal=(val)
			@partner_id_equal = val.to_i
		end
		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
		def updated_at_greater_than_or_equal=(val)
			@updated_at_greater_than_or_equal = val.to_i
		end
		def updated_at_less_than_or_equal=(val)
			@updated_at_less_than_or_equal = val.to_i
		end
	end

	class KalturaPermissionFilter < KalturaPermissionBaseFilter

	end

	class KalturaPermissionListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaMediaEntryFilterForPlaylist < KalturaMediaEntryFilter
		attr_accessor :limit

		def limit=(val)
			@limit = val.to_i
		end
	end

	class KalturaPlaylist < KalturaBaseEntry
		attr_accessor :playlist_content
		attr_accessor :filters
		attr_accessor :total_results
		attr_accessor :playlist_type
		attr_accessor :plays
		attr_accessor :views
		attr_accessor :duration

		def total_results=(val)
			@total_results = val.to_i
		end
		def playlist_type=(val)
			@playlist_type = val.to_i
		end
		def plays=(val)
			@plays = val.to_i
		end
		def views=(val)
			@views = val.to_i
		end
		def duration=(val)
			@duration = val.to_i
		end
	end

	class KalturaPlaylistBaseFilter < KalturaBaseEntryFilter

	end

	class KalturaPlaylistFilter < KalturaPlaylistBaseFilter

	end

	class KalturaPlaylistListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaReportInputFilter < KalturaObjectBase
		attr_accessor :from_date
		attr_accessor :to_date
		attr_accessor :keywords
		attr_accessor :search_in_tags
		attr_accessor :search_in_admin_tags
		attr_accessor :categories
		attr_accessor :time_zone_offset

		def from_date=(val)
			@from_date = val.to_i
		end
		def to_date=(val)
			@to_date = val.to_i
		end
		def search_in_tags=(val)
			@search_in_tags = to_b(val)
		end
		def search_in_admin_tags=(val)
			@search_in_admin_tags = to_b(val)
		end
		def time_zone_offset=(val)
			@time_zone_offset = val.to_i
		end
	end

	class KalturaReportGraph < KalturaObjectBase
		attr_accessor :id
		attr_accessor :data

	end

	class KalturaReportTotal < KalturaObjectBase
		attr_accessor :header
		attr_accessor :data

	end

	class KalturaReportTable < KalturaObjectBase
		attr_accessor :header
		attr_accessor :data
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaSearchResultResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :need_media_info

		def need_media_info=(val)
			@need_media_info = to_b(val)
		end
	end

	class KalturaSearchAuthData < KalturaObjectBase
		attr_accessor :auth_data
		attr_accessor :login_url
		attr_accessor :message

	end

	class KalturaStartWidgetSessionResponse < KalturaObjectBase
		attr_accessor :partner_id
		attr_accessor :ks
		attr_accessor :user_id

		def partner_id=(val)
			@partner_id = val.to_i
		end
	end

	class KalturaStatsEvent < KalturaObjectBase
		attr_accessor :client_ver
		attr_accessor :event_type
		attr_accessor :event_timestamp
		attr_accessor :session_id
		attr_accessor :partner_id
		attr_accessor :entry_id
		attr_accessor :unique_viewer
		attr_accessor :widget_id
		attr_accessor :uiconf_id
		attr_accessor :user_id
		attr_accessor :current_point
		attr_accessor :duration
		attr_accessor :user_ip
		attr_accessor :process_duration
		attr_accessor :control_id
		attr_accessor :seek
		attr_accessor :new_point
		attr_accessor :referrer
		attr_accessor :is_first_in_session

		def event_type=(val)
			@event_type = val.to_i
		end
		def event_timestamp=(val)
			@event_timestamp = val.to_f
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def uiconf_id=(val)
			@uiconf_id = val.to_i
		end
		def current_point=(val)
			@current_point = val.to_i
		end
		def duration=(val)
			@duration = val.to_i
		end
		def process_duration=(val)
			@process_duration = val.to_i
		end
		def seek=(val)
			@seek = to_b(val)
		end
		def new_point=(val)
			@new_point = val.to_i
		end
		def is_first_in_session=(val)
			@is_first_in_session = to_b(val)
		end
	end

	class KalturaStatsKmcEvent < KalturaObjectBase
		attr_accessor :client_ver
		attr_accessor :kmc_event_action_path
		attr_accessor :kmc_event_type
		attr_accessor :event_timestamp
		attr_accessor :session_id
		attr_accessor :partner_id
		attr_accessor :entry_id
		attr_accessor :widget_id
		attr_accessor :uiconf_id
		attr_accessor :user_id
		attr_accessor :user_ip

		def kmc_event_type=(val)
			@kmc_event_type = val.to_i
		end
		def event_timestamp=(val)
			@event_timestamp = val.to_f
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def uiconf_id=(val)
			@uiconf_id = val.to_i
		end
	end

	class KalturaCEError < KalturaObjectBase
		attr_accessor :id
		attr_accessor :partner_id
		attr_accessor :browser
		attr_accessor :server_ip
		attr_accessor :server_os
		attr_accessor :php_version
		attr_accessor :ce_admin_email
		attr_accessor :type
		attr_accessor :description
		attr_accessor :data

		def partner_id=(val)
			@partner_id = val.to_i
		end
	end

	class KalturaBaseSyndicationFeed < KalturaObjectBase
		attr_accessor :id
		attr_accessor :feed_url
		attr_accessor :partner_id
		attr_accessor :playlist_id
		attr_accessor :name
		attr_accessor :status
		attr_accessor :type
		attr_accessor :landing_page
		attr_accessor :created_at
		attr_accessor :allow_embed
		attr_accessor :player_uiconf_id
		attr_accessor :flavor_param_id
		attr_accessor :transcode_existing_content
		attr_accessor :add_to_default_conversion_profile
		attr_accessor :categories

		def partner_id=(val)
			@partner_id = val.to_i
		end
		def status=(val)
			@status = val.to_i
		end
		def type=(val)
			@type = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def allow_embed=(val)
			@allow_embed = to_b(val)
		end
		def player_uiconf_id=(val)
			@player_uiconf_id = val.to_i
		end
		def flavor_param_id=(val)
			@flavor_param_id = val.to_i
		end
		def transcode_existing_content=(val)
			@transcode_existing_content = to_b(val)
		end
		def add_to_default_conversion_profile=(val)
			@add_to_default_conversion_profile = to_b(val)
		end
	end

	class KalturaBaseSyndicationFeedBaseFilter < KalturaFilter

	end

	class KalturaBaseSyndicationFeedFilter < KalturaBaseSyndicationFeedBaseFilter

	end

	class KalturaBaseSyndicationFeedListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaSyndicationFeedEntryCount < KalturaObjectBase
		attr_accessor :total_entry_count
		attr_accessor :actual_entry_count
		attr_accessor :require_transcoding_count

		def total_entry_count=(val)
			@total_entry_count = val.to_i
		end
		def actual_entry_count=(val)
			@actual_entry_count = val.to_i
		end
		def require_transcoding_count=(val)
			@require_transcoding_count = val.to_i
		end
	end

	class KalturaThumbAsset < KalturaAsset
		attr_accessor :thumb_params_id
		attr_accessor :width
		attr_accessor :height

		def thumb_params_id=(val)
			@thumb_params_id = val.to_i
		end
		def width=(val)
			@width = val.to_i
		end
		def height=(val)
			@height = val.to_i
		end
	end

	class KalturaThumbParams < KalturaAssetParams
		attr_accessor :crop_type
		attr_accessor :quality
		attr_accessor :crop_x
		attr_accessor :crop_y
		attr_accessor :crop_width
		attr_accessor :crop_height
		attr_accessor :video_offset
		attr_accessor :width
		attr_accessor :height
		attr_accessor :scale_width
		attr_accessor :scale_height
		attr_accessor :background_color
		attr_accessor :source_params_id

		def crop_type=(val)
			@crop_type = val.to_i
		end
		def quality=(val)
			@quality = val.to_i
		end
		def crop_x=(val)
			@crop_x = val.to_i
		end
		def crop_y=(val)
			@crop_y = val.to_i
		end
		def crop_width=(val)
			@crop_width = val.to_i
		end
		def crop_height=(val)
			@crop_height = val.to_i
		end
		def video_offset=(val)
			@video_offset = val.to_i
		end
		def width=(val)
			@width = val.to_i
		end
		def height=(val)
			@height = val.to_i
		end
		def scale_width=(val)
			@scale_width = val.to_f
		end
		def scale_height=(val)
			@scale_height = val.to_f
		end
		def source_params_id=(val)
			@source_params_id = val.to_i
		end
	end

	class KalturaThumbAssetListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaThumbParamsBaseFilter < KalturaAssetParamsFilter

	end

	class KalturaThumbParamsFilter < KalturaThumbParamsBaseFilter

	end

	class KalturaThumbParamsListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaUiConf < KalturaObjectBase
		attr_accessor :id
		attr_accessor :name
		attr_accessor :description
		attr_accessor :partner_id
		attr_accessor :obj_type
		attr_accessor :obj_type_as_string
		attr_accessor :width
		attr_accessor :height
		attr_accessor :html_params
		attr_accessor :swf_url
		attr_accessor :conf_file_path
		attr_accessor :conf_file
		attr_accessor :conf_file_features
		attr_accessor :conf_vars
		attr_accessor :use_cdn
		attr_accessor :tags
		attr_accessor :swf_url_version
		attr_accessor :created_at
		attr_accessor :updated_at
		attr_accessor :creation_mode

		def id=(val)
			@id = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def obj_type=(val)
			@obj_type = val.to_i
		end
		def width=(val)
			@width = val.to_i
		end
		def height=(val)
			@height = val.to_i
		end
		def use_cdn=(val)
			@use_cdn = to_b(val)
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
		def creation_mode=(val)
			@creation_mode = val.to_i
		end
	end

	class KalturaUiConfBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :id_in
		attr_accessor :name_like
		attr_accessor :partner_id_equal
		attr_accessor :partner_id_in
		attr_accessor :obj_type_equal
		attr_accessor :obj_type_in
		attr_accessor :tags_multi_like_or
		attr_accessor :tags_multi_like_and
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal
		attr_accessor :updated_at_greater_than_or_equal
		attr_accessor :updated_at_less_than_or_equal
		attr_accessor :creation_mode_equal
		attr_accessor :creation_mode_in

		def id_equal=(val)
			@id_equal = val.to_i
		end
		def partner_id_equal=(val)
			@partner_id_equal = val.to_i
		end
		def obj_type_equal=(val)
			@obj_type_equal = val.to_i
		end
		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
		def updated_at_greater_than_or_equal=(val)
			@updated_at_greater_than_or_equal = val.to_i
		end
		def updated_at_less_than_or_equal=(val)
			@updated_at_less_than_or_equal = val.to_i
		end
		def creation_mode_equal=(val)
			@creation_mode_equal = val.to_i
		end
	end

	class KalturaUiConfFilter < KalturaUiConfBaseFilter

	end

	class KalturaUiConfListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaUiConfTypeInfo < KalturaObjectBase
		attr_accessor :type
		attr_accessor :versions
		attr_accessor :directory
		attr_accessor :filename

		def type=(val)
			@type = val.to_i
		end
	end

	class KalturaUploadResponse < KalturaObjectBase
		attr_accessor :upload_token_id
		attr_accessor :file_size
		attr_accessor :error_code
		attr_accessor :error_description

		def file_size=(val)
			@file_size = val.to_i
		end
		def error_code=(val)
			@error_code = val.to_i
		end
	end

	class KalturaUploadToken < KalturaObjectBase
		attr_accessor :id
		attr_accessor :partner_id
		attr_accessor :user_id
		attr_accessor :status
		attr_accessor :file_name
		attr_accessor :file_size
		attr_accessor :uploaded_file_size
		attr_accessor :created_at
		attr_accessor :updated_at

		def partner_id=(val)
			@partner_id = val.to_i
		end
		def status=(val)
			@status = val.to_i
		end
		def file_size=(val)
			@file_size = val.to_f
		end
		def uploaded_file_size=(val)
			@uploaded_file_size = val.to_f
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
	end

	class KalturaUploadTokenBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :id_in
		attr_accessor :user_id_equal
		attr_accessor :status_equal
		attr_accessor :status_in

		def status_equal=(val)
			@status_equal = val.to_i
		end
	end

	class KalturaUploadTokenFilter < KalturaUploadTokenBaseFilter

	end

	class KalturaUploadTokenListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaUserRole < KalturaObjectBase
		attr_accessor :id
		attr_accessor :name
		attr_accessor :description
		attr_accessor :status
		attr_accessor :partner_id
		attr_accessor :permission_names
		attr_accessor :tags
		attr_accessor :created_at
		attr_accessor :updated_at

		def id=(val)
			@id = val.to_i
		end
		def status=(val)
			@status = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
	end

	class KalturaUserRoleBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :id_in
		attr_accessor :name_equal
		attr_accessor :name_in
		attr_accessor :description_like
		attr_accessor :status_equal
		attr_accessor :status_in
		attr_accessor :partner_id_equal
		attr_accessor :partner_id_in
		attr_accessor :tags_multi_like_or
		attr_accessor :tags_multi_like_and
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal
		attr_accessor :updated_at_greater_than_or_equal
		attr_accessor :updated_at_less_than_or_equal

		def id_equal=(val)
			@id_equal = val.to_i
		end
		def status_equal=(val)
			@status_equal = val.to_i
		end
		def partner_id_equal=(val)
			@partner_id_equal = val.to_i
		end
		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
		def updated_at_greater_than_or_equal=(val)
			@updated_at_greater_than_or_equal = val.to_i
		end
		def updated_at_less_than_or_equal=(val)
			@updated_at_less_than_or_equal = val.to_i
		end
	end

	class KalturaUserRoleFilter < KalturaUserRoleBaseFilter

	end

	class KalturaUserRoleListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaUserBaseFilter < KalturaFilter
		attr_accessor :partner_id_equal
		attr_accessor :screen_name_like
		attr_accessor :screen_name_starts_with
		attr_accessor :email_like
		attr_accessor :email_starts_with
		attr_accessor :tags_multi_like_or
		attr_accessor :tags_multi_like_and
		attr_accessor :status_equal
		attr_accessor :status_in
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal
		attr_accessor :is_admin_equal

		def partner_id_equal=(val)
			@partner_id_equal = val.to_i
		end
		def status_equal=(val)
			@status_equal = val.to_i
		end
		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
		def is_admin_equal=(val)
			@is_admin_equal = to_b(val)
		end
	end

	class KalturaUserFilter < KalturaUserBaseFilter
		attr_accessor :id_equal
		attr_accessor :id_in
		attr_accessor :login_enabled_equal

		def login_enabled_equal=(val)
			@login_enabled_equal = to_b(val)
		end
	end

	class KalturaUserListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaWidget < KalturaObjectBase
		attr_accessor :id
		attr_accessor :source_widget_id
		attr_accessor :root_widget_id
		attr_accessor :partner_id
		attr_accessor :entry_id
		attr_accessor :ui_conf_id
		attr_accessor :security_type
		attr_accessor :security_policy
		attr_accessor :created_at
		attr_accessor :updated_at
		attr_accessor :partner_data
		attr_accessor :widget_ht_ml

		def partner_id=(val)
			@partner_id = val.to_i
		end
		def ui_conf_id=(val)
			@ui_conf_id = val.to_i
		end
		def security_type=(val)
			@security_type = val.to_i
		end
		def security_policy=(val)
			@security_policy = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
	end

	class KalturaWidgetBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :id_in
		attr_accessor :source_widget_id_equal
		attr_accessor :root_widget_id_equal
		attr_accessor :partner_id_equal
		attr_accessor :entry_id_equal
		attr_accessor :ui_conf_id_equal
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal
		attr_accessor :updated_at_greater_than_or_equal
		attr_accessor :updated_at_less_than_or_equal
		attr_accessor :partner_data_like

		def partner_id_equal=(val)
			@partner_id_equal = val.to_i
		end
		def ui_conf_id_equal=(val)
			@ui_conf_id_equal = val.to_i
		end
		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
		def updated_at_greater_than_or_equal=(val)
			@updated_at_greater_than_or_equal = val.to_i
		end
		def updated_at_less_than_or_equal=(val)
			@updated_at_less_than_or_equal = val.to_i
		end
	end

	class KalturaWidgetFilter < KalturaWidgetBaseFilter

	end

	class KalturaWidgetListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaMetadataBaseFilter < KalturaFilter
		attr_accessor :partner_id_equal
		attr_accessor :metadata_profile_id_equal
		attr_accessor :metadata_profile_version_equal
		attr_accessor :metadata_profile_version_greater_than_or_equal
		attr_accessor :metadata_profile_version_less_than_or_equal
		attr_accessor :metadata_object_type_equal
		attr_accessor :object_id_equal
		attr_accessor :object_id_in
		attr_accessor :version_equal
		attr_accessor :version_greater_than_or_equal
		attr_accessor :version_less_than_or_equal
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal
		attr_accessor :updated_at_greater_than_or_equal
		attr_accessor :updated_at_less_than_or_equal
		attr_accessor :status_equal
		attr_accessor :status_in

		def partner_id_equal=(val)
			@partner_id_equal = val.to_i
		end
		def metadata_profile_id_equal=(val)
			@metadata_profile_id_equal = val.to_i
		end
		def metadata_profile_version_equal=(val)
			@metadata_profile_version_equal = val.to_i
		end
		def metadata_profile_version_greater_than_or_equal=(val)
			@metadata_profile_version_greater_than_or_equal = val.to_i
		end
		def metadata_profile_version_less_than_or_equal=(val)
			@metadata_profile_version_less_than_or_equal = val.to_i
		end
		def metadata_object_type_equal=(val)
			@metadata_object_type_equal = val.to_i
		end
		def version_equal=(val)
			@version_equal = val.to_i
		end
		def version_greater_than_or_equal=(val)
			@version_greater_than_or_equal = val.to_i
		end
		def version_less_than_or_equal=(val)
			@version_less_than_or_equal = val.to_i
		end
		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
		def updated_at_greater_than_or_equal=(val)
			@updated_at_greater_than_or_equal = val.to_i
		end
		def updated_at_less_than_or_equal=(val)
			@updated_at_less_than_or_equal = val.to_i
		end
		def status_equal=(val)
			@status_equal = val.to_i
		end
	end

	class KalturaMetadataFilter < KalturaMetadataBaseFilter

	end

	class KalturaMetadata < KalturaObjectBase
		attr_accessor :id
		attr_accessor :partner_id
		attr_accessor :metadata_profile_id
		attr_accessor :metadata_profile_version
		attr_accessor :metadata_object_type
		attr_accessor :object_id
		attr_accessor :version
		attr_accessor :created_at
		attr_accessor :updated_at
		attr_accessor :status
		attr_accessor :xml

		def id=(val)
			@id = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def metadata_profile_id=(val)
			@metadata_profile_id = val.to_i
		end
		def metadata_profile_version=(val)
			@metadata_profile_version = val.to_i
		end
		def metadata_object_type=(val)
			@metadata_object_type = val.to_i
		end
		def version=(val)
			@version = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
		def status=(val)
			@status = val.to_i
		end
	end

	class KalturaMetadataListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaMetadataProfileBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :partner_id_equal
		attr_accessor :metadata_object_type_equal
		attr_accessor :version_equal
		attr_accessor :name_equal
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal
		attr_accessor :updated_at_greater_than_or_equal
		attr_accessor :updated_at_less_than_or_equal
		attr_accessor :status_equal
		attr_accessor :status_in

		def id_equal=(val)
			@id_equal = val.to_i
		end
		def partner_id_equal=(val)
			@partner_id_equal = val.to_i
		end
		def metadata_object_type_equal=(val)
			@metadata_object_type_equal = val.to_i
		end
		def version_equal=(val)
			@version_equal = val.to_i
		end
		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
		def updated_at_greater_than_or_equal=(val)
			@updated_at_greater_than_or_equal = val.to_i
		end
		def updated_at_less_than_or_equal=(val)
			@updated_at_less_than_or_equal = val.to_i
		end
		def status_equal=(val)
			@status_equal = val.to_i
		end
	end

	class KalturaMetadataProfileFilter < KalturaMetadataProfileBaseFilter

	end

	class KalturaMetadataProfile < KalturaObjectBase
		attr_accessor :id
		attr_accessor :partner_id
		attr_accessor :metadata_object_type
		attr_accessor :version
		attr_accessor :name
		attr_accessor :created_at
		attr_accessor :updated_at
		attr_accessor :status
		attr_accessor :xsd
		attr_accessor :views

		def id=(val)
			@id = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def metadata_object_type=(val)
			@metadata_object_type = val.to_i
		end
		def version=(val)
			@version = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
		def status=(val)
			@status = val.to_i
		end
	end

	class KalturaMetadataProfileListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaMetadataProfileField < KalturaObjectBase
		attr_accessor :id
		attr_accessor :x_path
		attr_accessor :key
		attr_accessor :label

		def id=(val)
			@id = val.to_i
		end
	end

	class KalturaMetadataProfileFieldListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaPartnerBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :id_in
		attr_accessor :name_like
		attr_accessor :name_multi_like_or
		attr_accessor :name_multi_like_and
		attr_accessor :name_equal
		attr_accessor :status_equal
		attr_accessor :status_in
		attr_accessor :partner_name_description_website_admin_name_admin_email_like

		def id_equal=(val)
			@id_equal = val.to_i
		end
		def status_equal=(val)
			@status_equal = val.to_i
		end
	end

	class KalturaPartnerFilter < KalturaPartnerBaseFilter

	end

	class KalturaStorageProfile < KalturaObjectBase
		attr_accessor :id
		attr_accessor :created_at
		attr_accessor :updated_at
		attr_accessor :partner_id
		attr_accessor :name
		attr_accessor :desciption
		attr_accessor :status
		attr_accessor :protocol
		attr_accessor :storage_url
		attr_accessor :storage_base_dir
		attr_accessor :storage_username
		attr_accessor :storage_password
		attr_accessor :storage_ftp_passive_mode
		attr_accessor :delivery_http_base_url
		attr_accessor :delivery_rmp_base_url
		attr_accessor :delivery_iis_base_url
		attr_accessor :min_file_size
		attr_accessor :max_file_size
		attr_accessor :flavor_params_ids
		attr_accessor :max_concurrent_connections
		attr_accessor :path_manager_class
		attr_accessor :url_manager_class
		attr_accessor :trigger

		def id=(val)
			@id = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def status=(val)
			@status = val.to_i
		end
		def protocol=(val)
			@protocol = val.to_i
		end
		def storage_ftp_passive_mode=(val)
			@storage_ftp_passive_mode = to_b(val)
		end
		def min_file_size=(val)
			@min_file_size = val.to_i
		end
		def max_file_size=(val)
			@max_file_size = val.to_i
		end
		def max_concurrent_connections=(val)
			@max_concurrent_connections = val.to_i
		end
		def trigger=(val)
			@trigger = val.to_i
		end
	end

	class KalturaStorageProfileListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaSystemPartnerUsageFilter < KalturaFilter
		attr_accessor :from_date
		attr_accessor :to_date

		def from_date=(val)
			@from_date = val.to_i
		end
		def to_date=(val)
			@to_date = val.to_i
		end
	end

	class KalturaSystemPartnerUsageItem < KalturaObjectBase
		attr_accessor :partner_id
		attr_accessor :partner_name
		attr_accessor :partner_status
		attr_accessor :partner_package
		attr_accessor :partner_created_at
		attr_accessor :views
		attr_accessor :plays
		attr_accessor :entries_count
		attr_accessor :total_entries_count
		attr_accessor :video_entries_count
		attr_accessor :image_entries_count
		attr_accessor :audio_entries_count
		attr_accessor :mix_entries_count
		attr_accessor :bandwidth
		attr_accessor :total_storage
		attr_accessor :storage

		def partner_id=(val)
			@partner_id = val.to_i
		end
		def partner_status=(val)
			@partner_status = val.to_i
		end
		def partner_package=(val)
			@partner_package = val.to_i
		end
		def partner_created_at=(val)
			@partner_created_at = val.to_i
		end
		def views=(val)
			@views = val.to_i
		end
		def plays=(val)
			@plays = val.to_i
		end
		def entries_count=(val)
			@entries_count = val.to_i
		end
		def total_entries_count=(val)
			@total_entries_count = val.to_i
		end
		def video_entries_count=(val)
			@video_entries_count = val.to_i
		end
		def image_entries_count=(val)
			@image_entries_count = val.to_i
		end
		def audio_entries_count=(val)
			@audio_entries_count = val.to_i
		end
		def mix_entries_count=(val)
			@mix_entries_count = val.to_i
		end
		def bandwidth=(val)
			@bandwidth = val.to_f
		end
		def total_storage=(val)
			@total_storage = val.to_f
		end
		def storage=(val)
			@storage = val.to_f
		end
	end

	class KalturaSystemPartnerUsageListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaPartnerListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaSystemPartnerConfiguration < KalturaObjectBase
		attr_accessor :partner_name
		attr_accessor :description
		attr_accessor :admin_name
		attr_accessor :admin_email
		attr_accessor :host
		attr_accessor :cdn_host
		attr_accessor :max_bulk_size
		attr_accessor :partner_package
		attr_accessor :monitor_usage
		attr_accessor :live_stream_enabled
		attr_accessor :moderate_content
		attr_accessor :rtmp_url
		attr_accessor :storage_delete_from_kaltura
		attr_accessor :storage_serve_priority
		attr_accessor :kmc_version
		attr_accessor :enable_analytics_tab
		attr_accessor :enable_silver_light
		attr_accessor :enable_vast
		attr_accessor :enable508players
		attr_accessor :enable_metadata
		attr_accessor :enable_content_distribution
		attr_accessor :enable_audit_trail
		attr_accessor :enable_annotation
		attr_accessor :enable_mobile_flavors
		attr_accessor :enable_ps2permission_validation
		attr_accessor :def_thumb_offset
		attr_accessor :admin_login_users_quota
		attr_accessor :user_session_role_id
		attr_accessor :admin_session_role_id
		attr_accessor :always_allowed_permission_names

		def max_bulk_size=(val)
			@max_bulk_size = val.to_i
		end
		def partner_package=(val)
			@partner_package = val.to_i
		end
		def monitor_usage=(val)
			@monitor_usage = val.to_i
		end
		def live_stream_enabled=(val)
			@live_stream_enabled = to_b(val)
		end
		def moderate_content=(val)
			@moderate_content = to_b(val)
		end
		def storage_delete_from_kaltura=(val)
			@storage_delete_from_kaltura = to_b(val)
		end
		def storage_serve_priority=(val)
			@storage_serve_priority = val.to_i
		end
		def kmc_version=(val)
			@kmc_version = val.to_i
		end
		def enable_analytics_tab=(val)
			@enable_analytics_tab = to_b(val)
		end
		def enable_silver_light=(val)
			@enable_silver_light = to_b(val)
		end
		def enable_vast=(val)
			@enable_vast = to_b(val)
		end
		def enable508players=(val)
			@enable508players = to_b(val)
		end
		def enable_metadata=(val)
			@enable_metadata = to_b(val)
		end
		def enable_content_distribution=(val)
			@enable_content_distribution = to_b(val)
		end
		def enable_audit_trail=(val)
			@enable_audit_trail = to_b(val)
		end
		def enable_annotation=(val)
			@enable_annotation = to_b(val)
		end
		def enable_mobile_flavors=(val)
			@enable_mobile_flavors = to_b(val)
		end
		def enable_ps2permission_validation=(val)
			@enable_ps2permission_validation = to_b(val)
		end
		def def_thumb_offset=(val)
			@def_thumb_offset = val.to_i
		end
		def admin_login_users_quota=(val)
			@admin_login_users_quota = val.to_i
		end
		def user_session_role_id=(val)
			@user_session_role_id = val.to_i
		end
		def admin_session_role_id=(val)
			@admin_session_role_id = val.to_i
		end
	end

	class KalturaSystemPartnerPackage < KalturaObjectBase
		attr_accessor :id
		attr_accessor :name

		def id=(val)
			@id = val.to_i
		end
	end

	class KalturaFlavorParamsOutputBaseFilter < KalturaFlavorParamsFilter
		attr_accessor :flavor_params_id_equal
		attr_accessor :flavor_params_version_equal
		attr_accessor :flavor_asset_id_equal
		attr_accessor :flavor_asset_version_equal

		def flavor_params_id_equal=(val)
			@flavor_params_id_equal = val.to_i
		end
	end

	class KalturaFlavorParamsOutputFilter < KalturaFlavorParamsOutputBaseFilter

	end

	class KalturaFlavorParamsOutput < KalturaFlavorParams
		attr_accessor :flavor_params_id
		attr_accessor :command_lines_str
		attr_accessor :flavor_params_version
		attr_accessor :flavor_asset_id
		attr_accessor :flavor_asset_version
		attr_accessor :ready_behavior

		def flavor_params_id=(val)
			@flavor_params_id = val.to_i
		end
		def ready_behavior=(val)
			@ready_behavior = val.to_i
		end
	end

	class KalturaFlavorParamsOutputListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaThumbParamsOutputBaseFilter < KalturaThumbParamsFilter
		attr_accessor :thumb_params_id_equal
		attr_accessor :thumb_params_version_equal
		attr_accessor :thumb_asset_id_equal
		attr_accessor :thumb_asset_version_equal

		def thumb_params_id_equal=(val)
			@thumb_params_id_equal = val.to_i
		end
	end

	class KalturaThumbParamsOutputFilter < KalturaThumbParamsOutputBaseFilter

	end

	class KalturaThumbParamsOutput < KalturaThumbParams
		attr_accessor :thumb_params_id
		attr_accessor :thumb_params_version
		attr_accessor :thumb_asset_id
		attr_accessor :thumb_asset_version

		def thumb_params_id=(val)
			@thumb_params_id = val.to_i
		end
	end

	class KalturaThumbParamsOutputListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaMediaInfoBaseFilter < KalturaFilter
		attr_accessor :flavor_asset_id_equal

	end

	class KalturaMediaInfoFilter < KalturaMediaInfoBaseFilter

	end

	class KalturaMediaInfo < KalturaObjectBase
		attr_accessor :id
		attr_accessor :flavor_asset_id
		attr_accessor :file_size
		attr_accessor :container_format
		attr_accessor :container_id
		attr_accessor :container_profile
		attr_accessor :container_duration
		attr_accessor :container_bit_rate
		attr_accessor :video_format
		attr_accessor :video_codec_id
		attr_accessor :video_duration
		attr_accessor :video_bit_rate
		attr_accessor :video_bit_rate_mode
		attr_accessor :video_width
		attr_accessor :video_height
		attr_accessor :video_frame_rate
		attr_accessor :video_dar
		attr_accessor :video_rotation
		attr_accessor :audio_format
		attr_accessor :audio_codec_id
		attr_accessor :audio_duration
		attr_accessor :audio_bit_rate
		attr_accessor :audio_bit_rate_mode
		attr_accessor :audio_channels
		attr_accessor :audio_sampling_rate
		attr_accessor :audio_resolution
		attr_accessor :writing_lib
		attr_accessor :raw_data
		attr_accessor :multi_stream_info
		attr_accessor :scan_type
		attr_accessor :multi_stream

		def id=(val)
			@id = val.to_i
		end
		def file_size=(val)
			@file_size = val.to_i
		end
		def container_duration=(val)
			@container_duration = val.to_i
		end
		def container_bit_rate=(val)
			@container_bit_rate = val.to_i
		end
		def video_duration=(val)
			@video_duration = val.to_i
		end
		def video_bit_rate=(val)
			@video_bit_rate = val.to_i
		end
		def video_bit_rate_mode=(val)
			@video_bit_rate_mode = val.to_i
		end
		def video_width=(val)
			@video_width = val.to_i
		end
		def video_height=(val)
			@video_height = val.to_i
		end
		def video_frame_rate=(val)
			@video_frame_rate = val.to_f
		end
		def video_dar=(val)
			@video_dar = val.to_f
		end
		def video_rotation=(val)
			@video_rotation = val.to_i
		end
		def audio_duration=(val)
			@audio_duration = val.to_i
		end
		def audio_bit_rate=(val)
			@audio_bit_rate = val.to_i
		end
		def audio_bit_rate_mode=(val)
			@audio_bit_rate_mode = val.to_i
		end
		def audio_channels=(val)
			@audio_channels = val.to_i
		end
		def audio_sampling_rate=(val)
			@audio_sampling_rate = val.to_i
		end
		def audio_resolution=(val)
			@audio_resolution = val.to_i
		end
		def scan_type=(val)
			@scan_type = val.to_i
		end
	end

	class KalturaMediaInfoListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaTrackEntry < KalturaObjectBase
		attr_accessor :id
		attr_accessor :track_event_type
		attr_accessor :ps_version
		attr_accessor :context
		attr_accessor :partner_id
		attr_accessor :entry_id
		attr_accessor :host_name
		attr_accessor :user_id
		attr_accessor :changed_properties
		attr_accessor :param_str1
		attr_accessor :param_str2
		attr_accessor :param_str3
		attr_accessor :ks
		attr_accessor :description
		attr_accessor :created_at
		attr_accessor :updated_at
		attr_accessor :user_ip

		def id=(val)
			@id = val.to_i
		end
		def track_event_type=(val)
			@track_event_type = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
	end

	class KalturaTrackEntryListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaInternalToolsSession < KalturaObjectBase
		attr_accessor :partner_id
		attr_accessor :valid_until
		attr_accessor :partner_pattern
		attr_accessor :type
		attr_accessor :error
		attr_accessor :rand
		attr_accessor :user
		attr_accessor :privileges

		def partner_id=(val)
			@partner_id = val.to_i
		end
		def valid_until=(val)
			@valid_until = val.to_i
		end
		def type=(val)
			@type = val.to_i
		end
		def rand=(val)
			@rand = val.to_i
		end
	end

	class KalturaAuditTrailBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal
		attr_accessor :parsed_at_greater_than_or_equal
		attr_accessor :parsed_at_less_than_or_equal
		attr_accessor :status_equal
		attr_accessor :status_in
		attr_accessor :audit_object_type_equal
		attr_accessor :audit_object_type_in
		attr_accessor :object_id_equal
		attr_accessor :object_id_in
		attr_accessor :related_object_id_equal
		attr_accessor :related_object_id_in
		attr_accessor :related_object_type_equal
		attr_accessor :related_object_type_in
		attr_accessor :entry_id_equal
		attr_accessor :entry_id_in
		attr_accessor :master_partner_id_equal
		attr_accessor :master_partner_id_in
		attr_accessor :partner_id_equal
		attr_accessor :partner_id_in
		attr_accessor :request_id_equal
		attr_accessor :request_id_in
		attr_accessor :user_id_equal
		attr_accessor :user_id_in
		attr_accessor :action_equal
		attr_accessor :action_in
		attr_accessor :ks_equal
		attr_accessor :context_equal
		attr_accessor :context_in
		attr_accessor :entry_point_equal
		attr_accessor :entry_point_in
		attr_accessor :server_name_equal
		attr_accessor :server_name_in
		attr_accessor :ip_address_equal
		attr_accessor :ip_address_in
		attr_accessor :client_tag_equal

		def id_equal=(val)
			@id_equal = val.to_i
		end
		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
		def parsed_at_greater_than_or_equal=(val)
			@parsed_at_greater_than_or_equal = val.to_i
		end
		def parsed_at_less_than_or_equal=(val)
			@parsed_at_less_than_or_equal = val.to_i
		end
		def status_equal=(val)
			@status_equal = val.to_i
		end
		def master_partner_id_equal=(val)
			@master_partner_id_equal = val.to_i
		end
		def partner_id_equal=(val)
			@partner_id_equal = val.to_i
		end
		def context_equal=(val)
			@context_equal = val.to_i
		end
	end

	class KalturaAuditTrailFilter < KalturaAuditTrailBaseFilter

	end

	class KalturaAuditTrailInfo < KalturaObjectBase

	end

	class KalturaAuditTrail < KalturaObjectBase
		attr_accessor :id
		attr_accessor :created_at
		attr_accessor :parsed_at
		attr_accessor :status
		attr_accessor :audit_object_type
		attr_accessor :object_id
		attr_accessor :related_object_id
		attr_accessor :related_object_type
		attr_accessor :entry_id
		attr_accessor :master_partner_id
		attr_accessor :partner_id
		attr_accessor :request_id
		attr_accessor :user_id
		attr_accessor :action
		attr_accessor :data
		attr_accessor :ks
		attr_accessor :context
		attr_accessor :entry_point
		attr_accessor :server_name
		attr_accessor :ip_address
		attr_accessor :user_agent
		attr_accessor :client_tag
		attr_accessor :description
		attr_accessor :error_description

		def id=(val)
			@id = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def parsed_at=(val)
			@parsed_at = val.to_i
		end
		def status=(val)
			@status = val.to_i
		end
		def master_partner_id=(val)
			@master_partner_id = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def context=(val)
			@context = val.to_i
		end
	end

	class KalturaAuditTrailListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaVirusScanProfileBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :id_in
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal
		attr_accessor :updated_at_greater_than_or_equal
		attr_accessor :updated_at_less_than_or_equal
		attr_accessor :partner_id_equal
		attr_accessor :partner_id_in
		attr_accessor :status_equal
		attr_accessor :status_in
		attr_accessor :engine_type_equal
		attr_accessor :engine_type_in

		def id_equal=(val)
			@id_equal = val.to_i
		end
		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
		def updated_at_greater_than_or_equal=(val)
			@updated_at_greater_than_or_equal = val.to_i
		end
		def updated_at_less_than_or_equal=(val)
			@updated_at_less_than_or_equal = val.to_i
		end
		def partner_id_equal=(val)
			@partner_id_equal = val.to_i
		end
		def status_equal=(val)
			@status_equal = val.to_i
		end
	end

	class KalturaVirusScanProfileFilter < KalturaVirusScanProfileBaseFilter

	end

	class KalturaVirusScanProfile < KalturaObjectBase
		attr_accessor :id
		attr_accessor :created_at
		attr_accessor :updated_at
		attr_accessor :partner_id
		attr_accessor :name
		attr_accessor :status
		attr_accessor :engine_type
		attr_accessor :entry_filter
		attr_accessor :action_if_infected

		def id=(val)
			@id = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def status=(val)
			@status = val.to_i
		end
		def action_if_infected=(val)
			@action_if_infected = val.to_i
		end
	end

	class KalturaVirusScanProfileListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaDistributionThumbDimensions < KalturaObjectBase
		attr_accessor :width
		attr_accessor :height

		def width=(val)
			@width = val.to_i
		end
		def height=(val)
			@height = val.to_i
		end
	end

	class KalturaDistributionProfile < KalturaObjectBase
		attr_accessor :id
		attr_accessor :created_at
		attr_accessor :updated_at
		attr_accessor :partner_id
		attr_accessor :provider_type
		attr_accessor :name
		attr_accessor :status
		attr_accessor :submit_enabled
		attr_accessor :update_enabled
		attr_accessor :delete_enabled
		attr_accessor :report_enabled
		attr_accessor :auto_create_flavors
		attr_accessor :auto_create_thumb
		attr_accessor :optional_flavor_params_ids
		attr_accessor :required_flavor_params_ids
		attr_accessor :optional_thumb_dimensions
		attr_accessor :required_thumb_dimensions
		attr_accessor :sunrise_default_offset
		attr_accessor :sunset_default_offset

		def id=(val)
			@id = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def status=(val)
			@status = val.to_i
		end
		def submit_enabled=(val)
			@submit_enabled = val.to_i
		end
		def update_enabled=(val)
			@update_enabled = val.to_i
		end
		def delete_enabled=(val)
			@delete_enabled = val.to_i
		end
		def report_enabled=(val)
			@report_enabled = val.to_i
		end
		def sunrise_default_offset=(val)
			@sunrise_default_offset = val.to_i
		end
		def sunset_default_offset=(val)
			@sunset_default_offset = val.to_i
		end
	end

	class KalturaDistributionProfileBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :id_in
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal
		attr_accessor :updated_at_greater_than_or_equal
		attr_accessor :updated_at_less_than_or_equal

		def id_equal=(val)
			@id_equal = val.to_i
		end
		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
		def updated_at_greater_than_or_equal=(val)
			@updated_at_greater_than_or_equal = val.to_i
		end
		def updated_at_less_than_or_equal=(val)
			@updated_at_less_than_or_equal = val.to_i
		end
	end

	class KalturaDistributionProfileFilter < KalturaDistributionProfileBaseFilter

	end

	class KalturaDistributionProfileListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaDistributionValidationError < KalturaObjectBase
		attr_accessor :action
		attr_accessor :error_type
		attr_accessor :description

		def action=(val)
			@action = val.to_i
		end
		def error_type=(val)
			@error_type = val.to_i
		end
	end

	class KalturaEntryDistribution < KalturaObjectBase
		attr_accessor :id
		attr_accessor :created_at
		attr_accessor :updated_at
		attr_accessor :submitted_at
		attr_accessor :entry_id
		attr_accessor :partner_id
		attr_accessor :distribution_profile_id
		attr_accessor :status
		attr_accessor :dirty_status
		attr_accessor :thumb_asset_ids
		attr_accessor :flavor_asset_ids
		attr_accessor :sunrise
		attr_accessor :sunset
		attr_accessor :remote_id
		attr_accessor :plays
		attr_accessor :views
		attr_accessor :validation_errors
		attr_accessor :error_type
		attr_accessor :error_number
		attr_accessor :error_description
		attr_accessor :has_submit_results_log
		attr_accessor :has_submit_sent_data_log
		attr_accessor :has_update_results_log
		attr_accessor :has_update_sent_data_log
		attr_accessor :has_delete_results_log
		attr_accessor :has_delete_sent_data_log

		def id=(val)
			@id = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
		def submitted_at=(val)
			@submitted_at = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def distribution_profile_id=(val)
			@distribution_profile_id = val.to_i
		end
		def status=(val)
			@status = val.to_i
		end
		def dirty_status=(val)
			@dirty_status = val.to_i
		end
		def sunrise=(val)
			@sunrise = val.to_i
		end
		def sunset=(val)
			@sunset = val.to_i
		end
		def plays=(val)
			@plays = val.to_i
		end
		def views=(val)
			@views = val.to_i
		end
		def error_type=(val)
			@error_type = val.to_i
		end
		def error_number=(val)
			@error_number = val.to_i
		end
		def has_submit_results_log=(val)
			@has_submit_results_log = val.to_i
		end
		def has_submit_sent_data_log=(val)
			@has_submit_sent_data_log = val.to_i
		end
		def has_update_results_log=(val)
			@has_update_results_log = val.to_i
		end
		def has_update_sent_data_log=(val)
			@has_update_sent_data_log = val.to_i
		end
		def has_delete_results_log=(val)
			@has_delete_results_log = val.to_i
		end
		def has_delete_sent_data_log=(val)
			@has_delete_sent_data_log = val.to_i
		end
	end

	class KalturaEntryDistributionBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :id_in
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal
		attr_accessor :updated_at_greater_than_or_equal
		attr_accessor :updated_at_less_than_or_equal
		attr_accessor :submitted_at_greater_than_or_equal
		attr_accessor :submitted_at_less_than_or_equal
		attr_accessor :entry_id_equal
		attr_accessor :entry_id_in
		attr_accessor :distribution_profile_id_equal
		attr_accessor :distribution_profile_id_in
		attr_accessor :status_equal
		attr_accessor :status_in
		attr_accessor :dirty_status_equal
		attr_accessor :dirty_status_in
		attr_accessor :sunrise_greater_than_or_equal
		attr_accessor :sunrise_less_than_or_equal
		attr_accessor :sunset_greater_than_or_equal
		attr_accessor :sunset_less_than_or_equal

		def id_equal=(val)
			@id_equal = val.to_i
		end
		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
		def updated_at_greater_than_or_equal=(val)
			@updated_at_greater_than_or_equal = val.to_i
		end
		def updated_at_less_than_or_equal=(val)
			@updated_at_less_than_or_equal = val.to_i
		end
		def submitted_at_greater_than_or_equal=(val)
			@submitted_at_greater_than_or_equal = val.to_i
		end
		def submitted_at_less_than_or_equal=(val)
			@submitted_at_less_than_or_equal = val.to_i
		end
		def distribution_profile_id_equal=(val)
			@distribution_profile_id_equal = val.to_i
		end
		def status_equal=(val)
			@status_equal = val.to_i
		end
		def dirty_status_equal=(val)
			@dirty_status_equal = val.to_i
		end
		def sunrise_greater_than_or_equal=(val)
			@sunrise_greater_than_or_equal = val.to_i
		end
		def sunrise_less_than_or_equal=(val)
			@sunrise_less_than_or_equal = val.to_i
		end
		def sunset_greater_than_or_equal=(val)
			@sunset_greater_than_or_equal = val.to_i
		end
		def sunset_less_than_or_equal=(val)
			@sunset_less_than_or_equal = val.to_i
		end
	end

	class KalturaEntryDistributionFilter < KalturaEntryDistributionBaseFilter

	end

	class KalturaEntryDistributionListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaDistributionProviderBaseFilter < KalturaFilter
		attr_accessor :type_equal
		attr_accessor :type_in

	end

	class KalturaDistributionProviderFilter < KalturaDistributionProviderBaseFilter

	end

	class KalturaDistributionProvider < KalturaObjectBase
		attr_accessor :type
		attr_accessor :name
		attr_accessor :schedule_update_enabled
		attr_accessor :delete_instead_update
		attr_accessor :interval_before_sunrise
		attr_accessor :interval_before_sunset
		attr_accessor :update_required_entry_fields
		attr_accessor :update_required_metadata_xpaths

		def schedule_update_enabled=(val)
			@schedule_update_enabled = to_b(val)
		end
		def delete_instead_update=(val)
			@delete_instead_update = to_b(val)
		end
		def interval_before_sunrise=(val)
			@interval_before_sunrise = val.to_i
		end
		def interval_before_sunset=(val)
			@interval_before_sunset = val.to_i
		end
	end

	class KalturaDistributionProviderListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaGenericDistributionProvider < KalturaDistributionProvider
		attr_accessor :id
		attr_accessor :created_at
		attr_accessor :updated_at
		attr_accessor :partner_id
		attr_accessor :is_default
		attr_accessor :status
		attr_accessor :optional_flavor_params_ids
		attr_accessor :required_flavor_params_ids
		attr_accessor :optional_thumb_dimensions
		attr_accessor :required_thumb_dimensions
		attr_accessor :editable_fields
		attr_accessor :mandatory_fields

		def id=(val)
			@id = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def is_default=(val)
			@is_default = to_b(val)
		end
		def status=(val)
			@status = val.to_i
		end
	end

	class KalturaGenericDistributionProviderBaseFilter < KalturaDistributionProviderFilter
		attr_accessor :id_equal
		attr_accessor :id_in
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal
		attr_accessor :updated_at_greater_than_or_equal
		attr_accessor :updated_at_less_than_or_equal
		attr_accessor :partner_id_equal
		attr_accessor :partner_id_in
		attr_accessor :is_default_equal
		attr_accessor :is_default_in
		attr_accessor :status_equal
		attr_accessor :status_in

		def id_equal=(val)
			@id_equal = val.to_i
		end
		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
		def updated_at_greater_than_or_equal=(val)
			@updated_at_greater_than_or_equal = val.to_i
		end
		def updated_at_less_than_or_equal=(val)
			@updated_at_less_than_or_equal = val.to_i
		end
		def partner_id_equal=(val)
			@partner_id_equal = val.to_i
		end
		def is_default_equal=(val)
			@is_default_equal = to_b(val)
		end
		def status_equal=(val)
			@status_equal = val.to_i
		end
	end

	class KalturaGenericDistributionProviderFilter < KalturaGenericDistributionProviderBaseFilter

	end

	class KalturaGenericDistributionProviderListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaGenericDistributionProviderAction < KalturaObjectBase
		attr_accessor :id
		attr_accessor :created_at
		attr_accessor :updated_at
		attr_accessor :generic_distribution_provider_id
		attr_accessor :action
		attr_accessor :status
		attr_accessor :results_parser
		attr_accessor :protocol
		attr_accessor :server_address
		attr_accessor :remote_path
		attr_accessor :remote_username
		attr_accessor :remote_password
		attr_accessor :editable_fields
		attr_accessor :mandatory_fields
		attr_accessor :mrss_transformer
		attr_accessor :mrss_validator
		attr_accessor :results_transformer

		def id=(val)
			@id = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
		def generic_distribution_provider_id=(val)
			@generic_distribution_provider_id = val.to_i
		end
		def action=(val)
			@action = val.to_i
		end
		def status=(val)
			@status = val.to_i
		end
		def results_parser=(val)
			@results_parser = val.to_i
		end
		def protocol=(val)
			@protocol = val.to_i
		end
	end

	class KalturaGenericDistributionProviderActionBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :id_in
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal
		attr_accessor :updated_at_greater_than_or_equal
		attr_accessor :updated_at_less_than_or_equal
		attr_accessor :generic_distribution_provider_id_equal
		attr_accessor :generic_distribution_provider_id_in
		attr_accessor :action_equal
		attr_accessor :action_in

		def id_equal=(val)
			@id_equal = val.to_i
		end
		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
		def updated_at_greater_than_or_equal=(val)
			@updated_at_greater_than_or_equal = val.to_i
		end
		def updated_at_less_than_or_equal=(val)
			@updated_at_less_than_or_equal = val.to_i
		end
		def generic_distribution_provider_id_equal=(val)
			@generic_distribution_provider_id_equal = val.to_i
		end
		def action_equal=(val)
			@action_equal = val.to_i
		end
	end

	class KalturaGenericDistributionProviderActionFilter < KalturaGenericDistributionProviderActionBaseFilter

	end

	class KalturaGenericDistributionProviderActionListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaAnnotationBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :entry_id_equal
		attr_accessor :parent_id_equal
		attr_accessor :parent_id_in
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal
		attr_accessor :updated_at_greater_than_or_equal
		attr_accessor :updated_at_less_than_or_equal
		attr_accessor :user_id_equal
		attr_accessor :user_id_in

		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
		def updated_at_greater_than_or_equal=(val)
			@updated_at_greater_than_or_equal = val.to_i
		end
		def updated_at_less_than_or_equal=(val)
			@updated_at_less_than_or_equal = val.to_i
		end
	end

	class KalturaAnnotationFilter < KalturaAnnotationBaseFilter

	end

	class KalturaAnnotation < KalturaObjectBase
		attr_accessor :id
		attr_accessor :entry_id
		attr_accessor :partner_id
		attr_accessor :parent_id
		attr_accessor :created_at
		attr_accessor :updated_at
		attr_accessor :text
		attr_accessor :tags
		attr_accessor :start_time
		attr_accessor :end_time
		attr_accessor :user_id
		attr_accessor :partner_data

		def partner_id=(val)
			@partner_id = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
		def start_time=(val)
			@start_time = val.to_i
		end
		def end_time=(val)
			@end_time = val.to_i
		end
	end

	class KalturaAnnotationListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaShortLinkBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :id_in
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal
		attr_accessor :updated_at_greater_than_or_equal
		attr_accessor :updated_at_less_than_or_equal
		attr_accessor :expires_at_greater_than_or_equal
		attr_accessor :expires_at_less_than_or_equal
		attr_accessor :partner_id_equal
		attr_accessor :partner_id_in
		attr_accessor :user_id_equal
		attr_accessor :user_id_in
		attr_accessor :system_name_equal
		attr_accessor :system_name_in
		attr_accessor :status_equal
		attr_accessor :status_in

		def id_equal=(val)
			@id_equal = val.to_i
		end
		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
		def updated_at_greater_than_or_equal=(val)
			@updated_at_greater_than_or_equal = val.to_i
		end
		def updated_at_less_than_or_equal=(val)
			@updated_at_less_than_or_equal = val.to_i
		end
		def expires_at_greater_than_or_equal=(val)
			@expires_at_greater_than_or_equal = val.to_i
		end
		def expires_at_less_than_or_equal=(val)
			@expires_at_less_than_or_equal = val.to_i
		end
		def partner_id_equal=(val)
			@partner_id_equal = val.to_i
		end
		def status_equal=(val)
			@status_equal = val.to_i
		end
	end

	class KalturaShortLinkFilter < KalturaShortLinkBaseFilter

	end

	class KalturaShortLink < KalturaObjectBase
		attr_accessor :id
		attr_accessor :created_at
		attr_accessor :updated_at
		attr_accessor :expires_at
		attr_accessor :partner_id
		attr_accessor :user_id
		attr_accessor :name
		attr_accessor :system_name
		attr_accessor :full_url
		attr_accessor :status

		def id=(val)
			@id = val.to_i
		end
		def created_at=(val)
			@created_at = val.to_i
		end
		def updated_at=(val)
			@updated_at = val.to_i
		end
		def expires_at=(val)
			@expires_at = val.to_i
		end
		def partner_id=(val)
			@partner_id = val.to_i
		end
		def status=(val)
			@status = val.to_i
		end
	end

	class KalturaShortLinkListResponse < KalturaObjectBase
		attr_accessor :objects
		attr_accessor :total_count

		def total_count=(val)
			@total_count = val.to_i
		end
	end

	class KalturaCountryRestriction < KalturaBaseRestriction
		attr_accessor :country_restriction_type
		attr_accessor :country_list

		def country_restriction_type=(val)
			@country_restriction_type = val.to_i
		end
	end

	class KalturaDirectoryRestriction < KalturaBaseRestriction
		attr_accessor :directory_restriction_type

		def directory_restriction_type=(val)
			@directory_restriction_type = val.to_i
		end
	end

	class KalturaIpAddressRestriction < KalturaBaseRestriction
		attr_accessor :ip_address_restriction_type
		attr_accessor :ip_address_list

		def ip_address_restriction_type=(val)
			@ip_address_restriction_type = val.to_i
		end
	end

	class KalturaSessionRestriction < KalturaBaseRestriction

	end

	class KalturaPreviewRestriction < KalturaSessionRestriction
		attr_accessor :preview_length

		def preview_length=(val)
			@preview_length = val.to_i
		end
	end

	class KalturaSiteRestriction < KalturaBaseRestriction
		attr_accessor :site_restriction_type
		attr_accessor :site_list

		def site_restriction_type=(val)
			@site_restriction_type = val.to_i
		end
	end

	class KalturaSearchCondition < KalturaSearchItem
		attr_accessor :field
		attr_accessor :value

	end

	class KalturaSearchComparableCondition < KalturaSearchCondition
		attr_accessor :comparison

		def comparison=(val)
			@comparison = val.to_i
		end
	end

	class KalturaSearchOperator < KalturaSearchItem
		attr_accessor :type
		attr_accessor :items

		def type=(val)
			@type = val.to_i
		end
	end

	class KalturaBaseJobBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :id_greater_than_or_equal
		attr_accessor :partner_id_equal
		attr_accessor :partner_id_in
		attr_accessor :partner_id_not_in
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal
		attr_accessor :updated_at_greater_than_or_equal
		attr_accessor :updated_at_less_than_or_equal
		attr_accessor :processor_expiration_greater_than_or_equal
		attr_accessor :processor_expiration_less_than_or_equal
		attr_accessor :execution_attempts_greater_than_or_equal
		attr_accessor :execution_attempts_less_than_or_equal
		attr_accessor :lock_version_greater_than_or_equal
		attr_accessor :lock_version_less_than_or_equal

		def id_equal=(val)
			@id_equal = val.to_i
		end
		def id_greater_than_or_equal=(val)
			@id_greater_than_or_equal = val.to_i
		end
		def partner_id_equal=(val)
			@partner_id_equal = val.to_i
		end
		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
		def updated_at_greater_than_or_equal=(val)
			@updated_at_greater_than_or_equal = val.to_i
		end
		def updated_at_less_than_or_equal=(val)
			@updated_at_less_than_or_equal = val.to_i
		end
		def processor_expiration_greater_than_or_equal=(val)
			@processor_expiration_greater_than_or_equal = val.to_i
		end
		def processor_expiration_less_than_or_equal=(val)
			@processor_expiration_less_than_or_equal = val.to_i
		end
		def execution_attempts_greater_than_or_equal=(val)
			@execution_attempts_greater_than_or_equal = val.to_i
		end
		def execution_attempts_less_than_or_equal=(val)
			@execution_attempts_less_than_or_equal = val.to_i
		end
		def lock_version_greater_than_or_equal=(val)
			@lock_version_greater_than_or_equal = val.to_i
		end
		def lock_version_less_than_or_equal=(val)
			@lock_version_less_than_or_equal = val.to_i
		end
	end

	class KalturaBaseJobFilter < KalturaBaseJobBaseFilter

	end

	class KalturaBatchJobBaseFilter < KalturaBaseJobFilter
		attr_accessor :entry_id_equal
		attr_accessor :job_type_equal
		attr_accessor :job_type_in
		attr_accessor :job_type_not_in
		attr_accessor :job_sub_type_equal
		attr_accessor :job_sub_type_in
		attr_accessor :job_sub_type_not_in
		attr_accessor :on_stress_divert_to_equal
		attr_accessor :on_stress_divert_to_in
		attr_accessor :on_stress_divert_to_not_in
		attr_accessor :status_equal
		attr_accessor :status_in
		attr_accessor :status_not_in
		attr_accessor :abort_equal
		attr_accessor :check_again_timeout_greater_than_or_equal
		attr_accessor :check_again_timeout_less_than_or_equal
		attr_accessor :progress_greater_than_or_equal
		attr_accessor :progress_less_than_or_equal
		attr_accessor :updates_count_greater_than_or_equal
		attr_accessor :updates_count_less_than_or_equal
		attr_accessor :priority_greater_than_or_equal
		attr_accessor :priority_less_than_or_equal
		attr_accessor :priority_equal
		attr_accessor :priority_in
		attr_accessor :priority_not_in
		attr_accessor :twin_job_id_equal
		attr_accessor :twin_job_id_in
		attr_accessor :twin_job_id_not_in
		attr_accessor :bulk_job_id_equal
		attr_accessor :bulk_job_id_in
		attr_accessor :bulk_job_id_not_in
		attr_accessor :parent_job_id_equal
		attr_accessor :parent_job_id_in
		attr_accessor :parent_job_id_not_in
		attr_accessor :root_job_id_equal
		attr_accessor :root_job_id_in
		attr_accessor :root_job_id_not_in
		attr_accessor :queue_time_greater_than_or_equal
		attr_accessor :queue_time_less_than_or_equal
		attr_accessor :finish_time_greater_than_or_equal
		attr_accessor :finish_time_less_than_or_equal
		attr_accessor :err_type_equal
		attr_accessor :err_type_in
		attr_accessor :err_type_not_in
		attr_accessor :err_number_equal
		attr_accessor :err_number_in
		attr_accessor :err_number_not_in
		attr_accessor :file_size_less_than
		attr_accessor :file_size_greater_than
		attr_accessor :last_worker_remote_equal
		attr_accessor :scheduler_id_equal
		attr_accessor :scheduler_id_in
		attr_accessor :scheduler_id_not_in
		attr_accessor :worker_id_equal
		attr_accessor :worker_id_in
		attr_accessor :worker_id_not_in
		attr_accessor :batch_index_equal
		attr_accessor :batch_index_in
		attr_accessor :batch_index_not_in
		attr_accessor :last_scheduler_id_equal
		attr_accessor :last_scheduler_id_in
		attr_accessor :last_scheduler_id_not_in
		attr_accessor :last_worker_id_equal
		attr_accessor :last_worker_id_in
		attr_accessor :last_worker_id_not_in
		attr_accessor :dc_equal
		attr_accessor :dc_in
		attr_accessor :dc_not_in

		def job_sub_type_equal=(val)
			@job_sub_type_equal = val.to_i
		end
		def on_stress_divert_to_equal=(val)
			@on_stress_divert_to_equal = val.to_i
		end
		def status_equal=(val)
			@status_equal = val.to_i
		end
		def abort_equal=(val)
			@abort_equal = val.to_i
		end
		def check_again_timeout_greater_than_or_equal=(val)
			@check_again_timeout_greater_than_or_equal = val.to_i
		end
		def check_again_timeout_less_than_or_equal=(val)
			@check_again_timeout_less_than_or_equal = val.to_i
		end
		def progress_greater_than_or_equal=(val)
			@progress_greater_than_or_equal = val.to_i
		end
		def progress_less_than_or_equal=(val)
			@progress_less_than_or_equal = val.to_i
		end
		def updates_count_greater_than_or_equal=(val)
			@updates_count_greater_than_or_equal = val.to_i
		end
		def updates_count_less_than_or_equal=(val)
			@updates_count_less_than_or_equal = val.to_i
		end
		def priority_greater_than_or_equal=(val)
			@priority_greater_than_or_equal = val.to_i
		end
		def priority_less_than_or_equal=(val)
			@priority_less_than_or_equal = val.to_i
		end
		def priority_equal=(val)
			@priority_equal = val.to_i
		end
		def twin_job_id_equal=(val)
			@twin_job_id_equal = val.to_i
		end
		def bulk_job_id_equal=(val)
			@bulk_job_id_equal = val.to_i
		end
		def parent_job_id_equal=(val)
			@parent_job_id_equal = val.to_i
		end
		def root_job_id_equal=(val)
			@root_job_id_equal = val.to_i
		end
		def queue_time_greater_than_or_equal=(val)
			@queue_time_greater_than_or_equal = val.to_i
		end
		def queue_time_less_than_or_equal=(val)
			@queue_time_less_than_or_equal = val.to_i
		end
		def finish_time_greater_than_or_equal=(val)
			@finish_time_greater_than_or_equal = val.to_i
		end
		def finish_time_less_than_or_equal=(val)
			@finish_time_less_than_or_equal = val.to_i
		end
		def err_type_equal=(val)
			@err_type_equal = val.to_i
		end
		def err_number_equal=(val)
			@err_number_equal = val.to_i
		end
		def file_size_less_than=(val)
			@file_size_less_than = val.to_i
		end
		def file_size_greater_than=(val)
			@file_size_greater_than = val.to_i
		end
		def last_worker_remote_equal=(val)
			@last_worker_remote_equal = to_b(val)
		end
		def scheduler_id_equal=(val)
			@scheduler_id_equal = val.to_i
		end
		def worker_id_equal=(val)
			@worker_id_equal = val.to_i
		end
		def batch_index_equal=(val)
			@batch_index_equal = val.to_i
		end
		def last_scheduler_id_equal=(val)
			@last_scheduler_id_equal = val.to_i
		end
		def last_worker_id_equal=(val)
			@last_worker_id_equal = val.to_i
		end
		def dc_equal=(val)
			@dc_equal = val.to_i
		end
	end

	class KalturaBatchJobFilter < KalturaBatchJobBaseFilter

	end

	class KalturaBatchJobFilterExt < KalturaBatchJobFilter
		attr_accessor :job_type_and_sub_type_in

	end

	class KalturaControlPanelCommandBaseFilter < KalturaFilter
		attr_accessor :id_equal
		attr_accessor :id_in
		attr_accessor :created_at_greater_than_or_equal
		attr_accessor :created_at_less_than_or_equal
		attr_accessor :created_by_id_equal
		attr_accessor :type_equal
		attr_accessor :type_in
		attr_accessor :target_type_equal
		attr_accessor :target_type_in
		attr_accessor :status_equal
		attr_accessor :status_in

		def id_equal=(val)
			@id_equal = val.to_i
		end
		def created_at_greater_than_or_equal=(val)
			@created_at_greater_than_or_equal = val.to_i
		end
		def created_at_less_than_or_equal=(val)
			@created_at_less_than_or_equal = val.to_i
		end
		def created_by_id_equal=(val)
			@created_by_id_equal = val.to_i
		end
		def type_equal=(val)
			@type_equal = val.to_i
		end
		def target_type_equal=(val)
			@target_type_equal = val.to_i
		end
		def status_equal=(val)
			@status_equal = val.to_i
		end
	end

	class KalturaControlPanelCommandFilter < KalturaControlPanelCommandBaseFilter

	end

	class KalturaMailJobBaseFilter < KalturaBaseJobFilter

	end

	class KalturaMailJobFilter < KalturaMailJobBaseFilter

	end

	class KalturaNotificationBaseFilter < KalturaBaseJobFilter

	end

	class KalturaNotificationFilter < KalturaNotificationBaseFilter

	end

	class KalturaAssetParamsOutputBaseFilter < KalturaAssetParamsFilter
		attr_accessor :asset_params_id_equal
		attr_accessor :asset_params_version_equal
		attr_accessor :asset_id_equal
		attr_accessor :asset_version_equal

		def asset_params_id_equal=(val)
			@asset_params_id_equal = val.to_i
		end
	end

	class KalturaAssetParamsOutputFilter < KalturaAssetParamsOutputBaseFilter

	end

	class KalturaFlavorAssetBaseFilter < KalturaAssetFilter

	end

	class KalturaFlavorAssetFilter < KalturaFlavorAssetBaseFilter

	end

	class KalturaMediaFlavorParamsBaseFilter < KalturaFlavorParamsFilter

	end

	class KalturaMediaFlavorParamsFilter < KalturaMediaFlavorParamsBaseFilter

	end

	class KalturaMediaFlavorParamsOutputBaseFilter < KalturaFlavorParamsOutputFilter

	end

	class KalturaMediaFlavorParamsOutputFilter < KalturaMediaFlavorParamsOutputBaseFilter

	end

	class KalturaThumbAssetBaseFilter < KalturaAssetFilter

	end

	class KalturaThumbAssetFilter < KalturaThumbAssetBaseFilter

	end

	class KalturaLiveStreamAdminEntryBaseFilter < KalturaLiveStreamEntryFilter

	end

	class KalturaLiveStreamAdminEntryFilter < KalturaLiveStreamAdminEntryBaseFilter

	end

	class KalturaAdminUserBaseFilter < KalturaUserFilter

	end

	class KalturaAdminUserFilter < KalturaAdminUserBaseFilter

	end

	class KalturaGoogleVideoSyndicationFeedBaseFilter < KalturaBaseSyndicationFeedFilter

	end

	class KalturaGoogleVideoSyndicationFeedFilter < KalturaGoogleVideoSyndicationFeedBaseFilter

	end

	class KalturaITunesSyndicationFeedBaseFilter < KalturaBaseSyndicationFeedFilter

	end

	class KalturaITunesSyndicationFeedFilter < KalturaITunesSyndicationFeedBaseFilter

	end

	class KalturaTubeMogulSyndicationFeedBaseFilter < KalturaBaseSyndicationFeedFilter

	end

	class KalturaTubeMogulSyndicationFeedFilter < KalturaTubeMogulSyndicationFeedBaseFilter

	end

	class KalturaYahooSyndicationFeedBaseFilter < KalturaBaseSyndicationFeedFilter

	end

	class KalturaYahooSyndicationFeedFilter < KalturaYahooSyndicationFeedBaseFilter

	end

	class KalturaApiActionPermissionItemBaseFilter < KalturaPermissionItemFilter

	end

	class KalturaApiActionPermissionItemFilter < KalturaApiActionPermissionItemBaseFilter

	end

	class KalturaApiParameterPermissionItemBaseFilter < KalturaPermissionItemFilter

	end

	class KalturaApiParameterPermissionItemFilter < KalturaApiParameterPermissionItemBaseFilter

	end

	class KalturaGenericSyndicationFeedBaseFilter < KalturaBaseSyndicationFeedFilter

	end

	class KalturaGenericSyndicationFeedFilter < KalturaGenericSyndicationFeedBaseFilter

	end

	class KalturaGenericXsltSyndicationFeedBaseFilter < KalturaGenericSyndicationFeedFilter

	end

	class KalturaGenericXsltSyndicationFeedFilter < KalturaGenericXsltSyndicationFeedBaseFilter

	end

	class KalturaAssetParamsOutput < KalturaAssetParams
		attr_accessor :asset_params_id
		attr_accessor :asset_params_version
		attr_accessor :asset_id
		attr_accessor :asset_version
		attr_accessor :ready_behavior

		def asset_params_id=(val)
			@asset_params_id = val.to_i
		end
		def ready_behavior=(val)
			@ready_behavior = val.to_i
		end
	end

	class KalturaMediaFlavorParams < KalturaFlavorParams

	end

	class KalturaMediaFlavorParamsOutput < KalturaFlavorParamsOutput

	end

	class KalturaApiActionPermissionItem < KalturaPermissionItem
		attr_accessor :service
		attr_accessor :action

	end

	class KalturaApiParameterPermissionItem < KalturaPermissionItem
		attr_accessor :object
		attr_accessor :parameter
		attr_accessor :action

	end

	class KalturaGenericSyndicationFeed < KalturaBaseSyndicationFeed
		attr_accessor :feed_description
		attr_accessor :feed_landing_page

	end

	class KalturaGenericXsltSyndicationFeed < KalturaGenericSyndicationFeed
		attr_accessor :xslt

	end

	class KalturaGoogleVideoSyndicationFeed < KalturaBaseSyndicationFeed
		attr_accessor :adult_content

	end

	class KalturaITunesSyndicationFeed < KalturaBaseSyndicationFeed
		attr_accessor :feed_description
		attr_accessor :language
		attr_accessor :feed_landing_page
		attr_accessor :owner_name
		attr_accessor :owner_email
		attr_accessor :feed_image_url
		attr_accessor :category
		attr_accessor :adult_content
		attr_accessor :feed_author

	end

	class KalturaTubeMogulSyndicationFeed < KalturaBaseSyndicationFeed
		attr_accessor :category

	end

	class KalturaYahooSyndicationFeed < KalturaBaseSyndicationFeed
		attr_accessor :category
		attr_accessor :adult_content
		attr_accessor :feed_description
		attr_accessor :feed_landing_page

	end


	class KalturaAccessControlService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(access_control)
			kparams = {}
			client.add_param(kparams, 'accessControl', access_control);
			client.queue_service_action_call('accessControl', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('accessControl', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(id, access_control)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'accessControl', access_control);
			client.queue_service_action_call('accessControl', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('accessControl', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('accessControl', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaAdminUserService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def update_password(email, password, new_email='', new_password='')
			kparams = {}
			client.add_param(kparams, 'email', email);
			client.add_param(kparams, 'password', password);
			client.add_param(kparams, 'newEmail', new_email);
			client.add_param(kparams, 'newPassword', new_password);
			client.queue_service_action_call('adminUser', 'updatePassword', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def reset_password(email)
			kparams = {}
			client.add_param(kparams, 'email', email);
			client.queue_service_action_call('adminUser', 'resetPassword', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def login(email, password, partner_id='')
			kparams = {}
			client.add_param(kparams, 'email', email);
			client.add_param(kparams, 'password', password);
			client.add_param(kparams, 'partnerId', partner_id);
			client.queue_service_action_call('adminUser', 'login', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def set_initial_password(hash_key, new_password)
			kparams = {}
			client.add_param(kparams, 'hashKey', hash_key);
			client.add_param(kparams, 'newPassword', new_password);
			client.queue_service_action_call('adminUser', 'setInitialPassword', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaBaseEntryService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add_from_uploaded_file(entry, upload_token_id, type='null')
			kparams = {}
			client.add_param(kparams, 'entry', entry);
			client.add_param(kparams, 'uploadTokenId', upload_token_id);
			client.add_param(kparams, 'type', type);
			client.queue_service_action_call('baseEntry', 'addFromUploadedFile', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(entry_id, version=-1)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'version', version);
			client.queue_service_action_call('baseEntry', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(entry_id, base_entry)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'baseEntry', base_entry);
			client.queue_service_action_call('baseEntry', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_by_ids(entry_ids)
			kparams = {}
			client.add_param(kparams, 'entryIds', entry_ids);
			client.queue_service_action_call('baseEntry', 'getByIds', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(entry_id)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.queue_service_action_call('baseEntry', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('baseEntry', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def count(filter=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.queue_service_action_call('baseEntry', 'count', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def upload(file_data)
			kparams = {}
			client.add_param(kparams, 'fileData', file_data);
			client.queue_service_action_call('baseEntry', 'upload', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update_thumbnail_jpeg(entry_id, file_data)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'fileData', file_data);
			client.queue_service_action_call('baseEntry', 'updateThumbnailJpeg', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update_thumbnail_from_url(entry_id, url)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'url', url);
			client.queue_service_action_call('baseEntry', 'updateThumbnailFromUrl', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update_thumbnail_from_source_entry(entry_id, source_entry_id, time_offset)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'sourceEntryId', source_entry_id);
			client.add_param(kparams, 'timeOffset', time_offset);
			client.queue_service_action_call('baseEntry', 'updateThumbnailFromSourceEntry', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def flag(moderation_flag)
			kparams = {}
			client.add_param(kparams, 'moderationFlag', moderation_flag);
			client.queue_service_action_call('baseEntry', 'flag', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def reject(entry_id)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.queue_service_action_call('baseEntry', 'reject', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def approve(entry_id)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.queue_service_action_call('baseEntry', 'approve', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list_flags(entry_id, pager=nil)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('baseEntry', 'listFlags', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def anonymous_rank(entry_id, rank)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'rank', rank);
			client.queue_service_action_call('baseEntry', 'anonymousRank', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_context_data(entry_id, context_data_params)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'contextDataParams', context_data_params);
			client.queue_service_action_call('baseEntry', 'getContextData', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaBulkUploadService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(conversion_profile_id, csv_file_data)
			kparams = {}
			client.add_param(kparams, 'conversionProfileId', conversion_profile_id);
			client.add_param(kparams, 'csvFileData', csv_file_data);
			client.queue_service_action_call('bulkUpload', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('bulkUpload', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(pager=nil)
			kparams = {}
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('bulkUpload', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaCategoryService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(category)
			kparams = {}
			client.add_param(kparams, 'category', category);
			client.queue_service_action_call('category', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('category', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(id, category)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'category', category);
			client.queue_service_action_call('category', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('category', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.queue_service_action_call('category', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaConversionProfileService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(conversion_profile)
			kparams = {}
			client.add_param(kparams, 'conversionProfile', conversion_profile);
			client.queue_service_action_call('conversionProfile', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('conversionProfile', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(id, conversion_profile)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'conversionProfile', conversion_profile);
			client.queue_service_action_call('conversionProfile', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('conversionProfile', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('conversionProfile', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaDataService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(data_entry)
			kparams = {}
			client.add_param(kparams, 'dataEntry', data_entry);
			client.queue_service_action_call('data', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(entry_id, version=-1)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'version', version);
			client.queue_service_action_call('data', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(entry_id, document_entry)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'documentEntry', document_entry);
			client.queue_service_action_call('data', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(entry_id)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.queue_service_action_call('data', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('data', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaEmailIngestionProfileService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(email_ip)
			kparams = {}
			client.add_param(kparams, 'EmailIP', email_ip);
			client.queue_service_action_call('EmailIngestionProfile', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_by_email_address(email_address)
			kparams = {}
			client.add_param(kparams, 'emailAddress', email_address);
			client.queue_service_action_call('EmailIngestionProfile', 'getByEmailAddress', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('EmailIngestionProfile', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(id, email_ip)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'EmailIP', email_ip);
			client.queue_service_action_call('EmailIngestionProfile', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('EmailIngestionProfile', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add_media_entry(media_entry, upload_token_id, email_prof_id, from_address, email_msg_id)
			kparams = {}
			client.add_param(kparams, 'mediaEntry', media_entry);
			client.add_param(kparams, 'uploadTokenId', upload_token_id);
			client.add_param(kparams, 'emailProfId', email_prof_id);
			client.add_param(kparams, 'fromAddress', from_address);
			client.add_param(kparams, 'emailMsgId', email_msg_id);
			client.queue_service_action_call('EmailIngestionProfile', 'addMediaEntry', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaFlavorAssetService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('flavorAsset', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_by_entry_id(entry_id)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.queue_service_action_call('flavorAsset', 'getByEntryId', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('flavorAsset', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_web_playable_by_entry_id(entry_id)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.queue_service_action_call('flavorAsset', 'getWebPlayableByEntryId', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def convert(entry_id, flavor_params_id)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'flavorParamsId', flavor_params_id);
			client.queue_service_action_call('flavorAsset', 'convert', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def reconvert(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('flavorAsset', 'reconvert', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('flavorAsset', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_download_url(id, use_cdn=false)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'useCdn', use_cdn);
			client.queue_service_action_call('flavorAsset', 'getDownloadUrl', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_flavor_assets_with_params(entry_id)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.queue_service_action_call('flavorAsset', 'getFlavorAssetsWithParams', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaFlavorParamsService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(flavor_params)
			kparams = {}
			client.add_param(kparams, 'flavorParams', flavor_params);
			client.queue_service_action_call('flavorParams', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('flavorParams', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(id, flavor_params)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'flavorParams', flavor_params);
			client.queue_service_action_call('flavorParams', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('flavorParams', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('flavorParams', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_by_conversion_profile_id(conversion_profile_id)
			kparams = {}
			client.add_param(kparams, 'conversionProfileId', conversion_profile_id);
			client.queue_service_action_call('flavorParams', 'getByConversionProfileId', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaLiveStreamService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(live_stream_entry, source_type='')
			kparams = {}
			client.add_param(kparams, 'liveStreamEntry', live_stream_entry);
			client.add_param(kparams, 'sourceType', source_type);
			client.queue_service_action_call('liveStream', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(entry_id, version=-1)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'version', version);
			client.queue_service_action_call('liveStream', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(entry_id, live_stream_entry)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'liveStreamEntry', live_stream_entry);
			client.queue_service_action_call('liveStream', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(entry_id)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.queue_service_action_call('liveStream', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('liveStream', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update_offline_thumbnail_jpeg(entry_id, file_data)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'fileData', file_data);
			client.queue_service_action_call('liveStream', 'updateOfflineThumbnailJpeg', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update_offline_thumbnail_from_url(entry_id, url)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'url', url);
			client.queue_service_action_call('liveStream', 'updateOfflineThumbnailFromUrl', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaMediaService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add_from_url(media_entry, url)
			kparams = {}
			client.add_param(kparams, 'mediaEntry', media_entry);
			client.add_param(kparams, 'url', url);
			client.queue_service_action_call('media', 'addFromUrl', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add_from_search_result(media_entry=nil, search_result=nil)
			kparams = {}
			client.add_param(kparams, 'mediaEntry', media_entry);
			client.add_param(kparams, 'searchResult', search_result);
			client.queue_service_action_call('media', 'addFromSearchResult', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add_from_uploaded_file(media_entry, upload_token_id)
			kparams = {}
			client.add_param(kparams, 'mediaEntry', media_entry);
			client.add_param(kparams, 'uploadTokenId', upload_token_id);
			client.queue_service_action_call('media', 'addFromUploadedFile', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add_from_recorded_webcam(media_entry, webcam_token_id)
			kparams = {}
			client.add_param(kparams, 'mediaEntry', media_entry);
			client.add_param(kparams, 'webcamTokenId', webcam_token_id);
			client.queue_service_action_call('media', 'addFromRecordedWebcam', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add_from_entry(source_entry_id, media_entry=nil, source_flavor_params_id='')
			kparams = {}
			client.add_param(kparams, 'sourceEntryId', source_entry_id);
			client.add_param(kparams, 'mediaEntry', media_entry);
			client.add_param(kparams, 'sourceFlavorParamsId', source_flavor_params_id);
			client.queue_service_action_call('media', 'addFromEntry', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add_from_flavor_asset(source_flavor_asset_id, media_entry=nil)
			kparams = {}
			client.add_param(kparams, 'sourceFlavorAssetId', source_flavor_asset_id);
			client.add_param(kparams, 'mediaEntry', media_entry);
			client.queue_service_action_call('media', 'addFromFlavorAsset', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def convert(entry_id, conversion_profile_id='', dynamic_conversion_attributes=nil)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'conversionProfileId', conversion_profile_id);
			dynamicConversionAttributes.each do |obj|
				client.add_param(kparams, 'dynamicConversionAttributes', obj);
			end
			client.queue_service_action_call('media', 'convert', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(entry_id, version=-1)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'version', version);
			client.queue_service_action_call('media', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(entry_id, media_entry)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'mediaEntry', media_entry);
			client.queue_service_action_call('media', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(entry_id)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.queue_service_action_call('media', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('media', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def count(filter=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.queue_service_action_call('media', 'count', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def upload(file_data)
			kparams = {}
			client.add_param(kparams, 'fileData', file_data);
			client.queue_service_action_call('media', 'upload', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def request_conversion(entry_id, file_format)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'fileFormat', file_format);
			client.queue_service_action_call('media', 'requestConversion', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def flag(moderation_flag)
			kparams = {}
			client.add_param(kparams, 'moderationFlag', moderation_flag);
			client.queue_service_action_call('media', 'flag', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def reject(entry_id)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.queue_service_action_call('media', 'reject', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def approve(entry_id)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.queue_service_action_call('media', 'approve', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list_flags(entry_id, pager=nil)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('media', 'listFlags', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def anonymous_rank(entry_id, rank)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'rank', rank);
			client.queue_service_action_call('media', 'anonymousRank', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaMixingService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(mix_entry)
			kparams = {}
			client.add_param(kparams, 'mixEntry', mix_entry);
			client.queue_service_action_call('mixing', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(entry_id, version=-1)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'version', version);
			client.queue_service_action_call('mixing', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(entry_id, mix_entry)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'mixEntry', mix_entry);
			client.queue_service_action_call('mixing', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(entry_id)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.queue_service_action_call('mixing', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('mixing', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def count(filter=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.queue_service_action_call('mixing', 'count', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def clone(entry_id)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.queue_service_action_call('mixing', 'clone', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def append_media_entry(mix_entry_id, media_entry_id)
			kparams = {}
			client.add_param(kparams, 'mixEntryId', mix_entry_id);
			client.add_param(kparams, 'mediaEntryId', media_entry_id);
			client.queue_service_action_call('mixing', 'appendMediaEntry', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def request_flattening(entry_id, file_format, version=-1)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'fileFormat', file_format);
			client.add_param(kparams, 'version', version);
			client.queue_service_action_call('mixing', 'requestFlattening', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_mixes_by_media_id(media_entry_id)
			kparams = {}
			client.add_param(kparams, 'mediaEntryId', media_entry_id);
			client.queue_service_action_call('mixing', 'getMixesByMediaId', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_ready_media_entries(mix_id, version=-1)
			kparams = {}
			client.add_param(kparams, 'mixId', mix_id);
			client.add_param(kparams, 'version', version);
			client.queue_service_action_call('mixing', 'getReadyMediaEntries', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def anonymous_rank(entry_id, rank)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'rank', rank);
			client.queue_service_action_call('mixing', 'anonymousRank', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaNotificationService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def get_client_notification(entry_id, type)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'type', type);
			client.queue_service_action_call('notification', 'getClientNotification', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaPartnerService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def register(partner, cms_password='')
			kparams = {}
			client.add_param(kparams, 'partner', partner);
			client.add_param(kparams, 'cmsPassword', cms_password);
			client.queue_service_action_call('partner', 'register', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(partner, allow_empty=false)
			kparams = {}
			client.add_param(kparams, 'partner', partner);
			client.add_param(kparams, 'allowEmpty', allow_empty);
			client.queue_service_action_call('partner', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_secrets(partner_id, admin_email, cms_password)
			kparams = {}
			client.add_param(kparams, 'partnerId', partner_id);
			client.add_param(kparams, 'adminEmail', admin_email);
			client.add_param(kparams, 'cmsPassword', cms_password);
			client.queue_service_action_call('partner', 'getSecrets', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_info()
			kparams = {}
			client.queue_service_action_call('partner', 'getInfo', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_usage(year='', month=1, resolution='days')
			kparams = {}
			client.add_param(kparams, 'year', year);
			client.add_param(kparams, 'month', month);
			client.add_param(kparams, 'resolution', resolution);
			client.queue_service_action_call('partner', 'getUsage', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaPermissionItemService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(permission_item)
			kparams = {}
			client.add_param(kparams, 'permissionItem', permission_item);
			client.queue_service_action_call('permissionItem', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(permission_item_id)
			kparams = {}
			client.add_param(kparams, 'permissionItemId', permission_item_id);
			client.queue_service_action_call('permissionItem', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(permission_item_id, permission_item)
			kparams = {}
			client.add_param(kparams, 'permissionItemId', permission_item_id);
			client.add_param(kparams, 'permissionItem', permission_item);
			client.queue_service_action_call('permissionItem', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(permission_item_id)
			kparams = {}
			client.add_param(kparams, 'permissionItemId', permission_item_id);
			client.queue_service_action_call('permissionItem', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('permissionItem', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaPermissionService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(permission)
			kparams = {}
			client.add_param(kparams, 'permission', permission);
			client.queue_service_action_call('permission', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(permission_name)
			kparams = {}
			client.add_param(kparams, 'permissionName', permission_name);
			client.queue_service_action_call('permission', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(permission_name, permission)
			kparams = {}
			client.add_param(kparams, 'permissionName', permission_name);
			client.add_param(kparams, 'permission', permission);
			client.queue_service_action_call('permission', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(permission_name)
			kparams = {}
			client.add_param(kparams, 'permissionName', permission_name);
			client.queue_service_action_call('permission', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('permission', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_current_permissions()
			kparams = {}
			client.queue_service_action_call('permission', 'getCurrentPermissions', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaPlaylistService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(playlist, update_stats=false)
			kparams = {}
			client.add_param(kparams, 'playlist', playlist);
			client.add_param(kparams, 'updateStats', update_stats);
			client.queue_service_action_call('playlist', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id, version=-1)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'version', version);
			client.queue_service_action_call('playlist', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(id, playlist, update_stats=false)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'playlist', playlist);
			client.add_param(kparams, 'updateStats', update_stats);
			client.queue_service_action_call('playlist', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('playlist', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def clone(id, new_playlist=nil)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'newPlaylist', new_playlist);
			client.queue_service_action_call('playlist', 'clone', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('playlist', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def execute(id, detailed='')
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'detailed', detailed);
			client.queue_service_action_call('playlist', 'execute', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def execute_from_content(playlist_type, playlist_content, detailed='')
			kparams = {}
			client.add_param(kparams, 'playlistType', playlist_type);
			client.add_param(kparams, 'playlistContent', playlist_content);
			client.add_param(kparams, 'detailed', detailed);
			client.queue_service_action_call('playlist', 'executeFromContent', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def execute_from_filters(filters, total_results, detailed='')
			kparams = {}
			filters.each do |obj|
				client.add_param(kparams, 'filters', obj);
			end
			client.add_param(kparams, 'totalResults', total_results);
			client.add_param(kparams, 'detailed', detailed);
			client.queue_service_action_call('playlist', 'executeFromFilters', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_stats_from_content(playlist_type, playlist_content)
			kparams = {}
			client.add_param(kparams, 'playlistType', playlist_type);
			client.add_param(kparams, 'playlistContent', playlist_content);
			client.queue_service_action_call('playlist', 'getStatsFromContent', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaReportService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def get_graphs(report_type, report_input_filter, dimension='', object_ids='')
			kparams = {}
			client.add_param(kparams, 'reportType', report_type);
			client.add_param(kparams, 'reportInputFilter', report_input_filter);
			client.add_param(kparams, 'dimension', dimension);
			client.add_param(kparams, 'objectIds', object_ids);
			client.queue_service_action_call('report', 'getGraphs', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_total(report_type, report_input_filter, object_ids='')
			kparams = {}
			client.add_param(kparams, 'reportType', report_type);
			client.add_param(kparams, 'reportInputFilter', report_input_filter);
			client.add_param(kparams, 'objectIds', object_ids);
			client.queue_service_action_call('report', 'getTotal', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_table(report_type, report_input_filter, pager, order='', object_ids='')
			kparams = {}
			client.add_param(kparams, 'reportType', report_type);
			client.add_param(kparams, 'reportInputFilter', report_input_filter);
			client.add_param(kparams, 'pager', pager);
			client.add_param(kparams, 'order', order);
			client.add_param(kparams, 'objectIds', object_ids);
			client.queue_service_action_call('report', 'getTable', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_url_for_report_as_csv(report_title, report_text, headers, report_type, report_input_filter, dimension='', pager=nil, order='', object_ids='')
			kparams = {}
			client.add_param(kparams, 'reportTitle', report_title);
			client.add_param(kparams, 'reportText', report_text);
			client.add_param(kparams, 'headers', headers);
			client.add_param(kparams, 'reportType', report_type);
			client.add_param(kparams, 'reportInputFilter', report_input_filter);
			client.add_param(kparams, 'dimension', dimension);
			client.add_param(kparams, 'pager', pager);
			client.add_param(kparams, 'order', order);
			client.add_param(kparams, 'objectIds', object_ids);
			client.queue_service_action_call('report', 'getUrlForReportAsCsv', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaSearchService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def search(search, pager=nil)
			kparams = {}
			client.add_param(kparams, 'search', search);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('search', 'search', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_media_info(search_result)
			kparams = {}
			client.add_param(kparams, 'searchResult', search_result);
			client.queue_service_action_call('search', 'getMediaInfo', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def search_url(media_type, url)
			kparams = {}
			client.add_param(kparams, 'mediaType', media_type);
			client.add_param(kparams, 'url', url);
			client.queue_service_action_call('search', 'searchUrl', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def external_login(search_source, user_name, password)
			kparams = {}
			client.add_param(kparams, 'searchSource', search_source);
			client.add_param(kparams, 'userName', user_name);
			client.add_param(kparams, 'password', password);
			client.queue_service_action_call('search', 'externalLogin', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaSessionService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def start(secret, user_id='', type=0, partner_id='', expiry=86400, privileges='')
			kparams = {}
			client.add_param(kparams, 'secret', secret);
			client.add_param(kparams, 'userId', user_id);
			client.add_param(kparams, 'type', type);
			client.add_param(kparams, 'partnerId', partner_id);
			client.add_param(kparams, 'expiry', expiry);
			client.add_param(kparams, 'privileges', privileges);
			client.queue_service_action_call('session', 'start', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def end()
			kparams = {}
			client.queue_service_action_call('session', 'end', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def impersonate(secret, impersonated_partner_id, user_id='', type=0, partner_id='', expiry=86400, privileges='')
			kparams = {}
			client.add_param(kparams, 'secret', secret);
			client.add_param(kparams, 'impersonatedPartnerId', impersonated_partner_id);
			client.add_param(kparams, 'userId', user_id);
			client.add_param(kparams, 'type', type);
			client.add_param(kparams, 'partnerId', partner_id);
			client.add_param(kparams, 'expiry', expiry);
			client.add_param(kparams, 'privileges', privileges);
			client.queue_service_action_call('session', 'impersonate', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def start_widget_session(widget_id, expiry=86400)
			kparams = {}
			client.add_param(kparams, 'widgetId', widget_id);
			client.add_param(kparams, 'expiry', expiry);
			client.queue_service_action_call('session', 'startWidgetSession', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaStatsService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def collect(event)
			kparams = {}
			client.add_param(kparams, 'event', event);
			client.queue_service_action_call('stats', 'collect', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def kmc_collect(kmc_event)
			kparams = {}
			client.add_param(kparams, 'kmcEvent', kmc_event);
			client.queue_service_action_call('stats', 'kmcCollect', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def report_kce_error(kaltura_ce_error)
			kparams = {}
			client.add_param(kparams, 'kalturaCEError', kaltura_ce_error);
			client.queue_service_action_call('stats', 'reportKceError', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaSyndicationFeedService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(syndication_feed)
			kparams = {}
			client.add_param(kparams, 'syndicationFeed', syndication_feed);
			client.queue_service_action_call('syndicationFeed', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('syndicationFeed', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(id, syndication_feed)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'syndicationFeed', syndication_feed);
			client.queue_service_action_call('syndicationFeed', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('syndicationFeed', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('syndicationFeed', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_entry_count(feed_id)
			kparams = {}
			client.add_param(kparams, 'feedId', feed_id);
			client.queue_service_action_call('syndicationFeed', 'getEntryCount', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def request_conversion(feed_id)
			kparams = {}
			client.add_param(kparams, 'feedId', feed_id);
			client.queue_service_action_call('syndicationFeed', 'requestConversion', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaSystemService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def ping()
			kparams = {}
			client.queue_service_action_call('system', 'ping', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaThumbAssetService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def set_as_default(thumb_asset_id)
			kparams = {}
			client.add_param(kparams, 'thumbAssetId', thumb_asset_id);
			client.queue_service_action_call('thumbAsset', 'setAsDefault', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def generate_by_entry_id(entry_id, dest_thumb_params_id)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'destThumbParamsId', dest_thumb_params_id);
			client.queue_service_action_call('thumbAsset', 'generateByEntryId', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def generate(entry_id, thumb_params, source_asset_id='')
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'thumbParams', thumb_params);
			client.add_param(kparams, 'sourceAssetId', source_asset_id);
			client.queue_service_action_call('thumbAsset', 'generate', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def regenerate(thumb_asset_id)
			kparams = {}
			client.add_param(kparams, 'thumbAssetId', thumb_asset_id);
			client.queue_service_action_call('thumbAsset', 'regenerate', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(thumb_asset_id)
			kparams = {}
			client.add_param(kparams, 'thumbAssetId', thumb_asset_id);
			client.queue_service_action_call('thumbAsset', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_by_entry_id(entry_id)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.queue_service_action_call('thumbAsset', 'getByEntryId', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('thumbAsset', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add_from_url(entry_id, url)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'url', url);
			client.queue_service_action_call('thumbAsset', 'addFromUrl', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add_from_image(entry_id, file_data)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'fileData', file_data);
			client.queue_service_action_call('thumbAsset', 'addFromImage', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(thumb_asset_id)
			kparams = {}
			client.add_param(kparams, 'thumbAssetId', thumb_asset_id);
			client.queue_service_action_call('thumbAsset', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaThumbParamsService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(thumb_params)
			kparams = {}
			client.add_param(kparams, 'thumbParams', thumb_params);
			client.queue_service_action_call('thumbParams', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('thumbParams', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(id, thumb_params)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'thumbParams', thumb_params);
			client.queue_service_action_call('thumbParams', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('thumbParams', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('thumbParams', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_by_conversion_profile_id(conversion_profile_id)
			kparams = {}
			client.add_param(kparams, 'conversionProfileId', conversion_profile_id);
			client.queue_service_action_call('thumbParams', 'getByConversionProfileId', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaUiConfService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(ui_conf)
			kparams = {}
			client.add_param(kparams, 'uiConf', ui_conf);
			client.queue_service_action_call('uiConf', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(id, ui_conf)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'uiConf', ui_conf);
			client.queue_service_action_call('uiConf', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('uiConf', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('uiConf', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def clone(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('uiConf', 'clone', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list_templates(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('uiConf', 'listTemplates', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('uiConf', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_available_types()
			kparams = {}
			client.queue_service_action_call('uiConf', 'getAvailableTypes', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaUploadService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def upload(file_data)
			kparams = {}
			client.add_param(kparams, 'fileData', file_data);
			client.queue_service_action_call('upload', 'upload', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_uploaded_file_token_by_file_name(file_name)
			kparams = {}
			client.add_param(kparams, 'fileName', file_name);
			client.queue_service_action_call('upload', 'getUploadedFileTokenByFileName', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaUploadTokenService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(upload_token=nil)
			kparams = {}
			client.add_param(kparams, 'uploadToken', upload_token);
			client.queue_service_action_call('uploadToken', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(upload_token_id)
			kparams = {}
			client.add_param(kparams, 'uploadTokenId', upload_token_id);
			client.queue_service_action_call('uploadToken', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def upload(upload_token_id, file_data, resume=false, final_chunk=true, resume_at=-1)
			kparams = {}
			client.add_param(kparams, 'uploadTokenId', upload_token_id);
			client.add_param(kparams, 'fileData', file_data);
			client.add_param(kparams, 'resume', resume);
			client.add_param(kparams, 'finalChunk', final_chunk);
			client.add_param(kparams, 'resumeAt', resume_at);
			client.queue_service_action_call('uploadToken', 'upload', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(upload_token_id)
			kparams = {}
			client.add_param(kparams, 'uploadTokenId', upload_token_id);
			client.queue_service_action_call('uploadToken', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('uploadToken', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaUserRoleService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(user_role)
			kparams = {}
			client.add_param(kparams, 'userRole', user_role);
			client.queue_service_action_call('userRole', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(user_role_id)
			kparams = {}
			client.add_param(kparams, 'userRoleId', user_role_id);
			client.queue_service_action_call('userRole', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(user_role_id, user_role)
			kparams = {}
			client.add_param(kparams, 'userRoleId', user_role_id);
			client.add_param(kparams, 'userRole', user_role);
			client.queue_service_action_call('userRole', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(user_role_id)
			kparams = {}
			client.add_param(kparams, 'userRoleId', user_role_id);
			client.queue_service_action_call('userRole', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('userRole', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def clone(user_role_id)
			kparams = {}
			client.add_param(kparams, 'userRoleId', user_role_id);
			client.queue_service_action_call('userRole', 'clone', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaUserService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(user)
			kparams = {}
			client.add_param(kparams, 'user', user);
			client.queue_service_action_call('user', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(user_id, user)
			kparams = {}
			client.add_param(kparams, 'userId', user_id);
			client.add_param(kparams, 'user', user);
			client.queue_service_action_call('user', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(user_id)
			kparams = {}
			client.add_param(kparams, 'userId', user_id);
			client.queue_service_action_call('user', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_by_login_id(login_id)
			kparams = {}
			client.add_param(kparams, 'loginId', login_id);
			client.queue_service_action_call('user', 'getByLoginId', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(user_id)
			kparams = {}
			client.add_param(kparams, 'userId', user_id);
			client.queue_service_action_call('user', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('user', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def notify_ban(user_id)
			kparams = {}
			client.add_param(kparams, 'userId', user_id);
			client.queue_service_action_call('user', 'notifyBan', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def login(partner_id, user_id, password, expiry=86400, privileges='*')
			kparams = {}
			client.add_param(kparams, 'partnerId', partner_id);
			client.add_param(kparams, 'userId', user_id);
			client.add_param(kparams, 'password', password);
			client.add_param(kparams, 'expiry', expiry);
			client.add_param(kparams, 'privileges', privileges);
			client.queue_service_action_call('user', 'login', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def login_by_login_id(login_id, password, partner_id='', expiry=86400, privileges='*')
			kparams = {}
			client.add_param(kparams, 'loginId', login_id);
			client.add_param(kparams, 'password', password);
			client.add_param(kparams, 'partnerId', partner_id);
			client.add_param(kparams, 'expiry', expiry);
			client.add_param(kparams, 'privileges', privileges);
			client.queue_service_action_call('user', 'loginByLoginId', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update_login_data(old_login_id, password, new_login_id='', new_password='', new_first_name='', new_last_name='')
			kparams = {}
			client.add_param(kparams, 'oldLoginId', old_login_id);
			client.add_param(kparams, 'password', password);
			client.add_param(kparams, 'newLoginId', new_login_id);
			client.add_param(kparams, 'newPassword', new_password);
			client.add_param(kparams, 'newFirstName', new_first_name);
			client.add_param(kparams, 'newLastName', new_last_name);
			client.queue_service_action_call('user', 'updateLoginData', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def reset_password(email)
			kparams = {}
			client.add_param(kparams, 'email', email);
			client.queue_service_action_call('user', 'resetPassword', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def set_initial_password(hash_key, new_password)
			kparams = {}
			client.add_param(kparams, 'hashKey', hash_key);
			client.add_param(kparams, 'newPassword', new_password);
			client.queue_service_action_call('user', 'setInitialPassword', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def enable_login(user_id, login_id, password='')
			kparams = {}
			client.add_param(kparams, 'userId', user_id);
			client.add_param(kparams, 'loginId', login_id);
			client.add_param(kparams, 'password', password);
			client.queue_service_action_call('user', 'enableLogin', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def disable_login(user_id='', login_id='')
			kparams = {}
			client.add_param(kparams, 'userId', user_id);
			client.add_param(kparams, 'loginId', login_id);
			client.queue_service_action_call('user', 'disableLogin', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaWidgetService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(widget)
			kparams = {}
			client.add_param(kparams, 'widget', widget);
			client.queue_service_action_call('widget', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(id, widget)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'widget', widget);
			client.queue_service_action_call('widget', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('widget', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def clone(widget)
			kparams = {}
			client.add_param(kparams, 'widget', widget);
			client.queue_service_action_call('widget', 'clone', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('widget', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaXInternalService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def x_add_bulk_download(entry_ids, flavor_params_id='')
			kparams = {}
			client.add_param(kparams, 'entryIds', entry_ids);
			client.add_param(kparams, 'flavorParamsId', flavor_params_id);
			client.queue_service_action_call('xInternal', 'xAddBulkDownload', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaMetadataService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('metadata', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add(metadata_profile_id, object_type, object_id, xml_data)
			kparams = {}
			client.add_param(kparams, 'metadataProfileId', metadata_profile_id);
			client.add_param(kparams, 'objectType', object_type);
			client.add_param(kparams, 'objectId', object_id);
			client.add_param(kparams, 'xmlData', xml_data);
			client.queue_service_action_call('metadata', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add_from_file(metadata_profile_id, object_type, object_id, xml_file)
			kparams = {}
			client.add_param(kparams, 'metadataProfileId', metadata_profile_id);
			client.add_param(kparams, 'objectType', object_type);
			client.add_param(kparams, 'objectId', object_id);
			client.add_param(kparams, 'xmlFile', xml_file);
			client.queue_service_action_call('metadata', 'addFromFile', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add_from_url(metadata_profile_id, object_type, object_id, url)
			kparams = {}
			client.add_param(kparams, 'metadataProfileId', metadata_profile_id);
			client.add_param(kparams, 'objectType', object_type);
			client.add_param(kparams, 'objectId', object_id);
			client.add_param(kparams, 'url', url);
			client.queue_service_action_call('metadata', 'addFromUrl', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add_from_bulk(metadata_profile_id, object_type, object_id, url)
			kparams = {}
			client.add_param(kparams, 'metadataProfileId', metadata_profile_id);
			client.add_param(kparams, 'objectType', object_type);
			client.add_param(kparams, 'objectId', object_id);
			client.add_param(kparams, 'url', url);
			client.queue_service_action_call('metadata', 'addFromBulk', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('metadata', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def invalidate(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('metadata', 'invalidate', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('metadata', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(id, xml_data='')
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'xmlData', xml_data);
			client.queue_service_action_call('metadata', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update_from_file(id, xml_file=nil)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'xmlFile', xml_file);
			client.queue_service_action_call('metadata', 'updateFromFile', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaMetadataProfileService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('metadataProfile', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list_fields(metadata_profile_id)
			kparams = {}
			client.add_param(kparams, 'metadataProfileId', metadata_profile_id);
			client.queue_service_action_call('metadataProfile', 'listFields', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add(metadata_profile, xsd_data, views_data='')
			kparams = {}
			client.add_param(kparams, 'metadataProfile', metadata_profile);
			client.add_param(kparams, 'xsdData', xsd_data);
			client.add_param(kparams, 'viewsData', views_data);
			client.queue_service_action_call('metadataProfile', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add_from_file(metadata_profile, xsd_file, views_file=nil)
			kparams = {}
			client.add_param(kparams, 'metadataProfile', metadata_profile);
			client.add_param(kparams, 'xsdFile', xsd_file);
			client.add_param(kparams, 'viewsFile', views_file);
			client.queue_service_action_call('metadataProfile', 'addFromFile', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('metadataProfile', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('metadataProfile', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(id, metadata_profile, xsd_data='', views_data='')
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'metadataProfile', metadata_profile);
			client.add_param(kparams, 'xsdData', xsd_data);
			client.add_param(kparams, 'viewsData', views_data);
			client.queue_service_action_call('metadataProfile', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def revert(id, to_version)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'toVersion', to_version);
			client.queue_service_action_call('metadataProfile', 'revert', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update_definition_from_file(id, xsd_file)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'xsdFile', xsd_file);
			client.queue_service_action_call('metadataProfile', 'updateDefinitionFromFile', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update_views_from_file(id, views_file)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'viewsFile', views_file);
			client.queue_service_action_call('metadataProfile', 'updateViewsFromFile', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaDocumentsService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add_from_uploaded_file(document_entry, upload_token_id)
			kparams = {}
			client.add_param(kparams, 'documentEntry', document_entry);
			client.add_param(kparams, 'uploadTokenId', upload_token_id);
			client.queue_service_action_call('documents', 'addFromUploadedFile', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add_from_entry(source_entry_id, document_entry=nil, source_flavor_params_id='')
			kparams = {}
			client.add_param(kparams, 'sourceEntryId', source_entry_id);
			client.add_param(kparams, 'documentEntry', document_entry);
			client.add_param(kparams, 'sourceFlavorParamsId', source_flavor_params_id);
			client.queue_service_action_call('documents', 'addFromEntry', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add_from_flavor_asset(source_flavor_asset_id, document_entry=nil)
			kparams = {}
			client.add_param(kparams, 'sourceFlavorAssetId', source_flavor_asset_id);
			client.add_param(kparams, 'documentEntry', document_entry);
			client.queue_service_action_call('documents', 'addFromFlavorAsset', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def convert(entry_id, conversion_profile_id='', dynamic_conversion_attributes=nil)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'conversionProfileId', conversion_profile_id);
			dynamicConversionAttributes.each do |obj|
				client.add_param(kparams, 'dynamicConversionAttributes', obj);
			end
			client.queue_service_action_call('documents', 'convert', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(entry_id, version=-1)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'version', version);
			client.queue_service_action_call('documents', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(entry_id, document_entry)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'documentEntry', document_entry);
			client.queue_service_action_call('documents', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(entry_id)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.queue_service_action_call('documents', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('documents', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def upload(file_data)
			kparams = {}
			client.add_param(kparams, 'fileData', file_data);
			client.queue_service_action_call('documents', 'upload', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def convert_ppt_to_swf(entry_id)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.queue_service_action_call('documents', 'convertPptToSwf', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaStorageProfileService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def list_by_partner(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('storageProfile', 'listByPartner', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update_status(storage_id, status)
			kparams = {}
			client.add_param(kparams, 'storageId', storage_id);
			client.add_param(kparams, 'status', status);
			client.queue_service_action_call('storageProfile', 'updateStatus', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(storage_profile_id)
			kparams = {}
			client.add_param(kparams, 'storageProfileId', storage_profile_id);
			client.queue_service_action_call('storageProfile', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(storage_profile_id, storage_profile)
			kparams = {}
			client.add_param(kparams, 'storageProfileId', storage_profile_id);
			client.add_param(kparams, 'storageProfile', storage_profile);
			client.queue_service_action_call('storageProfile', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add(storage_profile)
			kparams = {}
			client.add_param(kparams, 'storageProfile', storage_profile);
			client.queue_service_action_call('storageProfile', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaSystemPartnerService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def get(partner_id)
			kparams = {}
			client.add_param(kparams, 'partnerId', partner_id);
			client.queue_service_action_call('systemPartner', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_usage(partner_filter=nil, usage_filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'partnerFilter', partner_filter);
			client.add_param(kparams, 'usageFilter', usage_filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('systemPartner', 'getUsage', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('systemPartner', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update_status(partner_id, status)
			kparams = {}
			client.add_param(kparams, 'partnerId', partner_id);
			client.add_param(kparams, 'status', status);
			client.queue_service_action_call('systemPartner', 'updateStatus', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_admin_session(partner_id, user_id='')
			kparams = {}
			client.add_param(kparams, 'partnerId', partner_id);
			client.add_param(kparams, 'userId', user_id);
			client.queue_service_action_call('systemPartner', 'getAdminSession', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update_configuration(partner_id, configuration)
			kparams = {}
			client.add_param(kparams, 'partnerId', partner_id);
			client.add_param(kparams, 'configuration', configuration);
			client.queue_service_action_call('systemPartner', 'updateConfiguration', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_configuration(partner_id)
			kparams = {}
			client.add_param(kparams, 'partnerId', partner_id);
			client.queue_service_action_call('systemPartner', 'getConfiguration', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_packages()
			kparams = {}
			client.queue_service_action_call('systemPartner', 'getPackages', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaFlavorParamsOutputService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('flavorParamsOutput', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaThumbParamsOutputService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('thumbParamsOutput', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaMediaInfoService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('mediaInfo', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaEntryAdminService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def get(entry_id, version=-1)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.add_param(kparams, 'version', version);
			client.queue_service_action_call('entryAdmin', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_by_flavor_id(flavor_id, version=-1)
			kparams = {}
			client.add_param(kparams, 'flavorId', flavor_id);
			client.add_param(kparams, 'version', version);
			client.queue_service_action_call('entryAdmin', 'getByFlavorId', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_tracks(entry_id)
			kparams = {}
			client.add_param(kparams, 'entryId', entry_id);
			client.queue_service_action_call('entryAdmin', 'getTracks', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaUiConfAdminService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(ui_conf)
			kparams = {}
			client.add_param(kparams, 'uiConf', ui_conf);
			client.queue_service_action_call('uiConfAdmin', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(id, ui_conf)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'uiConf', ui_conf);
			client.queue_service_action_call('uiConfAdmin', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('uiConfAdmin', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('uiConfAdmin', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaKalturaInternalToolsService < KalturaServiceBase
		def initialize(client)
			super(client)
		end
	end

	class KalturaKalturaInternalToolsSystemHelperService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def from_secure_string(str)
			kparams = {}
			client.add_param(kparams, 'str', str);
			client.queue_service_action_call('kalturaInternalToolsSystemHelper', 'fromSecureString', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def iptocountry(remote_addr)
			kparams = {}
			client.add_param(kparams, 'remote_addr', remote_addr);
			client.queue_service_action_call('kalturaInternalToolsSystemHelper', 'iptocountry', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_remote_address()
			kparams = {}
			client.queue_service_action_call('kalturaInternalToolsSystemHelper', 'getRemoteAddress', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaAuditTrailService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('auditTrail', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add(audit_trail)
			kparams = {}
			client.add_param(kparams, 'auditTrail', audit_trail);
			client.queue_service_action_call('auditTrail', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('auditTrail', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaVirusScanProfileService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('virusScanProfile', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add(virus_scan_profile)
			kparams = {}
			client.add_param(kparams, 'virusScanProfile', virus_scan_profile);
			client.queue_service_action_call('virusScanProfile', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(virus_scan_profile_id)
			kparams = {}
			client.add_param(kparams, 'virusScanProfileId', virus_scan_profile_id);
			client.queue_service_action_call('virusScanProfile', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(virus_scan_profile_id, virus_scan_profile)
			kparams = {}
			client.add_param(kparams, 'virusScanProfileId', virus_scan_profile_id);
			client.add_param(kparams, 'virusScanProfile', virus_scan_profile);
			client.queue_service_action_call('virusScanProfile', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(virus_scan_profile_id)
			kparams = {}
			client.add_param(kparams, 'virusScanProfileId', virus_scan_profile_id);
			client.queue_service_action_call('virusScanProfile', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def scan(flavor_asset_id, virus_scan_profile_id='')
			kparams = {}
			client.add_param(kparams, 'flavorAssetId', flavor_asset_id);
			client.add_param(kparams, 'virusScanProfileId', virus_scan_profile_id);
			client.queue_service_action_call('virusScanProfile', 'scan', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaDistributionProfileService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(distribution_profile)
			kparams = {}
			client.add_param(kparams, 'distributionProfile', distribution_profile);
			client.queue_service_action_call('distributionProfile', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('distributionProfile', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(id, distribution_profile)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'distributionProfile', distribution_profile);
			client.queue_service_action_call('distributionProfile', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update_status(id, status)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'status', status);
			client.queue_service_action_call('distributionProfile', 'updateStatus', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('distributionProfile', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('distributionProfile', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list_by_partner(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('distributionProfile', 'listByPartner', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaEntryDistributionService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(entry_distribution)
			kparams = {}
			client.add_param(kparams, 'entryDistribution', entry_distribution);
			client.queue_service_action_call('entryDistribution', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('entryDistribution', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def validate(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('entryDistribution', 'validate', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(id, entry_distribution)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'entryDistribution', entry_distribution);
			client.queue_service_action_call('entryDistribution', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('entryDistribution', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('entryDistribution', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def submit_add(id, submit_when_ready=false)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'submitWhenReady', submit_when_ready);
			client.queue_service_action_call('entryDistribution', 'submitAdd', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def submit_update(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('entryDistribution', 'submitUpdate', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def submit_fetch_report(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('entryDistribution', 'submitFetchReport', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def submit_delete(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('entryDistribution', 'submitDelete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def retry_submit(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('entryDistribution', 'retrySubmit', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaDistributionProviderService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('distributionProvider', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaGenericDistributionProviderService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(generic_distribution_provider)
			kparams = {}
			client.add_param(kparams, 'genericDistributionProvider', generic_distribution_provider);
			client.queue_service_action_call('genericDistributionProvider', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('genericDistributionProvider', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(id, generic_distribution_provider)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'genericDistributionProvider', generic_distribution_provider);
			client.queue_service_action_call('genericDistributionProvider', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('genericDistributionProvider', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('genericDistributionProvider', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaGenericDistributionProviderActionService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def add(generic_distribution_provider_action)
			kparams = {}
			client.add_param(kparams, 'genericDistributionProviderAction', generic_distribution_provider_action);
			client.queue_service_action_call('genericDistributionProviderAction', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add_mrss_transform(id, xsl_data)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'xslData', xsl_data);
			client.queue_service_action_call('genericDistributionProviderAction', 'addMrssTransform', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add_mrss_transform_from_file(id, xsl_file)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'xslFile', xsl_file);
			client.queue_service_action_call('genericDistributionProviderAction', 'addMrssTransformFromFile', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add_mrss_validate(id, xsd_data)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'xsdData', xsd_data);
			client.queue_service_action_call('genericDistributionProviderAction', 'addMrssValidate', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add_mrss_validate_from_file(id, xsd_file)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'xsdFile', xsd_file);
			client.queue_service_action_call('genericDistributionProviderAction', 'addMrssValidateFromFile', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add_results_transform(id, transform_data)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'transformData', transform_data);
			client.queue_service_action_call('genericDistributionProviderAction', 'addResultsTransform', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add_results_transform_from_file(id, transform_file)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'transformFile', transform_file);
			client.queue_service_action_call('genericDistributionProviderAction', 'addResultsTransformFromFile', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('genericDistributionProviderAction', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get_by_provider_id(generic_distribution_provider_id, action_type)
			kparams = {}
			client.add_param(kparams, 'genericDistributionProviderId', generic_distribution_provider_id);
			client.add_param(kparams, 'actionType', action_type);
			client.queue_service_action_call('genericDistributionProviderAction', 'getByProviderId', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update_by_provider_id(generic_distribution_provider_id, action_type, generic_distribution_provider_action)
			kparams = {}
			client.add_param(kparams, 'genericDistributionProviderId', generic_distribution_provider_id);
			client.add_param(kparams, 'actionType', action_type);
			client.add_param(kparams, 'genericDistributionProviderAction', generic_distribution_provider_action);
			client.queue_service_action_call('genericDistributionProviderAction', 'updateByProviderId', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(id, generic_distribution_provider_action)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'genericDistributionProviderAction', generic_distribution_provider_action);
			client.queue_service_action_call('genericDistributionProviderAction', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('genericDistributionProviderAction', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete_by_provider_id(generic_distribution_provider_id, action_type)
			kparams = {}
			client.add_param(kparams, 'genericDistributionProviderId', generic_distribution_provider_id);
			client.add_param(kparams, 'actionType', action_type);
			client.queue_service_action_call('genericDistributionProviderAction', 'deleteByProviderId', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('genericDistributionProviderAction', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaAnnotationService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('annotation', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add(annotation)
			kparams = {}
			client.add_param(kparams, 'annotation', annotation);
			client.queue_service_action_call('annotation', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('annotation', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('annotation', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(id, annotation)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'annotation', annotation);
			client.queue_service_action_call('annotation', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

	class KalturaShortLinkService < KalturaServiceBase
		def initialize(client)
			super(client)
		end

		def list(filter=nil, pager=nil)
			kparams = {}
			client.add_param(kparams, 'filter', filter);
			client.add_param(kparams, 'pager', pager);
			client.queue_service_action_call('shortLink', 'list', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def add(short_link)
			kparams = {}
			client.add_param(kparams, 'shortLink', short_link);
			client.queue_service_action_call('shortLink', 'add', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def get(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('shortLink', 'get', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def update(id, short_link)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.add_param(kparams, 'shortLink', short_link);
			client.queue_service_action_call('shortLink', 'update', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end

		def delete(id)
			kparams = {}
			client.add_param(kparams, 'id', id);
			client.queue_service_action_call('shortLink', 'delete', kparams);
			if (client.is_multirequest)
				return nil;
			end
			return client.do_queue();
		end
	end

    class KalturaClient < KalturaClientBase
		attr_reader :access_control_service
		def access_control_service
			if (@access_control_service == nil)
				@access_control_service = KalturaAccessControlService.new(self)
			end
			return @access_control_service
		end
		attr_reader :admin_user_service
		def admin_user_service
			if (@admin_user_service == nil)
				@admin_user_service = KalturaAdminUserService.new(self)
			end
			return @admin_user_service
		end
		attr_reader :base_entry_service
		def base_entry_service
			if (@base_entry_service == nil)
				@base_entry_service = KalturaBaseEntryService.new(self)
			end
			return @base_entry_service
		end
		attr_reader :bulk_upload_service
		def bulk_upload_service
			if (@bulk_upload_service == nil)
				@bulk_upload_service = KalturaBulkUploadService.new(self)
			end
			return @bulk_upload_service
		end
		attr_reader :category_service
		def category_service
			if (@category_service == nil)
				@category_service = KalturaCategoryService.new(self)
			end
			return @category_service
		end
		attr_reader :conversion_profile_service
		def conversion_profile_service
			if (@conversion_profile_service == nil)
				@conversion_profile_service = KalturaConversionProfileService.new(self)
			end
			return @conversion_profile_service
		end
		attr_reader :data_service
		def data_service
			if (@data_service == nil)
				@data_service = KalturaDataService.new(self)
			end
			return @data_service
		end
		attr_reader :email_ingestion_profile_service
		def email_ingestion_profile_service
			if (@email_ingestion_profile_service == nil)
				@email_ingestion_profile_service = KalturaEmailIngestionProfileService.new(self)
			end
			return @email_ingestion_profile_service
		end
		attr_reader :flavor_asset_service
		def flavor_asset_service
			if (@flavor_asset_service == nil)
				@flavor_asset_service = KalturaFlavorAssetService.new(self)
			end
			return @flavor_asset_service
		end
		attr_reader :flavor_params_service
		def flavor_params_service
			if (@flavor_params_service == nil)
				@flavor_params_service = KalturaFlavorParamsService.new(self)
			end
			return @flavor_params_service
		end
		attr_reader :live_stream_service
		def live_stream_service
			if (@live_stream_service == nil)
				@live_stream_service = KalturaLiveStreamService.new(self)
			end
			return @live_stream_service
		end
		attr_reader :media_service
		def media_service
			if (@media_service == nil)
				@media_service = KalturaMediaService.new(self)
			end
			return @media_service
		end
		attr_reader :mixing_service
		def mixing_service
			if (@mixing_service == nil)
				@mixing_service = KalturaMixingService.new(self)
			end
			return @mixing_service
		end
		attr_reader :notification_service
		def notification_service
			if (@notification_service == nil)
				@notification_service = KalturaNotificationService.new(self)
			end
			return @notification_service
		end
		attr_reader :partner_service
		def partner_service
			if (@partner_service == nil)
				@partner_service = KalturaPartnerService.new(self)
			end
			return @partner_service
		end
		attr_reader :permission_item_service
		def permission_item_service
			if (@permission_item_service == nil)
				@permission_item_service = KalturaPermissionItemService.new(self)
			end
			return @permission_item_service
		end
		attr_reader :permission_service
		def permission_service
			if (@permission_service == nil)
				@permission_service = KalturaPermissionService.new(self)
			end
			return @permission_service
		end
		attr_reader :playlist_service
		def playlist_service
			if (@playlist_service == nil)
				@playlist_service = KalturaPlaylistService.new(self)
			end
			return @playlist_service
		end
		attr_reader :report_service
		def report_service
			if (@report_service == nil)
				@report_service = KalturaReportService.new(self)
			end
			return @report_service
		end
		attr_reader :search_service
		def search_service
			if (@search_service == nil)
				@search_service = KalturaSearchService.new(self)
			end
			return @search_service
		end
		attr_reader :session_service
		def session_service
			if (@session_service == nil)
				@session_service = KalturaSessionService.new(self)
			end
			return @session_service
		end
		attr_reader :stats_service
		def stats_service
			if (@stats_service == nil)
				@stats_service = KalturaStatsService.new(self)
			end
			return @stats_service
		end
		attr_reader :syndication_feed_service
		def syndication_feed_service
			if (@syndication_feed_service == nil)
				@syndication_feed_service = KalturaSyndicationFeedService.new(self)
			end
			return @syndication_feed_service
		end
		attr_reader :system_service
		def system_service
			if (@system_service == nil)
				@system_service = KalturaSystemService.new(self)
			end
			return @system_service
		end
		attr_reader :thumb_asset_service
		def thumb_asset_service
			if (@thumb_asset_service == nil)
				@thumb_asset_service = KalturaThumbAssetService.new(self)
			end
			return @thumb_asset_service
		end
		attr_reader :thumb_params_service
		def thumb_params_service
			if (@thumb_params_service == nil)
				@thumb_params_service = KalturaThumbParamsService.new(self)
			end
			return @thumb_params_service
		end
		attr_reader :ui_conf_service
		def ui_conf_service
			if (@ui_conf_service == nil)
				@ui_conf_service = KalturaUiConfService.new(self)
			end
			return @ui_conf_service
		end
		attr_reader :upload_service
		def upload_service
			if (@upload_service == nil)
				@upload_service = KalturaUploadService.new(self)
			end
			return @upload_service
		end
		attr_reader :upload_token_service
		def upload_token_service
			if (@upload_token_service == nil)
				@upload_token_service = KalturaUploadTokenService.new(self)
			end
			return @upload_token_service
		end
		attr_reader :user_role_service
		def user_role_service
			if (@user_role_service == nil)
				@user_role_service = KalturaUserRoleService.new(self)
			end
			return @user_role_service
		end
		attr_reader :user_service
		def user_service
			if (@user_service == nil)
				@user_service = KalturaUserService.new(self)
			end
			return @user_service
		end
		attr_reader :widget_service
		def widget_service
			if (@widget_service == nil)
				@widget_service = KalturaWidgetService.new(self)
			end
			return @widget_service
		end
		attr_reader :x_internal_service
		def x_internal_service
			if (@x_internal_service == nil)
				@x_internal_service = KalturaXInternalService.new(self)
			end
			return @x_internal_service
		end
		attr_reader :metadata_service
		def metadata_service
			if (@metadata_service == nil)
				@metadata_service = KalturaMetadataService.new(self)
			end
			return @metadata_service
		end
		attr_reader :metadata_profile_service
		def metadata_profile_service
			if (@metadata_profile_service == nil)
				@metadata_profile_service = KalturaMetadataProfileService.new(self)
			end
			return @metadata_profile_service
		end
		attr_reader :documents_service
		def documents_service
			if (@documents_service == nil)
				@documents_service = KalturaDocumentsService.new(self)
			end
			return @documents_service
		end
		attr_reader :storage_profile_service
		def storage_profile_service
			if (@storage_profile_service == nil)
				@storage_profile_service = KalturaStorageProfileService.new(self)
			end
			return @storage_profile_service
		end
		attr_reader :system_partner_service
		def system_partner_service
			if (@system_partner_service == nil)
				@system_partner_service = KalturaSystemPartnerService.new(self)
			end
			return @system_partner_service
		end
		attr_reader :flavor_params_output_service
		def flavor_params_output_service
			if (@flavor_params_output_service == nil)
				@flavor_params_output_service = KalturaFlavorParamsOutputService.new(self)
			end
			return @flavor_params_output_service
		end
		attr_reader :thumb_params_output_service
		def thumb_params_output_service
			if (@thumb_params_output_service == nil)
				@thumb_params_output_service = KalturaThumbParamsOutputService.new(self)
			end
			return @thumb_params_output_service
		end
		attr_reader :media_info_service
		def media_info_service
			if (@media_info_service == nil)
				@media_info_service = KalturaMediaInfoService.new(self)
			end
			return @media_info_service
		end
		attr_reader :entry_admin_service
		def entry_admin_service
			if (@entry_admin_service == nil)
				@entry_admin_service = KalturaEntryAdminService.new(self)
			end
			return @entry_admin_service
		end
		attr_reader :ui_conf_admin_service
		def ui_conf_admin_service
			if (@ui_conf_admin_service == nil)
				@ui_conf_admin_service = KalturaUiConfAdminService.new(self)
			end
			return @ui_conf_admin_service
		end
		attr_reader :kaltura_internal_tools_service
		def kaltura_internal_tools_service
			if (@kaltura_internal_tools_service == nil)
				@kaltura_internal_tools_service = KalturaKalturaInternalToolsService.new(self)
			end
			return @kaltura_internal_tools_service
		end
		attr_reader :kaltura_internal_tools_system_helper_service
		def kaltura_internal_tools_system_helper_service
			if (@kaltura_internal_tools_system_helper_service == nil)
				@kaltura_internal_tools_system_helper_service = KalturaKalturaInternalToolsSystemHelperService.new(self)
			end
			return @kaltura_internal_tools_system_helper_service
		end
		attr_reader :audit_trail_service
		def audit_trail_service
			if (@audit_trail_service == nil)
				@audit_trail_service = KalturaAuditTrailService.new(self)
			end
			return @audit_trail_service
		end
		attr_reader :virus_scan_profile_service
		def virus_scan_profile_service
			if (@virus_scan_profile_service == nil)
				@virus_scan_profile_service = KalturaVirusScanProfileService.new(self)
			end
			return @virus_scan_profile_service
		end
		attr_reader :distribution_profile_service
		def distribution_profile_service
			if (@distribution_profile_service == nil)
				@distribution_profile_service = KalturaDistributionProfileService.new(self)
			end
			return @distribution_profile_service
		end
		attr_reader :entry_distribution_service
		def entry_distribution_service
			if (@entry_distribution_service == nil)
				@entry_distribution_service = KalturaEntryDistributionService.new(self)
			end
			return @entry_distribution_service
		end
		attr_reader :distribution_provider_service
		def distribution_provider_service
			if (@distribution_provider_service == nil)
				@distribution_provider_service = KalturaDistributionProviderService.new(self)
			end
			return @distribution_provider_service
		end
		attr_reader :generic_distribution_provider_service
		def generic_distribution_provider_service
			if (@generic_distribution_provider_service == nil)
				@generic_distribution_provider_service = KalturaGenericDistributionProviderService.new(self)
			end
			return @generic_distribution_provider_service
		end
		attr_reader :generic_distribution_provider_action_service
		def generic_distribution_provider_action_service
			if (@generic_distribution_provider_action_service == nil)
				@generic_distribution_provider_action_service = KalturaGenericDistributionProviderActionService.new(self)
			end
			return @generic_distribution_provider_action_service
		end
		attr_reader :annotation_service
		def annotation_service
			if (@annotation_service == nil)
				@annotation_service = KalturaAnnotationService.new(self)
			end
			return @annotation_service
		end
		attr_reader :short_link_service
		def short_link_service
			if (@short_link_service == nil)
				@short_link_service = KalturaShortLinkService.new(self)
			end
			return @short_link_service
		end
    end

end
