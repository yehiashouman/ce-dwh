<?php
class Kaltura_Client_Type_MediaFlavorParamsOutput extends Kaltura_Client_Type_FlavorParamsOutput
{
	public function getKalturaObjectType()
	{
		return 'KalturaMediaFlavorParamsOutput';
	}
	

}

