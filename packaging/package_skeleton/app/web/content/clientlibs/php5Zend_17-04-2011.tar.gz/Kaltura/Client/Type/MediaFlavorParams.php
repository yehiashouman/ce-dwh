<?php
class Kaltura_Client_Type_MediaFlavorParams extends Kaltura_Client_Type_FlavorParams
{
	public function getKalturaObjectType()
	{
		return 'KalturaMediaFlavorParams';
	}
	

}

