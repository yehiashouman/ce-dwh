<?php
class Kaltura_Client_Type_FlavorParamsFilter extends Kaltura_Client_Type_FlavorParamsBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaFlavorParamsFilter';
	}
	

}

