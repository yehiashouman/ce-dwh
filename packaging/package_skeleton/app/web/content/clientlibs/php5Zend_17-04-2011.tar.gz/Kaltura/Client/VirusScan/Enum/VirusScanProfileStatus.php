<?php
class Kaltura_Client_VirusScan_Enum_VirusScanProfileStatus
{
	const DISABLED = 1;
	const ENABLED = 2;
}

