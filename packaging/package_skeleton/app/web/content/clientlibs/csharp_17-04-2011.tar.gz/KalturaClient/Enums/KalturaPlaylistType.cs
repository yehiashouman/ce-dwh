namespace Kaltura
{
	public enum KalturaPlaylistType
	{
		DYNAMIC = 10,
		STATIC_LIST = 3,
		EXTERNAL = 101,
	}
}
