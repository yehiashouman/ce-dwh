package com.kaltura.client.enums;

/**
 * This class was generated using generate.php
 * against an XML schema provided by Kaltura.
 * @date Tue, 03 May 11 15:50:03 +0300
 * 
 * MANUAL CHANGES TO THIS CLASS WILL BE OVERWRITTEN.
 */
public enum KalturaStorageProfileStatus {
    DISABLED (1),
    AUTOMATIC (2),
    MANUAL (3);

    int hashCode;

    KalturaStorageProfileStatus(int hashCode) {
        this.hashCode = hashCode;
    }

    public int getHashCode() {
        return this.hashCode;
    }

    public static KalturaStorageProfileStatus get(int hashCode) {
        switch(hashCode) {
            case 1: return DISABLED;
            case 2: return AUTOMATIC;
            case 3: return MANUAL;
            default: return DISABLED;
        }
    }
}
