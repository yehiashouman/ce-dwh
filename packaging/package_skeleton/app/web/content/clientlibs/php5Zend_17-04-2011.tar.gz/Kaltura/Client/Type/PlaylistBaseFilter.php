<?php
abstract class Kaltura_Client_Type_PlaylistBaseFilter extends Kaltura_Client_Type_BaseEntryFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaPlaylistBaseFilter';
	}
	

}

