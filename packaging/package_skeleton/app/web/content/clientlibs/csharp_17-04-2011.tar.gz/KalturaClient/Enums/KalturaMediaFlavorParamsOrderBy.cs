namespace Kaltura
{
	public sealed class KalturaMediaFlavorParamsOrderBy : KalturaStringEnum
	{

		private KalturaMediaFlavorParamsOrderBy(string name) : base(name) { }
	}
}
