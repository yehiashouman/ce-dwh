namespace Kaltura
{
	public enum KalturaShortLinkStatus
	{
		DISABLED = 1,
		ENABLED = 2,
		DELETED = 3,
	}
}
