<?php
class Kaltura_Client_Enum_ModerationObjectType
{
	const ENTRY = 2;
	const USER = 3;
}

