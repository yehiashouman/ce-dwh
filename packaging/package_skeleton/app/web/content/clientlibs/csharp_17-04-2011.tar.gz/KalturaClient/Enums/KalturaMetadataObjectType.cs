namespace Kaltura
{
	public enum KalturaMetadataObjectType
	{
		ENTRY = 1,
	}
}
