using System;
using System.Xml;
using System.Collections.Generic;
using System.IO;

namespace Kaltura
{

	public class KalturaFlavorParamsOutputService : KalturaServiceBase
	{
	public KalturaFlavorParamsOutputService(KalturaClient client)
			: base(client)
		{
		}

		public KalturaFlavorParamsOutputListResponse List()
		{
			return this.List(null);
		}

		public KalturaFlavorParamsOutputListResponse List(KalturaFlavorParamsOutputFilter filter)
		{
			return this.List(filter, null);
		}

		public KalturaFlavorParamsOutputListResponse List(KalturaFlavorParamsOutputFilter filter, KalturaFilterPager pager)
		{
			KalturaParams kparams = new KalturaParams();
			if (filter != null)
				kparams.Add("filter", filter.ToParams());
			if (pager != null)
				kparams.Add("pager", pager.ToParams());
			_Client.QueueServiceCall("adminconsole_flavorparamsoutput", "list", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaFlavorParamsOutputListResponse)KalturaObjectFactory.Create(result);
		}
	}
}
