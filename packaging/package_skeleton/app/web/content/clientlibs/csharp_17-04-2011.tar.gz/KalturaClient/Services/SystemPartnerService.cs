using System;
using System.Xml;
using System.Collections.Generic;
using System.IO;

namespace Kaltura
{

	public class KalturaSystemPartnerService : KalturaServiceBase
	{
	public KalturaSystemPartnerService(KalturaClient client)
			: base(client)
		{
		}

		public KalturaPartner Get(int partnerId)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddIntIfNotNull("partnerId", partnerId);
			_Client.QueueServiceCall("systempartner_systempartner", "get", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaPartner)KalturaObjectFactory.Create(result);
		}

		public KalturaSystemPartnerUsageListResponse GetUsage()
		{
			return this.GetUsage(null);
		}

		public KalturaSystemPartnerUsageListResponse GetUsage(KalturaPartnerFilter partnerFilter)
		{
			return this.GetUsage(partnerFilter, null);
		}

		public KalturaSystemPartnerUsageListResponse GetUsage(KalturaPartnerFilter partnerFilter, KalturaSystemPartnerUsageFilter usageFilter)
		{
			return this.GetUsage(partnerFilter, usageFilter, null);
		}

		public KalturaSystemPartnerUsageListResponse GetUsage(KalturaPartnerFilter partnerFilter, KalturaSystemPartnerUsageFilter usageFilter, KalturaFilterPager pager)
		{
			KalturaParams kparams = new KalturaParams();
			if (partnerFilter != null)
				kparams.Add("partnerFilter", partnerFilter.ToParams());
			if (usageFilter != null)
				kparams.Add("usageFilter", usageFilter.ToParams());
			if (pager != null)
				kparams.Add("pager", pager.ToParams());
			_Client.QueueServiceCall("systempartner_systempartner", "getUsage", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaSystemPartnerUsageListResponse)KalturaObjectFactory.Create(result);
		}

		public KalturaPartnerListResponse List()
		{
			return this.List(null);
		}

		public KalturaPartnerListResponse List(KalturaPartnerFilter filter)
		{
			return this.List(filter, null);
		}

		public KalturaPartnerListResponse List(KalturaPartnerFilter filter, KalturaFilterPager pager)
		{
			KalturaParams kparams = new KalturaParams();
			if (filter != null)
				kparams.Add("filter", filter.ToParams());
			if (pager != null)
				kparams.Add("pager", pager.ToParams());
			_Client.QueueServiceCall("systempartner_systempartner", "list", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaPartnerListResponse)KalturaObjectFactory.Create(result);
		}

		public void UpdateStatus(int partnerId, KalturaPartnerStatus status)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddIntIfNotNull("partnerId", partnerId);
			kparams.AddEnumIfNotNull("status", status);
			_Client.QueueServiceCall("systempartner_systempartner", "updateStatus", kparams);
			if (this._Client.IsMultiRequest)
				return;
			XmlElement result = _Client.DoQueue();
		}

		public string GetAdminSession(int partnerId)
		{
			return this.GetAdminSession(partnerId, "");
		}

		public string GetAdminSession(int partnerId, string userId)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddIntIfNotNull("partnerId", partnerId);
			kparams.AddStringIfNotNull("userId", userId);
			_Client.QueueServiceCall("systempartner_systempartner", "getAdminSession", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return result.InnerText;
		}

		public void UpdateConfiguration(int partnerId, KalturaSystemPartnerConfiguration configuration)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddIntIfNotNull("partnerId", partnerId);
			if (configuration != null)
				kparams.Add("configuration", configuration.ToParams());
			_Client.QueueServiceCall("systempartner_systempartner", "updateConfiguration", kparams);
			if (this._Client.IsMultiRequest)
				return;
			XmlElement result = _Client.DoQueue();
		}

		public KalturaSystemPartnerConfiguration GetConfiguration(int partnerId)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddIntIfNotNull("partnerId", partnerId);
			_Client.QueueServiceCall("systempartner_systempartner", "getConfiguration", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaSystemPartnerConfiguration)KalturaObjectFactory.Create(result);
		}

		public IList<KalturaSystemPartnerPackage> GetPackages()
		{
			KalturaParams kparams = new KalturaParams();
			_Client.QueueServiceCall("systempartner_systempartner", "getPackages", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			IList<KalturaSystemPartnerPackage> list = new List<KalturaSystemPartnerPackage>();
			foreach(XmlElement node in result.ChildNodes)
			{
				list.Add((KalturaSystemPartnerPackage)KalturaObjectFactory.Create(node));
			}
			return list;
		}
	}
}
