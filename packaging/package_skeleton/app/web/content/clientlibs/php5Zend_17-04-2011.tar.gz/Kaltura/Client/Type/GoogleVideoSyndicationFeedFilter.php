<?php
class Kaltura_Client_Type_GoogleVideoSyndicationFeedFilter extends Kaltura_Client_Type_GoogleVideoSyndicationFeedBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaGoogleVideoSyndicationFeedFilter';
	}
	

}

