<?php
class Kaltura_Client_Type_EntryContextDataParams extends Kaltura_Client_ObjectBase
{
	public function getKalturaObjectType()
	{
		return 'KalturaEntryContextDataParams';
	}
	
	/**
	 * 
	 *
	 * @var string
	 */
	public $referrer = null;


}

