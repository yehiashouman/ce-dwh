namespace Kaltura
{
	public sealed class KalturaThumbParamsOrderBy : KalturaStringEnum
	{

		private KalturaThumbParamsOrderBy(string name) : base(name) { }
	}
}
