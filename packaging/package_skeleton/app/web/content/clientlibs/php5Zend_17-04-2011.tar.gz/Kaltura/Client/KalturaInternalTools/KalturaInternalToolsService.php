<?php

class Kaltura_Client_KalturaInternalTools_KalturaInternalToolsService extends Kaltura_Client_ServiceBase
{
	function __construct(Kaltura_Client_Client $client = null)
	{
		parent::__construct($client);
	}
}
