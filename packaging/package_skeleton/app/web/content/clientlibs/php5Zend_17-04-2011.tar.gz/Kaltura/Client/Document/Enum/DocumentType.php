<?php
class Kaltura_Client_Document_Enum_DocumentType
{
	const DOCUMENT = 11;
	const SWF = 12;
	const PDF = 13;
}

