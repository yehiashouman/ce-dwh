<?php
class Kaltura_Client_ShortLink_Type_ShortLinkListResponse extends Kaltura_Client_ObjectBase
{
	public function getKalturaObjectType()
	{
		return 'KalturaShortLinkListResponse';
	}
	
	/**
	 * 
	 *
	 * @var array of KalturaShortLink
	 * @readonly
	 */
	public $objects;

	/**
	 * 
	 *
	 * @var int
	 * @readonly
	 */
	public $totalCount = null;


}

