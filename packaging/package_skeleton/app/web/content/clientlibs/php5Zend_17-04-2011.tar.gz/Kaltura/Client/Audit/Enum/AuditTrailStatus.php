<?php
class Kaltura_Client_Audit_Enum_AuditTrailStatus
{
	const PENDING = 1;
	const READY = 2;
	const FAILED = 3;
}

