namespace Kaltura
{
	public enum KalturaWidgetSecurityType
	{
		NONE = 1,
		TIMEHASH = 2,
	}
}
