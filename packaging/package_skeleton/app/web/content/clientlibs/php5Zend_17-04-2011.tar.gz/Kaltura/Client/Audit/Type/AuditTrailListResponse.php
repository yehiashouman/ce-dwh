<?php
class Kaltura_Client_Audit_Type_AuditTrailListResponse extends Kaltura_Client_ObjectBase
{
	public function getKalturaObjectType()
	{
		return 'KalturaAuditTrailListResponse';
	}
	
	/**
	 * 
	 *
	 * @var array of KalturaAuditTrail
	 * @readonly
	 */
	public $objects;

	/**
	 * 
	 *
	 * @var int
	 * @readonly
	 */
	public $totalCount = null;


}

