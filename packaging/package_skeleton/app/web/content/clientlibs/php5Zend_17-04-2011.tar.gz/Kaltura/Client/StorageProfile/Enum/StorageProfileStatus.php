<?php
class Kaltura_Client_StorageProfile_Enum_StorageProfileStatus
{
	const DISABLED = 1;
	const AUTOMATIC = 2;
	const MANUAL = 3;
}

