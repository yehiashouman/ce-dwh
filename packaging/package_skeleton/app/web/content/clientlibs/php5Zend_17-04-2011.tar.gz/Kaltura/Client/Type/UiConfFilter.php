<?php
class Kaltura_Client_Type_UiConfFilter extends Kaltura_Client_Type_UiConfBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaUiConfFilter';
	}
	

}

