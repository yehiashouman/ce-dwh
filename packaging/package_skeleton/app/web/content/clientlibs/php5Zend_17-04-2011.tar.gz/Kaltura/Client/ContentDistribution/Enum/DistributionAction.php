<?php
class Kaltura_Client_ContentDistribution_Enum_DistributionAction
{
	const SUBMIT = 1;
	const UPDATE = 2;
	const DELETE = 3;
	const FETCH_REPORT = 4;
}

