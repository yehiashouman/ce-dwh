namespace Kaltura
{
	public enum KalturaBitRateMode
	{
		CBR = 1,
		VBR = 2,
	}
}
