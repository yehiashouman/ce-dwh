<?php
class Kaltura_Client_Type_FlavorParamsOutputFilter extends Kaltura_Client_Type_FlavorParamsOutputBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaFlavorParamsOutputFilter';
	}
	

}

