namespace Kaltura
{
	public enum KalturaSearchConditionComparison
	{
		EQUEL = 1,
		GREATER_THAN = 2,
		GREATER_THAN_OR_EQUEL = 3,
		LESS_THAN = 4,
		LESS_THAN_OR_EQUEL = 5,
	}
}
