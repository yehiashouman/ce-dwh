using System;
using System.Xml;
using System.Collections.Generic;

namespace Kaltura
{
	public class KalturaMediaInfo : KalturaObjectBase
	{
		#region Private Fields
		private int _Id = Int32.MinValue;
		private string _FlavorAssetId = null;
		private int _FileSize = Int32.MinValue;
		private string _ContainerFormat = null;
		private string _ContainerId = null;
		private string _ContainerProfile = null;
		private int _ContainerDuration = Int32.MinValue;
		private int _ContainerBitRate = Int32.MinValue;
		private string _VideoFormat = null;
		private string _VideoCodecId = null;
		private int _VideoDuration = Int32.MinValue;
		private int _VideoBitRate = Int32.MinValue;
		private KalturaBitRateMode _VideoBitRateMode = (KalturaBitRateMode)Int32.MinValue;
		private int _VideoWidth = Int32.MinValue;
		private int _VideoHeight = Int32.MinValue;
		private float _VideoFrameRate = Single.MinValue;
		private float _VideoDar = Single.MinValue;
		private int _VideoRotation = Int32.MinValue;
		private string _AudioFormat = null;
		private string _AudioCodecId = null;
		private int _AudioDuration = Int32.MinValue;
		private int _AudioBitRate = Int32.MinValue;
		private KalturaBitRateMode _AudioBitRateMode = (KalturaBitRateMode)Int32.MinValue;
		private int _AudioChannels = Int32.MinValue;
		private int _AudioSamplingRate = Int32.MinValue;
		private int _AudioResolution = Int32.MinValue;
		private string _WritingLib = null;
		private string _RawData = null;
		private string _MultiStreamInfo = null;
		private int _ScanType = Int32.MinValue;
		private string _MultiStream = null;
		#endregion

		#region Properties
		public int Id
		{
			get { return _Id; }
			set 
			{ 
				_Id = value;
				OnPropertyChanged("Id");
			}
		}
		public string FlavorAssetId
		{
			get { return _FlavorAssetId; }
			set 
			{ 
				_FlavorAssetId = value;
				OnPropertyChanged("FlavorAssetId");
			}
		}
		public int FileSize
		{
			get { return _FileSize; }
			set 
			{ 
				_FileSize = value;
				OnPropertyChanged("FileSize");
			}
		}
		public string ContainerFormat
		{
			get { return _ContainerFormat; }
			set 
			{ 
				_ContainerFormat = value;
				OnPropertyChanged("ContainerFormat");
			}
		}
		public string ContainerId
		{
			get { return _ContainerId; }
			set 
			{ 
				_ContainerId = value;
				OnPropertyChanged("ContainerId");
			}
		}
		public string ContainerProfile
		{
			get { return _ContainerProfile; }
			set 
			{ 
				_ContainerProfile = value;
				OnPropertyChanged("ContainerProfile");
			}
		}
		public int ContainerDuration
		{
			get { return _ContainerDuration; }
			set 
			{ 
				_ContainerDuration = value;
				OnPropertyChanged("ContainerDuration");
			}
		}
		public int ContainerBitRate
		{
			get { return _ContainerBitRate; }
			set 
			{ 
				_ContainerBitRate = value;
				OnPropertyChanged("ContainerBitRate");
			}
		}
		public string VideoFormat
		{
			get { return _VideoFormat; }
			set 
			{ 
				_VideoFormat = value;
				OnPropertyChanged("VideoFormat");
			}
		}
		public string VideoCodecId
		{
			get { return _VideoCodecId; }
			set 
			{ 
				_VideoCodecId = value;
				OnPropertyChanged("VideoCodecId");
			}
		}
		public int VideoDuration
		{
			get { return _VideoDuration; }
			set 
			{ 
				_VideoDuration = value;
				OnPropertyChanged("VideoDuration");
			}
		}
		public int VideoBitRate
		{
			get { return _VideoBitRate; }
			set 
			{ 
				_VideoBitRate = value;
				OnPropertyChanged("VideoBitRate");
			}
		}
		public KalturaBitRateMode VideoBitRateMode
		{
			get { return _VideoBitRateMode; }
			set 
			{ 
				_VideoBitRateMode = value;
				OnPropertyChanged("VideoBitRateMode");
			}
		}
		public int VideoWidth
		{
			get { return _VideoWidth; }
			set 
			{ 
				_VideoWidth = value;
				OnPropertyChanged("VideoWidth");
			}
		}
		public int VideoHeight
		{
			get { return _VideoHeight; }
			set 
			{ 
				_VideoHeight = value;
				OnPropertyChanged("VideoHeight");
			}
		}
		public float VideoFrameRate
		{
			get { return _VideoFrameRate; }
			set 
			{ 
				_VideoFrameRate = value;
				OnPropertyChanged("VideoFrameRate");
			}
		}
		public float VideoDar
		{
			get { return _VideoDar; }
			set 
			{ 
				_VideoDar = value;
				OnPropertyChanged("VideoDar");
			}
		}
		public int VideoRotation
		{
			get { return _VideoRotation; }
			set 
			{ 
				_VideoRotation = value;
				OnPropertyChanged("VideoRotation");
			}
		}
		public string AudioFormat
		{
			get { return _AudioFormat; }
			set 
			{ 
				_AudioFormat = value;
				OnPropertyChanged("AudioFormat");
			}
		}
		public string AudioCodecId
		{
			get { return _AudioCodecId; }
			set 
			{ 
				_AudioCodecId = value;
				OnPropertyChanged("AudioCodecId");
			}
		}
		public int AudioDuration
		{
			get { return _AudioDuration; }
			set 
			{ 
				_AudioDuration = value;
				OnPropertyChanged("AudioDuration");
			}
		}
		public int AudioBitRate
		{
			get { return _AudioBitRate; }
			set 
			{ 
				_AudioBitRate = value;
				OnPropertyChanged("AudioBitRate");
			}
		}
		public KalturaBitRateMode AudioBitRateMode
		{
			get { return _AudioBitRateMode; }
			set 
			{ 
				_AudioBitRateMode = value;
				OnPropertyChanged("AudioBitRateMode");
			}
		}
		public int AudioChannels
		{
			get { return _AudioChannels; }
			set 
			{ 
				_AudioChannels = value;
				OnPropertyChanged("AudioChannels");
			}
		}
		public int AudioSamplingRate
		{
			get { return _AudioSamplingRate; }
			set 
			{ 
				_AudioSamplingRate = value;
				OnPropertyChanged("AudioSamplingRate");
			}
		}
		public int AudioResolution
		{
			get { return _AudioResolution; }
			set 
			{ 
				_AudioResolution = value;
				OnPropertyChanged("AudioResolution");
			}
		}
		public string WritingLib
		{
			get { return _WritingLib; }
			set 
			{ 
				_WritingLib = value;
				OnPropertyChanged("WritingLib");
			}
		}
		public string RawData
		{
			get { return _RawData; }
			set 
			{ 
				_RawData = value;
				OnPropertyChanged("RawData");
			}
		}
		public string MultiStreamInfo
		{
			get { return _MultiStreamInfo; }
			set 
			{ 
				_MultiStreamInfo = value;
				OnPropertyChanged("MultiStreamInfo");
			}
		}
		public int ScanType
		{
			get { return _ScanType; }
			set 
			{ 
				_ScanType = value;
				OnPropertyChanged("ScanType");
			}
		}
		public string MultiStream
		{
			get { return _MultiStream; }
			set 
			{ 
				_MultiStream = value;
				OnPropertyChanged("MultiStream");
			}
		}
		#endregion

		#region CTor
		public KalturaMediaInfo()
		{
		}

		public KalturaMediaInfo(XmlElement node)
		{
			foreach (XmlElement propertyNode in node.ChildNodes)
			{
				string txt = propertyNode.InnerText;
				switch (propertyNode.Name)
				{
					case "id":
						this.Id = ParseInt(txt);
						continue;
					case "flavorAssetId":
						this.FlavorAssetId = txt;
						continue;
					case "fileSize":
						this.FileSize = ParseInt(txt);
						continue;
					case "containerFormat":
						this.ContainerFormat = txt;
						continue;
					case "containerId":
						this.ContainerId = txt;
						continue;
					case "containerProfile":
						this.ContainerProfile = txt;
						continue;
					case "containerDuration":
						this.ContainerDuration = ParseInt(txt);
						continue;
					case "containerBitRate":
						this.ContainerBitRate = ParseInt(txt);
						continue;
					case "videoFormat":
						this.VideoFormat = txt;
						continue;
					case "videoCodecId":
						this.VideoCodecId = txt;
						continue;
					case "videoDuration":
						this.VideoDuration = ParseInt(txt);
						continue;
					case "videoBitRate":
						this.VideoBitRate = ParseInt(txt);
						continue;
					case "videoBitRateMode":
						this.VideoBitRateMode = (KalturaBitRateMode)ParseEnum(typeof(KalturaBitRateMode), txt);
						continue;
					case "videoWidth":
						this.VideoWidth = ParseInt(txt);
						continue;
					case "videoHeight":
						this.VideoHeight = ParseInt(txt);
						continue;
					case "videoFrameRate":
						this.VideoFrameRate = ParseFloat(txt);
						continue;
					case "videoDar":
						this.VideoDar = ParseFloat(txt);
						continue;
					case "videoRotation":
						this.VideoRotation = ParseInt(txt);
						continue;
					case "audioFormat":
						this.AudioFormat = txt;
						continue;
					case "audioCodecId":
						this.AudioCodecId = txt;
						continue;
					case "audioDuration":
						this.AudioDuration = ParseInt(txt);
						continue;
					case "audioBitRate":
						this.AudioBitRate = ParseInt(txt);
						continue;
					case "audioBitRateMode":
						this.AudioBitRateMode = (KalturaBitRateMode)ParseEnum(typeof(KalturaBitRateMode), txt);
						continue;
					case "audioChannels":
						this.AudioChannels = ParseInt(txt);
						continue;
					case "audioSamplingRate":
						this.AudioSamplingRate = ParseInt(txt);
						continue;
					case "audioResolution":
						this.AudioResolution = ParseInt(txt);
						continue;
					case "writingLib":
						this.WritingLib = txt;
						continue;
					case "rawData":
						this.RawData = txt;
						continue;
					case "multiStreamInfo":
						this.MultiStreamInfo = txt;
						continue;
					case "scanType":
						this.ScanType = ParseInt(txt);
						continue;
					case "multiStream":
						this.MultiStream = txt;
						continue;
				}
			}
		}
		#endregion

		#region Methods
		public override KalturaParams ToParams()
		{
			KalturaParams kparams = base.ToParams();
			kparams.AddIntIfNotNull("id", this.Id);
			kparams.AddStringIfNotNull("flavorAssetId", this.FlavorAssetId);
			kparams.AddIntIfNotNull("fileSize", this.FileSize);
			kparams.AddStringIfNotNull("containerFormat", this.ContainerFormat);
			kparams.AddStringIfNotNull("containerId", this.ContainerId);
			kparams.AddStringIfNotNull("containerProfile", this.ContainerProfile);
			kparams.AddIntIfNotNull("containerDuration", this.ContainerDuration);
			kparams.AddIntIfNotNull("containerBitRate", this.ContainerBitRate);
			kparams.AddStringIfNotNull("videoFormat", this.VideoFormat);
			kparams.AddStringIfNotNull("videoCodecId", this.VideoCodecId);
			kparams.AddIntIfNotNull("videoDuration", this.VideoDuration);
			kparams.AddIntIfNotNull("videoBitRate", this.VideoBitRate);
			kparams.AddEnumIfNotNull("videoBitRateMode", this.VideoBitRateMode);
			kparams.AddIntIfNotNull("videoWidth", this.VideoWidth);
			kparams.AddIntIfNotNull("videoHeight", this.VideoHeight);
			kparams.AddFloatIfNotNull("videoFrameRate", this.VideoFrameRate);
			kparams.AddFloatIfNotNull("videoDar", this.VideoDar);
			kparams.AddIntIfNotNull("videoRotation", this.VideoRotation);
			kparams.AddStringIfNotNull("audioFormat", this.AudioFormat);
			kparams.AddStringIfNotNull("audioCodecId", this.AudioCodecId);
			kparams.AddIntIfNotNull("audioDuration", this.AudioDuration);
			kparams.AddIntIfNotNull("audioBitRate", this.AudioBitRate);
			kparams.AddEnumIfNotNull("audioBitRateMode", this.AudioBitRateMode);
			kparams.AddIntIfNotNull("audioChannels", this.AudioChannels);
			kparams.AddIntIfNotNull("audioSamplingRate", this.AudioSamplingRate);
			kparams.AddIntIfNotNull("audioResolution", this.AudioResolution);
			kparams.AddStringIfNotNull("writingLib", this.WritingLib);
			kparams.AddStringIfNotNull("rawData", this.RawData);
			kparams.AddStringIfNotNull("multiStreamInfo", this.MultiStreamInfo);
			kparams.AddIntIfNotNull("scanType", this.ScanType);
			kparams.AddStringIfNotNull("multiStream", this.MultiStream);
			return kparams;
		}
		#endregion
	}
}

