namespace Kaltura
{
	public enum KalturaDistributionErrorType
	{
		MISSING_FLAVOR = 1,
		MISSING_THUMBNAIL = 2,
		MISSING_METADATA = 3,
		INVALID_DATA = 4,
	}
}
