<?php
abstract class Kaltura_Client_Type_MediaFlavorParamsBaseFilter extends Kaltura_Client_Type_FlavorParamsFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaMediaFlavorParamsBaseFilter';
	}
	

}

