namespace Kaltura
{
	public enum KalturaMetadataStatus
	{
		VALID = 1,
		INVALID = 2,
		DELETED = 3,
	}
}
