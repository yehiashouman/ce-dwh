<?php
class Kaltura_Client_Enum_UserStatus
{
	const BLOCKED = 0;
	const ACTIVE = 1;
	const DELETED = 2;
}

