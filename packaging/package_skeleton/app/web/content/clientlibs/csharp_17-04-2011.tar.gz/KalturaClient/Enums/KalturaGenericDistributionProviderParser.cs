namespace Kaltura
{
	public enum KalturaGenericDistributionProviderParser
	{
		XSL = 1,
		XPATH = 2,
		REGEX = 3,
	}
}
