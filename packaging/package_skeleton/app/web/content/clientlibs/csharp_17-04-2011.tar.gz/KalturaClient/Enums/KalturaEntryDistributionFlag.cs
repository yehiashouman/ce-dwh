namespace Kaltura
{
	public enum KalturaEntryDistributionFlag
	{
		NONE = 0,
		SUBMIT_REQUIRED = 1,
		DELETE_REQUIRED = 2,
		UPDATE_REQUIRED = 3,
	}
}
