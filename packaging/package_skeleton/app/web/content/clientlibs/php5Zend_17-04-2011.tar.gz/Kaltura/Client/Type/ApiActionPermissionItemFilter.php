<?php
class Kaltura_Client_Type_ApiActionPermissionItemFilter extends Kaltura_Client_Type_ApiActionPermissionItemBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaApiActionPermissionItemFilter';
	}
	

}

