<?php
abstract class Kaltura_Client_Type_FlavorAssetBaseFilter extends Kaltura_Client_Type_AssetFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaFlavorAssetBaseFilter';
	}
	

}

