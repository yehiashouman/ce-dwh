<?php
class Kaltura_Client_Type_ThumbAssetFilter extends Kaltura_Client_Type_ThumbAssetBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaThumbAssetFilter';
	}
	

}

