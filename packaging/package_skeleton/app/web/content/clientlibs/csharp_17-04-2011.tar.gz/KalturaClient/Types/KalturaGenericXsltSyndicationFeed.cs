using System;
using System.Xml;
using System.Collections.Generic;

namespace Kaltura
{
	public class KalturaGenericXsltSyndicationFeed : KalturaGenericSyndicationFeed
	{
		#region Private Fields
		private string _Xslt = null;
		#endregion

		#region Properties
		public string Xslt
		{
			get { return _Xslt; }
			set 
			{ 
				_Xslt = value;
				OnPropertyChanged("Xslt");
			}
		}
		#endregion

		#region CTor
		public KalturaGenericXsltSyndicationFeed()
		{
		}

		public KalturaGenericXsltSyndicationFeed(XmlElement node) : base(node)
		{
			foreach (XmlElement propertyNode in node.ChildNodes)
			{
				string txt = propertyNode.InnerText;
				switch (propertyNode.Name)
				{
					case "xslt":
						this.Xslt = txt;
						continue;
				}
			}
		}
		#endregion

		#region Methods
		public override KalturaParams ToParams()
		{
			KalturaParams kparams = base.ToParams();
			kparams.AddStringIfNotNull("xslt", this.Xslt);
			return kparams;
		}
		#endregion
	}
}

