<?php
class Kaltura_Client_Enum_ModerationFlagStatus
{
	const PENDING = 1;
	const MODERATED = 2;
}

