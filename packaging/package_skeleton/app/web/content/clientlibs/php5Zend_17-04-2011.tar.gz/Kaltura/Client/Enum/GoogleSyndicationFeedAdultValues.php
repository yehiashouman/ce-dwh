<?php
class Kaltura_Client_Enum_GoogleSyndicationFeedAdultValues
{
	const YES = "Yes";
	const NO = "No";
}

