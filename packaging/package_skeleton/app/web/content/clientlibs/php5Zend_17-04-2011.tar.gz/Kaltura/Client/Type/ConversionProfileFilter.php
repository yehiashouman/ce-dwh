<?php
class Kaltura_Client_Type_ConversionProfileFilter extends Kaltura_Client_Type_ConversionProfileBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaConversionProfileFilter';
	}
	

}

