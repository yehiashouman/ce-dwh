Kaltura JavaScript API Client Library.
Run kaltura.min.js.php to create merged minified version of the client library. 