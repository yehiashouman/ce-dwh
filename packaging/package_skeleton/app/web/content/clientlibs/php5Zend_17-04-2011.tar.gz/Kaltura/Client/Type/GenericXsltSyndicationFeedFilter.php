<?php
class Kaltura_Client_Type_GenericXsltSyndicationFeedFilter extends Kaltura_Client_Type_GenericXsltSyndicationFeedBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaGenericXsltSyndicationFeedFilter';
	}
	

}

