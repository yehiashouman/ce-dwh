<?php
/**
 * @package External
 * @subpackage Kaltura
 */
abstract class Kaltura_Client_Plugin implements Kaltura_Client_IPlugin
{
	protected function __construct(Kaltura_Client_Client $client)
	{
		
	}
}
