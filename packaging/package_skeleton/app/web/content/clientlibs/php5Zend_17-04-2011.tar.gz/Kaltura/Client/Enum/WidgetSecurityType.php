<?php
class Kaltura_Client_Enum_WidgetSecurityType
{
	const NONE = 1;
	const TIMEHASH = 2;
}

