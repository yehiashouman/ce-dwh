namespace Kaltura
{
	public enum KalturaPermissionType
	{
		NORMAL = 1,
		SPECIAL_FEATURE = 2,
		PLUGIN = 3,
		PARTNER_GROUP = 4,
	}
}
