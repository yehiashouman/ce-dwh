<?php
abstract class Kaltura_Client_Type_AssetParamsBaseFilter extends Kaltura_Client_Type_Filter
{
	public function getKalturaObjectType()
	{
		return 'KalturaAssetParamsBaseFilter';
	}
	
	/**
	 * 
	 *
	 * @var Kaltura_Client_Enum_NullableBoolean
	 */
	public $isSystemDefaultEqual = null;

	/**
	 * 
	 *
	 * @var string
	 */
	public $tagsEqual = null;

	/**
	 * 
	 *
	 * @var Kaltura_Client_Enum_ContainerFormat
	 */
	public $formatEqual = null;


}

