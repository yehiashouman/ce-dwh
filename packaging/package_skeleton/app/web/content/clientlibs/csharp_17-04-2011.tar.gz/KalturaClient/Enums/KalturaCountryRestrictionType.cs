namespace Kaltura
{
	public enum KalturaCountryRestrictionType
	{
		RESTRICT_COUNTRY_LIST = 0,
		ALLOW_COUNTRY_LIST = 1,
	}
}
