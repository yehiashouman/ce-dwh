namespace Kaltura
{
	public enum KalturaSyndicationFeedType
	{
		GOOGLE_VIDEO = 1,
		YAHOO = 2,
		ITUNES = 3,
		TUBE_MOGUL = 4,
		KALTURA = 5,
		KALTURA_XSLT = 6,
	}
}
