namespace Kaltura
{
	public sealed class KalturaAnnotationOrderBy : KalturaStringEnum
	{
		public static readonly KalturaAnnotationOrderBy CREATED_AT_ASC = new KalturaAnnotationOrderBy("+createdAt");
		public static readonly KalturaAnnotationOrderBy CREATED_AT_DESC = new KalturaAnnotationOrderBy("-createdAt");
		public static readonly KalturaAnnotationOrderBy UPDATED_AT_ASC = new KalturaAnnotationOrderBy("+updatedAt");
		public static readonly KalturaAnnotationOrderBy UPDATED_AT_DESC = new KalturaAnnotationOrderBy("-updatedAt");

		private KalturaAnnotationOrderBy(string name) : base(name) { }
	}
}
