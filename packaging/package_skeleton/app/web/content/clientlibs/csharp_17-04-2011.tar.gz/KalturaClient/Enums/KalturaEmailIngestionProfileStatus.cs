namespace Kaltura
{
	public enum KalturaEmailIngestionProfileStatus
	{
		INACTIVE = 0,
		ACTIVE = 1,
	}
}
