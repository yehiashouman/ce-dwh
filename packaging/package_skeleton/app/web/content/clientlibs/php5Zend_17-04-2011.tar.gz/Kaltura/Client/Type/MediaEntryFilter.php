<?php
class Kaltura_Client_Type_MediaEntryFilter extends Kaltura_Client_Type_MediaEntryBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaMediaEntryFilter';
	}
	

}

