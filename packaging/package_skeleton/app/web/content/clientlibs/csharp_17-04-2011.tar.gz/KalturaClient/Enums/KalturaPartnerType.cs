namespace Kaltura
{
	public enum KalturaPartnerType
	{
		KMC = 1,
		WIKI = 100,
		WORDPRESS = 101,
		DRUPAL = 102,
		DEKIWIKI = 103,
		MOODLE = 104,
		COMMUNITY_EDITION = 105,
		JOOMLA = 106,
		BLACKBOARD = 107,
		SAKAI = 108,
	}
}
