<?php
abstract class Kaltura_Client_Type_YahooSyndicationFeedBaseFilter extends Kaltura_Client_Type_BaseSyndicationFeedFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaYahooSyndicationFeedBaseFilter';
	}
	

}

