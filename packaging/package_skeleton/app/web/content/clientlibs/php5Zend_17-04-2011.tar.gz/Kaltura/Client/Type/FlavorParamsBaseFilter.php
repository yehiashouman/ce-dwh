<?php
abstract class Kaltura_Client_Type_FlavorParamsBaseFilter extends Kaltura_Client_Type_AssetParamsFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaFlavorParamsBaseFilter';
	}
	

}

