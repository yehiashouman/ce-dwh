namespace Kaltura
{
	public enum KalturaUserStatus
	{
		BLOCKED = 0,
		ACTIVE = 1,
		DELETED = 2,
	}
}
