using System;
using System.Xml;
using System.Collections.Generic;
using System.IO;

namespace Kaltura
{

	public class KalturaUiConfAdminService : KalturaServiceBase
	{
	public KalturaUiConfAdminService(KalturaClient client)
			: base(client)
		{
		}

		public KalturaUiConf Add(KalturaUiConf uiConf)
		{
			KalturaParams kparams = new KalturaParams();
			if (uiConf != null)
				kparams.Add("uiConf", uiConf.ToParams());
			_Client.QueueServiceCall("adminconsole_uiconfadmin", "add", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaUiConf)KalturaObjectFactory.Create(result);
		}

		public KalturaUiConf Update(int id, KalturaUiConf uiConf)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddIntIfNotNull("id", id);
			if (uiConf != null)
				kparams.Add("uiConf", uiConf.ToParams());
			_Client.QueueServiceCall("adminconsole_uiconfadmin", "update", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaUiConf)KalturaObjectFactory.Create(result);
		}

		public KalturaUiConf Get(int id)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddIntIfNotNull("id", id);
			_Client.QueueServiceCall("adminconsole_uiconfadmin", "get", kparams);
			if (this._Client.IsMultiRequest)
				return null;
			XmlElement result = _Client.DoQueue();
			return (KalturaUiConf)KalturaObjectFactory.Create(result);
		}

		public void Delete(int id)
		{
			KalturaParams kparams = new KalturaParams();
			kparams.AddIntIfNotNull("id", id);
			_Client.QueueServiceCall("adminconsole_uiconfadmin", "delete", kparams);
			if (this._Client.IsMultiRequest)
				return;
			XmlElement result = _Client.DoQueue();
		}
	}
}
