<?php
class Kaltura_Client_Metadata_Type_MetadataProfileFilter extends Kaltura_Client_Metadata_Type_MetadataProfileBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaMetadataProfileFilter';
	}
	

}

