namespace Kaltura
{
	public enum KalturaGenericDistributionProviderStatus
	{
		ACTIVE = 2,
		DELETED = 3,
	}
}
