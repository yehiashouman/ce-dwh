<?php
class Kaltura_Client_Type_PermissionItemFilter extends Kaltura_Client_Type_PermissionItemBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaPermissionItemFilter';
	}
	

}

