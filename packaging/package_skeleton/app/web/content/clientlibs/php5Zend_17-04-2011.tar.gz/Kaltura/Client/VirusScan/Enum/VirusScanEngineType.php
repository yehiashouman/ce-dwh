<?php
class Kaltura_Client_VirusScan_Enum_VirusScanEngineType
{
	const SYMANTEC_SCAN_ENGINE = "symantecScanEngine.SymantecScanEngine";
}

