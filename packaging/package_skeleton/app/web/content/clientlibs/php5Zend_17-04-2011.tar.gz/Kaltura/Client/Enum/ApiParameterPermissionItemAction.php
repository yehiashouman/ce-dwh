<?php
class Kaltura_Client_Enum_ApiParameterPermissionItemAction
{
	const READ = "read";
	const UPDATE = "update";
	const INSERT = "insert";
}

