using System;
using System.Xml;
using System.Collections.Generic;
using System.IO;

namespace Kaltura
{

	public class KalturaKalturaInternalToolsService : KalturaServiceBase
	{
	public KalturaKalturaInternalToolsService(KalturaClient client)
			: base(client)
		{
		}
	}
}
