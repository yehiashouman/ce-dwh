namespace Kaltura
{
	public enum KalturaNullableBoolean
	{
		NULL_VALUE = -1,
		FALSE_VALUE = 0,
		TRUE_VALUE = 1,
	}
}
