<?php
class Kaltura_Client_Enum_SearchOperatorType
{
	const SEARCH_AND = 1;
	const SEARCH_OR = 2;
}

