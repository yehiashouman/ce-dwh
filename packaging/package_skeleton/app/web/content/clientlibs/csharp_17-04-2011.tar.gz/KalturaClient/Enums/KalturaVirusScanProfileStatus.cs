namespace Kaltura
{
	public enum KalturaVirusScanProfileStatus
	{
		DISABLED = 1,
		ENABLED = 2,
	}
}
