<?php
abstract class Kaltura_Client_Type_SearchItem extends Kaltura_Client_ObjectBase
{
	public function getKalturaObjectType()
	{
		return 'KalturaSearchItem';
	}
	

}

