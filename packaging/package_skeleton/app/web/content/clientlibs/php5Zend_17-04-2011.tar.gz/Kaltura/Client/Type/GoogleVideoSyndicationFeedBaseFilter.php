<?php
abstract class Kaltura_Client_Type_GoogleVideoSyndicationFeedBaseFilter extends Kaltura_Client_Type_BaseSyndicationFeedFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaGoogleVideoSyndicationFeedBaseFilter';
	}
	

}

