<?php
abstract class Kaltura_Client_Audit_Type_AuditTrailInfo extends Kaltura_Client_ObjectBase
{
	public function getKalturaObjectType()
	{
		return 'KalturaAuditTrailInfo';
	}
	

}

