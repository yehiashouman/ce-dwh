<?php
class Kaltura_Client_Type_YahooSyndicationFeedFilter extends Kaltura_Client_Type_YahooSyndicationFeedBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaYahooSyndicationFeedFilter';
	}
	

}

