namespace Kaltura
{
	public enum KalturaStorageProfileProtocol
	{
		KALTURA_DC = 0,
		FTP = 1,
		SCP = 2,
		SFTP = 3,
	}
}
