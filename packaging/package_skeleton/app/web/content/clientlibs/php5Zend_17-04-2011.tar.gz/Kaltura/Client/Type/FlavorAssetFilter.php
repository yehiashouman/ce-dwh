<?php
class Kaltura_Client_Type_FlavorAssetFilter extends Kaltura_Client_Type_FlavorAssetBaseFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaFlavorAssetFilter';
	}
	

}

