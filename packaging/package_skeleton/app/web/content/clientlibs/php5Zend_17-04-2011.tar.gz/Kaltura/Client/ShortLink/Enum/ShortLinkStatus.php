<?php
class Kaltura_Client_ShortLink_Enum_ShortLinkStatus
{
	const DISABLED = 1;
	const ENABLED = 2;
	const DELETED = 3;
}

