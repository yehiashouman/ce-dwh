namespace Kaltura
{
	public sealed class KalturaAssetType : KalturaStringEnum
	{
		public static readonly KalturaAssetType FLAVOR = new KalturaAssetType("1");
		public static readonly KalturaAssetType THUMBNAIL = new KalturaAssetType("2");
		public static readonly KalturaAssetType DOCUMENT = new KalturaAssetType("document.Document");
		public static readonly KalturaAssetType SWF = new KalturaAssetType("document.SWF");
		public static readonly KalturaAssetType PDF = new KalturaAssetType("document.PDF");

		private KalturaAssetType(string name) : base(name) { }
	}
}
