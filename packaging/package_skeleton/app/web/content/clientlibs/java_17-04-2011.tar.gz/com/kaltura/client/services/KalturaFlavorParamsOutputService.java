package com.kaltura.client.services;

import org.w3c.dom.Element;
import com.kaltura.client.KalturaApiException;
import com.kaltura.client.KalturaClient;
import com.kaltura.client.KalturaObjectFactory;
import com.kaltura.client.KalturaParams;
import com.kaltura.client.KalturaServiceBase;
import com.kaltura.client.utils.XmlUtils;
import com.kaltura.client.enums.*;
import com.kaltura.client.types.*;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import com.kaltura.client.KalturaFiles;

/**
 * This class was generated using generate.php
 * against an XML schema provided by Kaltura.
 * @date Tue, 03 May 11 15:50:03 +0300
 * 
 * MANUAL CHANGES TO THIS CLASS WILL BE OVERWRITTEN.
 */

public class KalturaFlavorParamsOutputService extends KalturaServiceBase {
    public KalturaFlavorParamsOutputService(KalturaClient client) {
        this.kalturaClient = client;
    }

    public KalturaFlavorParamsOutputListResponse list() throws KalturaApiException {
        return this.list(null);
    }

    public KalturaFlavorParamsOutputListResponse list(KalturaFlavorParamsOutputFilter filter) throws KalturaApiException {
        return this.list(filter, null);
    }

    public KalturaFlavorParamsOutputListResponse list(KalturaFlavorParamsOutputFilter filter, KalturaFilterPager pager) throws KalturaApiException {
        KalturaParams kparams = new KalturaParams();
        if (filter != null) kparams.add("filter", filter.toParams());
        if (pager != null) kparams.add("pager", pager.toParams());
        this.kalturaClient.queueServiceCall("adminconsole_flavorparamsoutput", "list", kparams);
        if (this.kalturaClient.isMultiRequest())
            return null;
        Element resultXmlElement = this.kalturaClient.doQueue();
        return (KalturaFlavorParamsOutputListResponse)KalturaObjectFactory.create(resultXmlElement);
    }
}
