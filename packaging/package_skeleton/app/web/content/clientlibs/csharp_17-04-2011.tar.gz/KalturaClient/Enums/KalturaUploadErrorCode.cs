namespace Kaltura
{
	public enum KalturaUploadErrorCode
	{
		NO_ERROR = 0,
		GENERAL_ERROR = 1,
		PARTIAL_UPLOAD = 2,
	}
}
