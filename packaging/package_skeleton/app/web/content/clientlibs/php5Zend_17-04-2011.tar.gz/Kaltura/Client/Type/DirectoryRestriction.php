<?php
class Kaltura_Client_Type_DirectoryRestriction extends Kaltura_Client_Type_BaseRestriction
{
	public function getKalturaObjectType()
	{
		return 'KalturaDirectoryRestriction';
	}
	
	/**
	 * Kaltura directory restriction type
	 * 
	 *
	 * @var Kaltura_Client_Enum_DirectoryRestrictionType
	 */
	public $directoryRestrictionType = null;


}

