﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kaltura
{
    public class KalturaMultiResponse : List<object>
    {
    }
}
