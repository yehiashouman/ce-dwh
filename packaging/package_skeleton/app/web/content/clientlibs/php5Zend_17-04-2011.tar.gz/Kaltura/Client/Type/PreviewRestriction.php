<?php
class Kaltura_Client_Type_PreviewRestriction extends Kaltura_Client_Type_SessionRestriction
{
	public function getKalturaObjectType()
	{
		return 'KalturaPreviewRestriction';
	}
	
	/**
	 * The preview restriction length 
	 * 
	 *
	 * @var int
	 */
	public $previewLength = null;


}

