﻿using System;
using System.Text;

namespace Kaltura
{
    public interface IKalturaLogger
    {
        void Log(string msg);
    }
}
