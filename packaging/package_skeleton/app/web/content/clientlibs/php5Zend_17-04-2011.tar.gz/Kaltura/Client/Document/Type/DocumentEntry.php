<?php
class Kaltura_Client_Document_Type_DocumentEntry extends Kaltura_Client_Type_BaseEntry
{
	public function getKalturaObjectType()
	{
		return 'KalturaDocumentEntry';
	}
	
	/**
	 * The type of the document
	 *
	 * @var Kaltura_Client_Document_Enum_DocumentType
	 * @insertonly
	 */
	public $documentType = null;

	/**
	 * Conversion profile ID to override the default conversion profile
	 * 
	 *
	 * @var string
	 * @insertonly
	 */
	public $conversionProfileId = null;


}

