<?php
class Kaltura_Client_Type_BaseRestriction extends Kaltura_Client_ObjectBase
{
	public function getKalturaObjectType()
	{
		return 'KalturaBaseRestriction';
	}
	

}

