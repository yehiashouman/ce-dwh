<?php
abstract class Kaltura_Client_Type_ApiParameterPermissionItemBaseFilter extends Kaltura_Client_Type_PermissionItemFilter
{
	public function getKalturaObjectType()
	{
		return 'KalturaApiParameterPermissionItemBaseFilter';
	}
	

}

